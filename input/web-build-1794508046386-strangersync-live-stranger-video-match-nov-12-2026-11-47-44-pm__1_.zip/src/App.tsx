import { useState, useEffect, useRef, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { VideoPlayer } from './components/VideoPlayer';
import { ControlsBar } from './components/ControlsBar';
import { ChatBox } from './components/ChatBox';
import { InterestsModal } from './components/InterestsModal';
import { SafetyModal } from './components/SafetyModal';
import { DualTabTestModal } from './components/DualTabTestModal';
import { ReportModal } from './components/ReportModal';
import { PrivacyPolicyModal } from './components/PrivacyPolicyModal';
import { CookieConsentBanner } from './components/CookieConsentBanner';
import { AdMobBanner } from './components/AdMobBanner';
import { InterstitialAdModal } from './components/InterstitialAdModal';
import { MonetizationSettingsModal } from './components/MonetizationSettingsModal';
import { AppOpenAdModal } from './components/AppOpenAdModal';
import { ApkExportModal } from './components/ApkExportModal';
import { WebRTCClient } from './utils/webrtcClient';
import { sounds } from './utils/audioEffects';
import { PracticeBotEngine } from './utils/botStream';
import {
  MatchState,
  ChatMessage,
  VideoFilter,
  FloatingReaction,
  StrangerProfile,
  AppStats,
  ChatMode,
  AdMobConfig
} from './types';

export default function App() {
  // Primary States
  const [matchState, setMatchState] = useState<MatchState>('idle');
  const [chatMode, setChatMode] = useState<ChatMode>('video');
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [videoFilter, setVideoFilter] = useState<VideoFilter>('none');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Chat & Match Details
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStrangerTyping, setIsStrangerTyping] = useState(false);
  const [stranger, setStranger] = useState<StrangerProfile | null>(null);
  const [reactions, setReactions] = useState<FloatingReaction[]>([]);

  // Telemetry & Settings
  const [stats, setStats] = useState<AppStats>({
    totalOnline: 1,
    inCalls: 0,
    inTextChat: 0,
    inQueue: 0
  });
  const [selectedInterests, setSelectedInterests] = useState<string[]>(['Tech & AI', 'Gaming']);
  const [selectedCountry, setSelectedCountry] = useState('Global');
  const [isPracticeMode, setIsPracticeMode] = useState(false);

  // Speaking indicator state
  const [isLocalSpeaking, setIsLocalSpeaking] = useState(false);
  const [isRemoteSpeaking, setIsRemoteSpeaking] = useState(false);

  // AdMob Monetization Configuration (Configured with User IDs)
  const [adMobConfig, setAdMobConfig] = useState<AdMobConfig>(() => {
    try {
      const saved = localStorage.getItem('strangersync_admob_config');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      appId: 'ca-app-pub-9670799162361917~4119297613',
      appOpenUnitId: 'ca-app-pub-9670799162361917/9179393460',
      publisherId: 'ca-pub-9670799162361917',
      bannerUnitId: 'ca-app-pub-9670799162361917/6300978111',
      interstitialUnitId: 'ca-app-pub-9670799162361917/1033173712',
      rewardedUnitId: 'ca-app-pub-9670799162361917/5224354917',
      testMode: false,
      adsEnabled: true,
      vipAdFree: false,
      interstitialFrequency: 4,
      showAppOpenOnLoad: true
    };
  });

  const [skipCount, setSkipCount] = useState(0);
  const [rewardNotice, setRewardNotice] = useState<string | null>(null);

  // Modals
  const [isSafetyOpen, setIsSafetyOpen] = useState(false);
  const [isDualTabTestOpen, setIsDualTabTestOpen] = useState(false);
  const [isInterestsOpen, setIsInterestsOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isMonetizationOpen, setIsMonetizationOpen] = useState(false);
  const [isInterstitialOpen, setIsInterstitialOpen] = useState(false);
  const [isAppOpenAdVisible, setIsAppOpenAdVisible] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // Show App Open Ad on launch
  useEffect(() => {
    if (adMobConfig.showAppOpenOnLoad && adMobConfig.adsEnabled && !adMobConfig.vipAdFree) {
      const timer = setTimeout(() => {
        setIsAppOpenAdVisible(true);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [adMobConfig.showAppOpenOnLoad, adMobConfig.adsEnabled, adMobConfig.vipAdFree]);

  // Camera permission error warning
  const [mediaError, setMediaError] = useState<string | null>(null);

  // References
  const wsRef = useRef<WebSocket | null>(null);
  const rtcClientRef = useRef<WebRTCClient | null>(null);
  const practiceBotRef = useRef<PracticeBotEngine | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioAnalyserRef = useRef<AnalyserNode | null>(null);

  // Keep localStreamRef synced
  useEffect(() => {
    localStreamRef.current = localStream;
  }, [localStream]);

  // Request user camera and microphone (for video mode)
  const initUserMedia = useCallback(async () => {
    try {
      if (localStreamRef.current) return localStreamRef.current;
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
        audio: true
      });
      setLocalStream(stream);
      setMediaError(null);

      // Setup audio analysis for local speaking detection
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AudioCtx();
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        const source = ctx.createMediaStreamSource(stream);
        source.connect(analyser);
        audioContextRef.current = ctx;
        audioAnalyserRef.current = analyser;

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        const checkVolume = () => {
          if (!audioAnalyserRef.current) return;
          audioAnalyserRef.current.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
          const average = sum / dataArray.length;
          setIsLocalSpeaking(average > 25);
          requestAnimationFrame(checkVolume);
        };
        checkVolume();
      } catch (err) {
        console.warn('Audio analyser setup note:', err);
      }

      return stream;
    } catch (err: unknown) {
      console.warn('Could not access camera/mic:', err);
      setMediaError('Camera or microphone permission is needed for video chat. Or you can switch to Text Only mode.');
      return null;
    }
  }, []);

  // WebSocket signaling setup
  useEffect(() => {
    let reconnectTimeout: NodeJS.Timeout;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    function connectWs() {
      const socket = new WebSocket(wsUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        // Send initial profile
        socket.send(JSON.stringify({
          type: 'set_profile',
          country: selectedCountry,
          interests: selectedInterests,
          chatMode
        }));
      };

      socket.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);

          switch (msg.type) {
            case 'connected':
              setStats((prev) => ({
                ...prev,
                totalOnline: Math.max(prev.totalOnline, msg.totalOnline || 1)
              }));
              break;

            case 'stats_update':
              setStats({
                totalOnline: msg.totalOnline,
                inCalls: msg.inCalls,
                inTextChat: msg.inTextChat || 0,
                inQueue: msg.inQueue
              });
              break;

            case 'queue_status':
              if (msg.status === 'waiting') {
                setMatchState('waiting');
              } else if (msg.status === 'idle') {
                setMatchState('idle');
              }
              break;

            case 'match_found': {
              setMatchState('connecting');
              sounds.playMatchFound();

              const activeMode = msg.chatMode || chatMode;
              setStranger({
                partnerId: msg.partnerId,
                country: msg.partnerCountry,
                sharedInterests: msg.sharedInterests || [],
                partnerInterests: msg.partnerInterests || [],
                chatMode: activeMode
              });

              // Add welcome system message to chat
              const sharedMsg = msg.sharedInterests && msg.sharedInterests.length > 0
                ? ` You both like: ${msg.sharedInterests.join(', ')}.`
                : '';
              setMessages([
                {
                  id: `sys_${Date.now()}`,
                  sender: 'system',
                  text: `Connected to stranger from ${msg.partnerCountry}!${sharedMsg} Say hello!`,
                  timestamp: Date.now()
                }
              ]);

              if (activeMode === 'text') {
                // In text mode, no WebRTC video negotiation needed
                setMatchState('connected');
                break;
              }

              // In video mode, initialize WebRTC peer connection
              const stream = localStreamRef.current || (await initUserMedia());
              const rtc = new WebRTCClient({
                onRemoteStream: (rStream) => {
                  setRemoteStream(rStream);
                  setMatchState('connected');
                },
                onIceCandidate: (candidate) => {
                  if (wsRef.current?.readyState === WebSocket.OPEN) {
                    wsRef.current.send(JSON.stringify({
                      type: 'ice_candidate',
                      candidate
                    }));
                  }
                },
                onConnectionStateChange: (state) => {
                  if (state === 'connected') {
                    setMatchState('connected');
                  } else if (state === 'disconnected' || state === 'failed') {
                    setMatchState('disconnected');
                  }
                }
              });

              rtcClientRef.current = rtc;
              rtc.initConnection(stream);

              if (msg.isCaller) {
                try {
                  const offer = await rtc.createOffer();
                  if (wsRef.current?.readyState === WebSocket.OPEN) {
                    wsRef.current.send(JSON.stringify({
                      type: 'webrtc_offer',
                      sdp: offer
                    }));
                  }
                } catch (e) {
                  console.error('Error creating WebRTC offer:', e);
                }
              }
              break;
            }

            case 'webrtc_offer': {
              if (rtcClientRef.current) {
                try {
                  const answer = await rtcClientRef.current.handleOffer(msg.sdp);
                  if (wsRef.current?.readyState === WebSocket.OPEN) {
                    wsRef.current.send(JSON.stringify({
                      type: 'webrtc_answer',
                      sdp: answer
                    }));
                  }
                } catch (e) {
                  console.error('Error handling WebRTC offer:', e);
                }
              }
              break;
            }

            case 'webrtc_answer': {
              if (rtcClientRef.current) {
                try {
                  await rtcClientRef.current.handleAnswer(msg.sdp);
                } catch (e) {
                  console.error('Error handling WebRTC answer:', e);
                }
              }
              break;
            }

            case 'ice_candidate': {
              if (rtcClientRef.current) {
                await rtcClientRef.current.addIceCandidate(msg.candidate);
              }
              break;
            }

            case 'chat_message': {
              sounds.playMessagePop();
              setMessages((prev) => [
                ...prev,
                {
                  id: `msg_${Date.now()}_${Math.random()}`,
                  sender: 'stranger',
                  text: msg.text,
                  timestamp: msg.timestamp || Date.now()
                }
              ]);
              break;
            }

            case 'chat_typing': {
              setIsStrangerTyping(!!msg.isTyping);
              break;
            }

            case 'icebreaker_prompt': {
              sounds.playMatchFound();
              setMessages((prev) => [
                ...prev,
                {
                  id: `ice_${Date.now()}`,
                  sender: 'system',
                  text: `🎲 ICEBREAKER: ${msg.prompt}`,
                  timestamp: Date.now()
                }
              ]);
              break;
            }

            case 'reaction_received': {
              sounds.playReaction();
              const newReaction: FloatingReaction = {
                id: msg.id || Math.random().toString(),
                emoji: msg.emoji,
                x: 35 + Math.random() * 40,
                y: 55 + Math.random() * 30
              };
              setReactions((prev) => [...prev, newReaction]);
              setTimeout(() => {
                setReactions((prev) => prev.filter((r) => r.id !== newReaction.id));
              }, 2000);
              break;
            }

            case 'stranger_disconnected': {
              sounds.playNextWhoosh();
              setMatchState('disconnected');
              setRemoteStream(null);
              if (rtcClientRef.current) {
                rtcClientRef.current.close();
                rtcClientRef.current = null;
              }
              setMessages((prev) => [
                ...prev,
                {
                  id: `sys_${Date.now()}`,
                  sender: 'system',
                  text: 'Stranger has disconnected or skipped.',
                  timestamp: Date.now()
                }
              ]);
              break;
            }

            case 'report_acknowledged': {
              setMessages((prev) => [
                ...prev,
                {
                  id: `sys_${Date.now()}`,
                  sender: 'system',
                  text: 'Report submitted. You have been disconnected safely.',
                  timestamp: Date.now()
                }
              ]);
              setMatchState('idle');
              setRemoteStream(null);
              if (rtcClientRef.current) {
                rtcClientRef.current.close();
                rtcClientRef.current = null;
              }
              break;
            }
          }
        } catch (err) {
          console.error('Error in socket message dispatch:', err);
        }
      };

      socket.onclose = () => {
        reconnectTimeout = setTimeout(connectWs, 2500);
      };
    }

    connectWs();

    return () => {
      clearTimeout(reconnectTimeout);
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (rtcClientRef.current) {
        rtcClientRef.current.close();
      }
    };
  }, [initUserMedia, selectedCountry, selectedInterests, chatMode]);

  // Sync profile update when modal closes
  const handleUpdateInterests = (newInterests: string[]) => {
    setSelectedInterests(newInterests);
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'set_profile',
        interests: newInterests,
        country: selectedCountry,
        chatMode
      }));
    }
  };

  const handleUpdateCountry = (newCountry: string) => {
    setSelectedCountry(newCountry);
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'set_profile',
        country: newCountry,
        interests: selectedInterests,
        chatMode
      }));
    }
  };

  // Change chat mode
  const handleChangeChatMode = (mode: ChatMode) => {
    setChatMode(mode);
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'set_profile',
        chatMode: mode,
        country: selectedCountry,
        interests: selectedInterests
      }));
    }
  };

  // Save AdMob configuration
  const handleSaveAdMobConfig = (newConfig: AdMobConfig) => {
    setAdMobConfig(newConfig);
    try {
      localStorage.setItem('strangersync_admob_config', JSON.stringify(newConfig));
    } catch {}
  };

  // Start live matching
  const handleStartMatching = async () => {
    if (isPracticeMode) {
      startPracticeBot();
      return;
    }

    if (chatMode === 'video') {
      await initUserMedia();
    }

    setMatchState('waiting');
    setMessages([]);
    setStranger(null);
    setRemoteStream(null);

    if (rtcClientRef.current) {
      rtcClientRef.current.close();
      rtcClientRef.current = null;
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'join_queue',
        country: selectedCountry,
        interests: selectedInterests,
        chatMode
      }));
    }
  };

  // Skip to next stranger with AdMob Interstitial trigger
  const handleNextStranger = async () => {
    sounds.playNextWhoosh();
    setRemoteStream(null);
    setStranger(null);
    setMessages([]);

    if (rtcClientRef.current) {
      rtcClientRef.current.close();
      rtcClientRef.current = null;
    }

    // Interstitial Ad Frequency Check (Monetization)
    const newSkip = skipCount + 1;
    setSkipCount(newSkip);
    if (
      adMobConfig.adsEnabled &&
      !adMobConfig.vipAdFree &&
      adMobConfig.interstitialFrequency > 0 &&
      newSkip % adMobConfig.interstitialFrequency === 0
    ) {
      setIsInterstitialOpen(true);
      return;
    }

    if (isPracticeMode) {
      startPracticeBot();
      return;
    }

    setMatchState('waiting');
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'next_stranger',
        country: selectedCountry,
        interests: selectedInterests,
        chatMode
      }));
    }
  };

  // When interstitial ad finishes or is dismissed
  const handleInterstitialCompleted = () => {
    setRewardNotice('AdMob Reward: Priority Queue Boost Active!');
    setTimeout(() => setRewardNotice(null), 4000);

    if (isPracticeMode) {
      startPracticeBot();
    } else {
      setMatchState('waiting');
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: 'next_stranger',
          country: selectedCountry,
          interests: selectedInterests,
          chatMode
        }));
      }
    }
  };

  // Stop current call
  const handleStopCall = () => {
    setMatchState('idle');
    setRemoteStream(null);
    setStranger(null);

    if (rtcClientRef.current) {
      rtcClientRef.current.close();
      rtcClientRef.current = null;
    }

    if (practiceBotRef.current) {
      practiceBotRef.current.stop();
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'stop_call'
      }));
    }
  };

  // Solo Practice Bot logic
  const startPracticeBot = async () => {
    if (chatMode === 'video') {
      await initUserMedia();
    }
    setMatchState('connecting');

    setTimeout(() => {
      sounds.playMatchFound();
      if (!practiceBotRef.current) {
        practiceBotRef.current = new PracticeBotEngine();
      }

      if (chatMode === 'video') {
        const botStream = practiceBotRef.current.getMediaStream();
        setRemoteStream(botStream);
      }

      setStranger({
        partnerId: 'solo_bot',
        country: 'Practice Bot AI',
        sharedInterests: selectedInterests.length > 0 ? selectedInterests : ['Gaming', 'Tech'],
        partnerInterests: ['Coding', 'Art', 'Music'],
        chatMode
      });
      setMatchState('connected');
      setMessages([
        {
          id: `bot_${Date.now()}`,
          sender: 'system',
          text: `Practice mode active (${chatMode === 'video' ? 'Video' : 'Text'}). Test conversations, reactions, and icebreakers freely.`,
          timestamp: Date.now()
        },
        {
          id: `bot_greet_${Date.now()}`,
          sender: 'stranger',
          text: "Hey! Nice to meet you. I'm your practice partner. What's on your mind today?",
          timestamp: Date.now()
        }
      ]);

      if (chatMode === 'video') {
        practiceBotRef.current.speakText("Hey! Nice to meet you. I'm your practice partner. What's on your mind today?");
      }
    }, 900);
  };

  const handleTogglePractice = () => {
    handleStopCall();
    setIsPracticeMode((prev) => !prev);
  };

  // Send message
  const handleSendMessage = (text: string) => {
    const newMsg: ChatMessage = {
      id: `my_${Date.now()}`,
      sender: 'me',
      text,
      timestamp: Date.now()
    };
    setMessages((prev) => [...prev, newMsg]);

    if (isPracticeMode && practiceBotRef.current) {
      // Bot conversational replies
      setTimeout(() => {
        setIsStrangerTyping(true);
        setTimeout(() => {
          setIsStrangerTyping(false);
          const botReplies = [
            `That's awesome! I totally agree with that.`,
            `Interesting point! How long have you been into that?`,
            `Haha so true! Tell me more about it!`,
            `Nice! If you could travel anywhere tomorrow, where would it be?`,
            `Cool! What do you like to do on weekends?`
          ];
          const reply = botReplies[Math.floor(Math.random() * botReplies.length)];
          setMessages((prev) => [
            ...prev,
            {
              id: `bot_${Date.now()}`,
              sender: 'stranger',
              text: reply,
              timestamp: Date.now()
            }
          ]);
          if (chatMode === 'video') {
            practiceBotRef.current?.speakText(reply);
          }
        }, 1200);
      }, 600);
      return;
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'chat_message',
        text
      }));
    }
  };

  // Send reaction emoji
  const handleSendReaction = (emoji: string) => {
    sounds.playReaction();
    const newReaction: FloatingReaction = {
      id: Math.random().toString(),
      emoji,
      x: 40 + Math.random() * 30,
      y: 60 + Math.random() * 20
    };
    setReactions((prev) => [...prev, newReaction]);
    setTimeout(() => {
      setReactions((prev) => prev.filter((r) => r.id !== newReaction.id));
    }, 2000);

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'send_reaction',
        emoji
      }));
    }
  };

  // Typing state
  const handleTypingChange = (isTyping: boolean) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'chat_typing',
        isTyping
      }));
    }
  };

  // Send icebreaker
  const handleSendIcebreaker = () => {
    if (isPracticeMode && practiceBotRef.current) {
      const sampleIcebreaker = "If you could teleport to any city in the world right now, where would you go?";
      setMessages((prev) => [
        ...prev,
        {
          id: `ice_${Date.now()}`,
          sender: 'system',
          text: `🎲 ICEBREAKER: ${sampleIcebreaker}`,
          timestamp: Date.now()
        }
      ]);
      setTimeout(() => {
        const reply = "I would teleport to Tokyo to get late-night ramen in Shibuya!";
        setMessages((prev) => [
          ...prev,
          {
            id: `bot_${Date.now()}`,
            sender: 'stranger',
            text: reply,
            timestamp: Date.now()
          }
        ]);
        if (chatMode === 'video') {
          practiceBotRef.current?.speakText(reply);
        }
      }, 1400);
      return;
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'send_icebreaker'
      }));
    }
  };

  // Toggle mic
  const handleToggleMic = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach((track) => {
        track.enabled = isMicMuted;
      });
      setIsMicMuted(!isMicMuted);
    }
  };

  // Toggle camera
  const handleToggleCamera = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach((track) => {
        track.enabled = isCameraOff;
      });
      setIsCameraOff(!isCameraOff);
    }
  };

  // Screen share
  const handleShareScreen = async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const screenTrack = screenStream.getVideoTracks()[0];
      if (screenTrack && localStream) {
        if (rtcClientRef.current) {
          rtcClientRef.current.updateLocalStream(screenStream);
        }
        screenTrack.onended = () => {
          if (localStream && rtcClientRef.current) {
            rtcClientRef.current.updateLocalStream(localStream);
          }
        };
      }
    } catch (err) {
      console.warn('Screen share canceled or denied:', err);
    }
  };

  // Report participant
  const handleReportStranger = (reason: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'report_stranger',
        reason
      }));
    }
    handleStopCall();
  };

  // Global hotkeys (Space to Next Stranger, Esc to Stop)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        if (matchState === 'connected' || matchState === 'disconnected') {
          handleNextStranger();
        } else if (matchState === 'idle') {
          handleStartMatching();
        }
      } else if (e.code === 'Escape') {
        e.preventDefault();
        handleStopCall();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [matchState, isPracticeMode, skipCount, adMobConfig]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* TOP BAR CONTRACT COMPLIANT NAVBAR */}
      <Navbar
        onOpenSafety={() => setIsSafetyOpen(true)}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        onOpenMonetization={() => setIsMonetizationOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onOpenDualTabTest={() => setIsDualTabTestOpen(true)}
        onOpenInterests={() => setIsInterestsOpen(true)}
        onTogglePractice={handleTogglePractice}
        isPracticeMode={isPracticeMode}
        onlineCount={stats.totalOnline}
      />

      {/* REWARD / BOOST NOTIFICATION */}
      {rewardNotice && (
        <div className="bg-emerald-950/90 border-b border-emerald-800 px-6 py-2 text-xs text-emerald-200 text-center font-semibold animate-in fade-in">
          {rewardNotice}
        </div>
      )}

      {/* MEDIA PERMISSION ALERT BANNER IF NEEDED */}
      {mediaError && chatMode === 'video' && (
        <div className="bg-amber-950/80 border-b border-amber-800 px-6 py-2.5 text-xs text-amber-200 flex items-center justify-between">
          <span>{mediaError}</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleChangeChatMode('text')}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded cursor-pointer"
            >
              Switch to Text Mode
            </button>
            <button
              onClick={() => initUserMedia()}
              className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded cursor-pointer"
            >
              Allow Camera
            </button>
          </div>
        </div>
      )}

      {/* MAIN TWO-COLUMN RESPONSIVE LAYOUT */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto p-4 sm:p-6 flex flex-col gap-4">
        {/* MATCH STATS & ACTIVE COUNTER STRIP */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 px-1">
          <div className="flex items-center gap-3">
            <span>
              Mode: <strong className="text-white capitalize">{chatMode} Match</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              Region: <strong className="text-slate-200">{selectedCountry}</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              Interests: <strong className="text-indigo-400">{selectedInterests.length > 0 ? selectedInterests.join(', ') : 'All Topics'}</strong>
            </span>
          </div>

          <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400 tabular-nums">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>Calls: <strong className="text-white">{stats.inCalls}</strong></span>
            </span>
            <span aria-hidden="true">·</span>
            <span>Text: <strong className="text-white">{stats.inTextChat}</strong></span>
            <span aria-hidden="true">·</span>
            <span>Queue: <strong className="text-white">{stats.inQueue}</strong></span>
          </div>
        </div>

        {/* WORKSPACE GRID: VIDEO STAGE (LEFT 65%) + LIVE CHAT (RIGHT 35%) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 min-h-[560px]">
          {/* VIDEO STAGE & CONTROLS (8 COLS) */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            <div className="flex-1 min-h-[420px] lg:min-h-[500px]">
              <VideoPlayer
                matchState={matchState}
                localStream={localStream}
                remoteStream={remoteStream}
                isMicMuted={isMicMuted}
                isCameraOff={isCameraOff}
                videoFilter={videoFilter}
                stranger={stranger}
                reactions={reactions}
                chatMode={chatMode}
                onChangeChatMode={handleChangeChatMode}
                onStartMatching={handleStartMatching}
                onNextStranger={handleNextStranger}
                onReportStranger={() => setIsReportOpen(true)}
                isLocalSpeaking={isLocalSpeaking}
                isRemoteSpeaking={isRemoteSpeaking}
                isPracticeMode={isPracticeMode}
              />
            </div>

            {/* CONTROLS BAR */}
            <ControlsBar
              matchState={matchState}
              isMicMuted={isMicMuted}
              isCameraOff={isCameraOff}
              videoFilter={videoFilter}
              soundEnabled={soundEnabled}
              chatMode={chatMode}
              onNext={handleNextStranger}
              onStop={handleStopCall}
              onStart={handleStartMatching}
              onToggleMic={handleToggleMic}
              onToggleCamera={handleToggleCamera}
              onSelectFilter={setVideoFilter}
              onToggleSound={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                sounds.enabled = next;
              }}
              onShareScreen={handleShareScreen}
              onSendIcebreaker={handleSendIcebreaker}
            />
          </div>

          {/* CHAT & ICEBREAKER PANEL (4 COLS) */}
          <div className="lg:col-span-4 h-full min-h-[380px] flex flex-col">
            <ChatBox
              messages={messages}
              matchState={matchState}
              isStrangerTyping={isStrangerTyping}
              onSendMessage={handleSendMessage}
              onSendReaction={handleSendReaction}
              onTypingChange={handleTypingChange}
              onNextStranger={handleNextStranger}
            />
          </div>
        </div>

        {/* ADMOB / GOOGLE ADSENSE MONETIZATION BANNER */}
        <AdMobBanner
          config={adMobConfig}
          onOpenMonetizationSettings={() => setIsMonetizationOpen(true)}
        />
      </main>

      {/* FOOTER WITH COMPLIANCE & PRIVACY LINKS */}
      <footer className="px-6 py-5 border-t border-slate-900 bg-slate-950/80 text-xs text-slate-500">
        <div className="max-w-[1440px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>
            StrangerSync · Free Anonymous Stranger Video Roulette with WebRTC & AI Safety Moderation.
          </p>
          <div className="flex items-center gap-4 text-xs text-slate-400">
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsSafetyOpen(true)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Safety Rules (18+)
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsMonetizationOpen(true)}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              AdMob Setup
            </button>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      <InterestsModal
        isOpen={isInterestsOpen}
        onClose={() => setIsInterestsOpen(false)}
        selectedInterests={selectedInterests}
        onChangeInterests={handleUpdateInterests}
        selectedCountry={selectedCountry}
        onChangeCountry={handleUpdateCountry}
      />

      <SafetyModal
        isOpen={isSafetyOpen}
        onClose={() => setIsSafetyOpen(false)}
      />

      <DualTabTestModal
        isOpen={isDualTabTestOpen}
        onClose={() => setIsDualTabTestOpen(false)}
      />

      <ReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        onSubmitReport={handleReportStranger}
      />

      <PrivacyPolicyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
      />

      <MonetizationSettingsModal
        isOpen={isMonetizationOpen}
        onClose={() => setIsMonetizationOpen(false)}
        config={adMobConfig}
        onSaveConfig={handleSaveAdMobConfig}
      />

      <InterstitialAdModal
        isOpen={isInterstitialOpen}
        config={adMobConfig}
        onClose={() => {
          setIsInterstitialOpen(false);
          handleInterstitialCompleted();
        }}
        onAdCompleted={handleInterstitialCompleted}
        reason="Supporting free server matchmaking"
      />

      {/* ADMOB APP OPEN AD */}
      <AppOpenAdModal
        isOpen={isAppOpenAdVisible}
        config={adMobConfig}
        onClose={() => setIsAppOpenAdVisible(false)}
      />

      {/* ANDROID APK EXPORT MODAL */}
      <ApkExportModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
        config={adMobConfig}
      />

      {/* GDPR / ADMOB COOKIE CONSENT BANNER */}
      <CookieConsentBanner onOpenPrivacy={() => setIsPrivacyOpen(true)} />
    </div>
  );
}
