// WebRTC Peer Connection Manager

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun3.l.google.com:19302' },
    { urls: 'stun:stun4.l.google.com:19302' }
  ],
  iceCandidatePoolSize: 10
};

export interface WebRTCClientCallbacks {
  onRemoteStream: (stream: MediaStream) => void;
  onIceCandidate: (candidate: RTCIceCandidate) => void;
  onConnectionStateChange: (state: RTCPeerConnectionState) => void;
}

export class WebRTCClient {
  private peerConnection: RTCPeerConnection | null = null;
  private remoteStream: MediaStream | null = null;
  private pendingCandidates: RTCIceCandidateInit[] = [];
  private callbacks: WebRTCClientCallbacks;

  constructor(callbacks: WebRTCClientCallbacks) {
    this.callbacks = callbacks;
  }

  public initConnection(localStream: MediaStream | null): RTCPeerConnection {
    this.close();

    this.peerConnection = new RTCPeerConnection(ICE_SERVERS);
    this.remoteStream = new MediaStream();
    this.pendingCandidates = [];

    // Add local tracks to peer connection (or recvonly transceivers so connection still negotiates)
    const addedKinds = new Set<string>();
    if (localStream) {
      localStream.getTracks().forEach((track) => {
        if (this.peerConnection && localStream) {
          this.peerConnection.addTrack(track, localStream);
          addedKinds.add(track.kind);
        }
      });
    }
    if (!addedKinds.has('audio')) {
      try {
        this.peerConnection.addTransceiver('audio', { direction: 'recvonly' });
      } catch {}
    }
    if (!addedKinds.has('video')) {
      try {
        this.peerConnection.addTransceiver('video', { direction: 'recvonly' });
      } catch {}
    }

    // Handle incoming remote media tracks
    this.peerConnection.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        this.callbacks.onRemoteStream(event.streams[0]);
      } else if (this.remoteStream) {
        this.remoteStream.addTrack(event.track);
        this.callbacks.onRemoteStream(this.remoteStream);
      }
    };

    // Handle ICE candidates
    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        this.callbacks.onIceCandidate(event.candidate);
      }
    };

    // Track connection state & ICE connection state for cross-browser reliability
    this.peerConnection.onconnectionstatechange = () => {
      if (this.peerConnection) {
        this.callbacks.onConnectionStateChange(this.peerConnection.connectionState);
      }
    };

    this.peerConnection.oniceconnectionstatechange = () => {
      if (!this.peerConnection) return;
      const iceState = this.peerConnection.iceConnectionState;
      if (iceState === 'connected' || iceState === 'completed') {
        this.callbacks.onConnectionStateChange('connected');
      } else if (iceState === 'failed') {
        this.callbacks.onConnectionStateChange('failed');
      }
    };

    return this.peerConnection;
  }

  public async createOffer(): Promise<RTCSessionDescriptionInit> {
    if (!this.peerConnection) {
      throw new Error('PeerConnection not initialized');
    }
    const offer = await this.peerConnection.createOffer({
      offerToReceiveAudio: true,
      offerToReceiveVideo: true
    });
    await this.peerConnection.setLocalDescription(offer);
    return offer;
  }

  public async handleOffer(offer: RTCSessionDescriptionInit): Promise<RTCSessionDescriptionInit> {
    if (!this.peerConnection) {
      throw new Error('PeerConnection not initialized');
    }
    await this.peerConnection.setRemoteDescription(new RTCSessionDescription(offer));

    // Process any queued ICE candidates
    while (this.pendingCandidates.length > 0) {
      const candidate = this.pendingCandidates.shift();
      if (candidate && this.peerConnection) {
        await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
      }
    }

    const answer = await this.peerConnection.createAnswer();
    await this.peerConnection.setLocalDescription(answer);
    return answer;
  }

  public async handleAnswer(answer: RTCSessionDescriptionInit): Promise<void> {
    if (!this.peerConnection) return;
    if (this.peerConnection.signalingState === 'have-local-offer') {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
    }

    // Process queued ICE candidates
    while (this.pendingCandidates.length > 0) {
      const candidate = this.pendingCandidates.shift();
      if (candidate && this.peerConnection) {
        await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
      }
    }
  }

  public async addIceCandidate(candidate: RTCIceCandidateInit): Promise<void> {
    if (!this.peerConnection || !this.peerConnection.remoteDescription) {
      this.pendingCandidates.push(candidate);
      return;
    }
    try {
      await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
    } catch (err) {
      console.warn('Error adding ICE candidate:', err);
    }
  }

  public updateLocalStream(newStream: MediaStream) {
    if (!this.peerConnection) return;

    const senders = this.peerConnection.getSenders();
    newStream.getTracks().forEach((track) => {
      const sender = senders.find((s) => s.track && s.track.kind === track.kind);
      if (sender) {
        sender.replaceTrack(track).catch((err) => console.warn('Error replacing track:', err));
      } else {
        this.peerConnection?.addTrack(track, newStream);
      }
    });
  }

  public close() {
    if (this.peerConnection) {
      this.peerConnection.ontrack = null;
      this.peerConnection.onicecandidate = null;
      this.peerConnection.onconnectionstatechange = null;
      this.peerConnection.oniceconnectionstatechange = null;
      this.peerConnection.close();
      this.peerConnection = null;
    }
    if (this.remoteStream) {
      this.remoteStream.getTracks().forEach((t) => t.stop());
      this.remoteStream = null;
    }
    this.pendingCandidates = [];
  }
}
