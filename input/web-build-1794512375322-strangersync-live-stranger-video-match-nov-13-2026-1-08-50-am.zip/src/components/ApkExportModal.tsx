import React, { useState } from 'react';
import { X, Smartphone, Download, Check, ShieldCheck, KeyRound, Sparkles } from 'lucide-react';
import { AdMobConfig } from '../types';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AdMobConfig;
}

export const ApkExportModal: React.FC<ApkExportModalProps> = ({
  isOpen,
  onClose,
  config,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'download' | 'signing' | 'instructions'>('download');

  // Optional non-sensitive signing metadata (never stores private passwords in ZIP)
  const [packageName, setPackageName] = useState('com.strangersync');
  const [keyAlias, setKeyAlias] = useState('strangersync-release-key');
  const [keystoreFilename, setKeystoreFilename] = useState('my-release-key.jks');

  if (!isOpen) return null;

  const safeAppId = config.appId || 'ca-app-pub-9670799162361917~4119297613';
  const safeAppOpenUnitId = config.appOpenUnitId || 'ca-app-pub-9670799162361917/9179393460';
  const safeBannerUnitId = config.bannerUnitId || 'ca-app-pub-9670799162361917/6300978111';
  const safePackage = packageName.trim() || 'com.strangersync';

  // Download complete APK-ready Android Studio project ZIP (includes bundled app assets + AdMob SDK + GitHub APK workflow)
  const handleDownloadAndroidProject = async () => {
    setIsGenerating(true);
    try {
      const serverUrl = typeof window !== 'undefined'
        ? window.location.origin
        : 'https://ais-pre-a7ozikrbtumsd7bsp3ecei-863895830917.asia-northeast1.run.app';

      const params = new URLSearchParams({
        packageName: safePackage,
        appId: safeAppId,
        appOpenUnitId: safeAppOpenUnitId,
        bannerUnitId: safeBannerUnitId,
        keyAlias: keyAlias || 'strangersync-release-key',
        keystore: keystoreFilename || 'my-release-key.jks',
        serverUrl,
      });

      const response = await fetch(`/api/download-android-zip?${params.toString()}`);
      if (!response.ok) throw new Error('Server ZIP export failed');
      const blob = await response.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = 'strangersync-android-apk-project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Error generating APK bundle:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Download original full project source code ZIP
  const handleDownloadOriginalSource = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/download-source-zip');
      if (!response.ok) throw new Error('Source ZIP export failed');
      const blob = await response.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = 'strangersync-original-source.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error('Error downloading source ZIP:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2 mb-2 text-indigo-400">
          <Smartphone size={24} />
          <h3 className="text-xl font-bold text-white">Convert to Native Android APK (.ZIP)</h3>
        </div>
        <p className="text-xs text-slate-400 mb-5 leading-relaxed">
          Download the complete Android Studio Gradle project (with bundled app files, native AdMob SDK, and GitHub Actions cloud APK workflow) or the original full source code ZIP.
        </p>

        {/* TABS */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl mb-4 border border-slate-800 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('download')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'download'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ZIP Downloads
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('signing')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'signing'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign With Your Key
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('instructions')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'instructions'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            AdMob IDs
          </button>
        </div>

        {activeTab === 'download' && (
          <div className="space-y-4 text-xs text-slate-300 overflow-y-auto pr-1">
            {/* CURRENT ADMOB STATUS BOX */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-white">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <ShieldCheck size={16} />
                  <span>Configured AdMob Units</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Bundled Offline Assets + Native Ads</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono mt-2">
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">App ID:</span>
                  <span className="text-slate-200 select-all">{safeAppId}</span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">App Open Ad Unit:</span>
                  <span className="text-indigo-300 select-all">{safeAppOpenUnitId}</span>
                </div>
              </div>
            </div>

            {/* DOWNLOAD ACTION CARD 1: ANDROID STUDIO APK-READY ZIP */}
            <div className="p-4 bg-gradient-to-br from-indigo-950/60 to-slate-950 rounded-xl border border-indigo-900/40 space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Sparkles size={16} className="text-indigo-400" />
                <span>1. Android Studio Project (.ZIP) — Ready for APK</span>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Bundles the compiled app inside <code className="text-indigo-300">assets/www/</code>, native <code className="text-indigo-300">MainActivity.java</code> with Google AdMob SDK, WebRTC permissions, release signing config, and <code className="text-indigo-300">.github/workflows/build-apk.yml</code> for cloud APK builds.
              </p>

              <button
                onClick={handleDownloadAndroidProject}
                disabled={isGenerating}
                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer text-xs"
              >
                {downloadSuccess ? (
                  <>
                    <Check size={16} className="text-emerald-300" />
                    <span>Android APK Project ZIP Downloaded!</span>
                  </>
                ) : isGenerating ? (
                  <span>Packaging Project ZIP...</span>
                ) : (
                  <>
                    <Download size={16} />
                    <span>Download Android APK Project (.ZIP)</span>
                  </>
                )}
              </button>
            </div>

            {/* DOWNLOAD ACTION CARD 2: ORIGINAL FULL SOURCE ZIP */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Download size={16} className="text-emerald-400" />
                <span>2. Original Full Source Code (.ZIP)</span>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Includes all original React + TypeScript + Express + WebSocket source files (<code className="text-slate-300">src/</code>, <code className="text-slate-300">server.ts</code>, <code className="text-slate-300">capacitor.config.json</code>) for Capacitor/Cordova or custom native conversion.
              </p>
              <button
                onClick={handleDownloadOriginalSource}
                disabled={isGenerating}
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl border border-slate-700 transition-all cursor-pointer text-xs"
              >
                <Download size={15} />
                <span>Download Original Source Code (.ZIP)</span>
              </button>
            </div>
          </div>
        )}

        {activeTab === 'signing' && (
          <div className="space-y-3 text-xs text-slate-300 overflow-y-auto max-h-[55vh] pr-1">
            <div className="p-3 bg-emerald-950/30 border border-emerald-800/50 rounded-xl flex items-start gap-2.5">
              <KeyRound size={16} className="text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-[11px] leading-relaxed">
                <strong className="text-emerald-300 block mb-0.5">Yes — sign locally with your own private keystore!</strong>
                Never upload your <code className="text-slate-200">.jks</code> or passwords online. Configure your package ID &amp; key alias below so the exported <code className="text-slate-200">build.gradle</code> and <code className="text-slate-200">keystore.properties.example</code> match your key, then sign locally in Android Studio or via <code className="text-slate-200">apksigner</code>.
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Android Package ID</label>
                <input
                  type="text"
                  value={packageName}
                  onChange={(e) => setPackageName(e.target.value)}
                  placeholder="com.strangersync"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Keystore File Name</label>
                <input
                  type="text"
                  value={keystoreFilename}
                  onChange={(e) => setKeystoreFilename(e.target.value)}
                  placeholder="my-release-key.jks"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Key Alias</label>
              <input
                type="text"
                value={keyAlias}
                onChange={(e) => setKeyAlias(e.target.value)}
                placeholder="strangersync-release-key"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-[11px]">
              <h4 className="font-bold text-white">Commands to sign with your key locally:</h4>
              <pre className="p-2.5 bg-slate-900 rounded-lg text-[10px] font-mono text-emerald-400 overflow-x-auto">
{`# 1. Generate a new key (skip if you already have a .jks key)
keytool -genkey -v -keystore ${keystoreFilename || 'my-release-key.jks'} \\
  -keyalg RSA -keysize 2048 -validity 10000 -alias ${keyAlias || 'strangersync-release-key'}

# 2. Or sign via Gradle after copying keystore.properties.example -> keystore.properties
./gradlew assembleRelease   # Signed APK
./gradlew bundleRelease     # Signed Play Store AAB`}
              </pre>
            </div>
          </div>
        )}

        {activeTab === 'instructions' && (
          <div className="space-y-4 text-xs text-slate-300 overflow-y-auto max-h-[50vh] pr-1">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <span className="text-slate-400 text-[10px] block font-sans">AndroidManifest.xml snippet:</span>
              <pre className="text-emerald-400 overflow-x-auto p-2 bg-slate-900 rounded">
{`<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="${safeAppId}"/>`}
              </pre>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <span className="text-slate-400 text-[10px] block font-sans">MainActivity.java App Open Ad Loader:</span>
              <pre className="text-indigo-300 overflow-x-auto p-2 bg-slate-900 rounded">
{`AppOpenAd.load(this, "${safeAppOpenUnitId}", request, callback);`}
              </pre>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-[11px]">
              <h4 className="font-bold text-white">Signed Release Build in Android Studio:</h4>
              <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1">
                <li>Download the ZIP from the <strong>Project Download</strong> tab.</li>
                <li>Open the extracted folder in Android Studio.</li>
                <li>Click <strong>Build &gt; Generate Signed App Bundle / APK</strong>.</li>
                <li>Select your own <code>.jks</code> / <code>.keystore</code> file and key alias to output a signed release APK or Google Play AAB.</li>
              </ol>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-3 mt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
