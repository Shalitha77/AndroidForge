import React from 'react';

interface NavbarProps {
  onOpenSafety: () => void;
  onOpenPrivacy: () => void;
  onOpenMonetization: () => void;
  onOpenApkModal: () => void;
  onOpenDualTabTest: () => void;
  onOpenInterests: () => void;
  onTogglePractice: () => void;
  isPracticeMode: boolean;
  onlineCount: number;
  isAdminMode?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenSafety,
  onOpenPrivacy,
  onOpenMonetization,
  onOpenApkModal,
  onOpenDualTabTest,
  onOpenInterests,
  onTogglePractice,
  isPracticeMode,
  onlineCount,
  isAdminMode = false,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-30">
      {/* Zone 1: Wordmark brand + Live Online counter */}
      <div className="flex items-center gap-3 shrink-0">
        <a href="/" className="text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0">
          StrangerSync
        </a>
        <div className="flex items-center text-xs text-slate-300 font-mono tabular-nums px-2.5 py-1 bg-slate-900/80 border border-slate-800 rounded-lg">
          <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block mr-1.5 animate-pulse" />
          <span className="font-semibold text-white">{onlineCount.toLocaleString()}</span>
          <span className="text-slate-400 ml-1">Online</span>
        </div>
      </div>

      {/* Zone 2: Clean single-line navigation links */}
      <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-300">
        <button
          onClick={onOpenInterests}
          className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          Match Interests
        </button>
        <button
          onClick={onOpenPrivacy}
          className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          Privacy Policy
        </button>
        <button
          onClick={onOpenSafety}
          className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          Safety & Rules
        </button>
        <button
          onClick={onOpenDualTabTest}
          className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          Dual-Tab Test
        </button>
        {isAdminMode && (
          <button
            onClick={onOpenMonetization}
            className="hover:text-emerald-400 text-emerald-400/90 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Owner AdMob
          </button>
        )}
      </nav>

      {/* Zone 3: 1 primary action (plus owner-only APK export when unlocked) */}
      <div className="flex items-center gap-2.5 shrink-0">
        {isAdminMode && (
          <button
            onClick={onOpenApkModal}
            className="hidden sm:flex items-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-emerald-300 hover:text-emerald-200 border border-emerald-800/60 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
            title="Download Android APK Project (Owner Only)"
          >
            <span>Android APK</span>
          </button>
        )}
        <button
          onClick={onTogglePractice}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
            isPracticeMode
              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20'
          }`}
        >
          {isPracticeMode ? 'Switch to Live Match' : 'Practice Solo Bot'}
        </button>
      </div>
    </header>
  );
};
