import React, { useState } from 'react';
import { ExternalLink, Info, Sparkles, Settings } from 'lucide-react';
import { AdMobConfig } from '../types';

interface AdMobBannerProps {
  config: AdMobConfig;
  onOpenMonetizationSettings: () => void;
  format?: 'banner' | 'leaderboard';
  isAdminMode?: boolean;
}

const SAMPLE_ADS = [
  {
    title: 'NordVPN Cyber Protection',
    tagline: 'Stay 100% anonymous & secure on public video chats. 70% off today.',
    cta: 'Secure Connection',
    link: 'https://nordvpn.com',
    badge: 'Cybersecurity',
    accent: 'from-blue-600 to-indigo-700'
  },
  {
    title: 'Razer BlackShark V2 Pro',
    tagline: 'Ultra-clear broadcast mic & spatial audio for crystal clear video calls.',
    cta: 'Explore Gear',
    link: 'https://razer.com',
    badge: 'Hardware',
    accent: 'from-emerald-600 to-teal-700'
  },
  {
    title: 'Duolingo English & Japanese',
    tagline: 'Practicing languages with strangers? Learn 40+ languages for free.',
    cta: 'Start Learning',
    link: 'https://duolingo.com',
    badge: 'Education',
    accent: 'from-amber-600 to-orange-700'
  }
];

export const AdMobBanner: React.FC<AdMobBannerProps> = ({
  config,
  onOpenMonetizationSettings,
  format = 'leaderboard',
  isAdminMode = false,
}) => {
  const [currentAdIndex, setCurrentAdIndex] = useState(0);

  if (!config.adsEnabled || config.vipAdFree) {
    return null;
  }

  const currentAd = SAMPLE_ADS[currentAdIndex];

  const handleNextAd = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentAdIndex((prev) => (prev + 1) % SAMPLE_ADS.length);
  };

  return (
    <div className="w-full my-2 flex flex-col items-center">
      {/* AD CONTAINER COMPLIANT WITH GOOGLE ADMOB POLICIES */}
      <div
        className={`w-full max-w-4xl bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-lg transition-all hover:border-slate-700 ${
          format === 'leaderboard' ? 'p-2.5 sm:p-3' : 'p-2'
        }`}
      >
        {/* COMPLIANCE LABEL ROW */}
        <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1.5 px-1">
          <div className="flex items-center gap-1.5">
            <span className="bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded font-semibold text-[9px] tracking-wider uppercase">
              Ad
            </span>
            <span>Sponsored</span>
            {isAdminMode && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-[9px] text-slate-500">
                  {config.testMode ? 'TEST MODE (ca-app-pub-3940256099942544/6300978111)' : config.publisherId}
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            {isAdminMode && (
              <button
                onClick={onOpenMonetizationSettings}
                className="hover:text-indigo-400 transition-colors flex items-center gap-1 cursor-pointer"
                title="Configure your AdMob Publisher & Ad Unit IDs (Owner Only)"
              >
                <Settings size={11} />
                <span className="hidden sm:inline">AdMob Setup</span>
              </button>
            )}
            <a
              href="https://support.google.com/admob/answer/7313578"
              target="_blank"
              rel="noreferrer"
              className="hover:text-slate-300 transition-colors"
              title="About Sponsored Ads"
            >
              <Info size={11} />
            </a>
          </div>
        </div>

        {/* AD CREATIVE BODY */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-2.5 bg-slate-950/70 rounded-lg border border-slate-800/80">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-lg bg-gradient-to-br ${currentAd.accent} flex items-center justify-center text-white shrink-0 shadow-md`}
            >
              <Sparkles size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight">
                  {currentAd.title}
                </h4>
                <span className="text-[10px] text-slate-400 border border-slate-800 px-1.5 py-0.2 rounded">
                  {currentAd.badge}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                {currentAd.tagline}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
            <button
              onClick={handleNextAd}
              className="text-[10px] text-slate-500 hover:text-slate-300 px-2 py-1 rounded transition-colors cursor-pointer"
              title="Rotate ad creative"
            >
              Rotate Ad
            </button>
            <a
              href={currentAd.link}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow-sm shadow-indigo-600/30 transition-all cursor-pointer whitespace-nowrap"
            >
              <span>{currentAd.cta}</span>
              <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
