import React, { useState, useEffect } from 'react';
import { X, Sparkles, Volume2, VolumeX, ExternalLink } from 'lucide-react';
import { AdMobConfig } from '../types';

interface InterstitialAdModalProps {
  isOpen: boolean;
  config: AdMobConfig;
  onClose: () => void;
  onAdCompleted: () => void;
  reason?: string;
}

export const InterstitialAdModal: React.FC<InterstitialAdModalProps> = ({
  isOpen,
  config,
  onClose,
  onAdCompleted,
  reason = 'Support Free Stranger Video Matching',
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState(5);
  const [canSkip, setCanSkip] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  useEffect(() => {
    if (!isOpen) {
      setSecondsRemaining(5);
      setCanSkip(false);
      return;
    }

    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setCanSkip(true);
          onAdCompleted();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, onAdCompleted]);

  if (!isOpen || !config.adsEnabled || config.vipAdFree) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden relative flex flex-col">
        {/* HEADER BAR */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950/90 border-b border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 px-1.5 py-0.5 rounded text-[10px] font-bold uppercase">
              Sponsored Ad
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
            >
              {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
            </button>

            {canSkip ? (
              <button
                onClick={onClose}
                className="flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition-all cursor-pointer"
              >
                <span>Skip Ad</span>
                <X size={14} />
              </button>
            ) : (
              <div className="px-2.5 py-1 bg-slate-800/80 text-slate-300 rounded-lg text-[11px] font-mono">
                Reward in {secondsRemaining}s
              </div>
            )}
          </div>
        </div>

        {/* AD CREATIVE MEDIA */}
        <div className="relative aspect-video bg-gradient-to-br from-indigo-950 via-slate-900 to-violet-950 flex flex-col items-center justify-center p-6 text-center overflow-hidden">
          {/* Animated decorative backdrop */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(99,102,241,0.25),transparent)] pointer-events-none" />

          <div className="w-16 h-16 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400 mb-3 shadow-lg shadow-indigo-600/20">
            <Sparkles size={32} />
          </div>

          <h3 className="text-lg sm:text-xl font-extrabold text-white mb-1">
            Global Connect Ultra VPN
          </h3>
          <p className="text-xs text-slate-300 max-w-sm mb-4 leading-relaxed">
            Ultra low-latency video streaming, zero data logging, and worldwide servers. Instant match unlock.
          </p>

          <a
            href="https://google.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-400 hover:to-violet-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-500/30 transition-all cursor-pointer"
          >
            <span>Learn More & Install</span>
            <ExternalLink size={14} />
          </a>
        </div>

        {/* REWARD BENEFIT FOOTER */}
        <div className="p-4 bg-slate-950 flex items-center justify-between border-t border-slate-800 text-xs">
          <div>
            <span className="text-slate-400 text-[11px]">Reason: {reason}</span>
            <p className="text-emerald-400 font-medium text-[11px]">
              {canSkip ? '✓ Match Priority Boost Unlocked!' : 'Watching supports free server infrastructure'}
            </p>
          </div>

          {canSkip && (
            <button
              onClick={onClose}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
            >
              Continue to Match
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
