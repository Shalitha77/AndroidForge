import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || 3000;

const app = express();
app.use(express.json());

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

interface ClientInfo {
  ws: WebSocket;
  id: string;
  username: string;
  country: string;
  interests: string[];
  chatMode: 'video' | 'text';
  currentRoomId: string | null;
  partnerId: string | null;
  lastMatchedWith: string | null;
  joinedAt: number;
}

interface Room {
  id: string;
  user1Id: string;
  user2Id: string;
  chatMode: 'video' | 'text';
  createdAt: number;
}

const clients = new Map<string, ClientInfo>();
const waitingQueue = new Set<string>();
const activeRooms = new Map<string, Room>();

const CURATED_ICEBREAKERS = [
  "What's the most spontaneous thing you've ever done?",
  "If you could teleport to any city in the world right now, where would you go?",
  "What's a weird food combination you secretly love?",
  "Show me the nearest object on your desk and tell the story behind it!",
  "What song have you had on repeat lately?",
  "If you could have dinner with anyone dead or alive, who?",
  "What is your all-time favorite movie or show?",
  "Are you a night owl or an early bird, and why?",
  "What's one skill you really want to learn in 2026?",
  "Coffee, tea, or energy drinks?",
  "If you could master any musical instrument overnight, which one?",
  "What's the best travel memory you have?",
  "Cats, dogs, or exotic pets?",
  "What's your unpopular opinion that you will defend forever?",
  "If you could design a video game, what genre would it be?",
  "Tell me two truths and one lie — let me guess the lie!",
  "What is the funniest rumor you ever heard about yourself?",
  "What superpower would be the most convenient for daily life?"
];

function broadcastStats() {
  let inCallsCount = 0;
  let inTextChatCount = 0;
  for (const r of activeRooms.values()) {
    if (r.chatMode === 'video') inCallsCount += 2;
    else inTextChatCount += 2;
  }

  const stats = {
    type: 'stats_update',
    totalOnline: Math.max(clients.size, 1),
    inCalls: inCallsCount,
    inTextChat: inTextChatCount,
    inQueue: waitingQueue.size,
    timestamp: Date.now()
  };

  const payload = JSON.stringify(stats);
  for (const client of clients.values()) {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(payload);
    }
  }
}

function findMatchFor(userId: string): string | null {
  const client = clients.get(userId);
  if (!client) return null;

  let bestCandidateId: string | null = null;
  let maxScore = -1;

  for (const candidateId of waitingQueue) {
    if (candidateId === userId) continue;
    const candidate = clients.get(candidateId);
    if (!candidate) continue;

    // Both must match requested chat mode (video vs text)
    if (candidate.chatMode !== client.chatMode) continue;

    // Avoid immediate rematch with the exact same person if others in queue
    if (client.lastMatchedWith === candidateId && waitingQueue.size > 2) {
      continue;
    }

    // Count shared interests
    const shared = client.interests.filter(tag => candidate.interests.includes(tag));
    let score = shared.length * 10;
    if (candidate.country === client.country && client.country !== 'Global') {
      score += 5;
    }

    if (score > maxScore) {
      maxScore = score;
      bestCandidateId = candidateId;
    }
  }

  // Fallback to any waiting client with the same chatMode
  if (!bestCandidateId) {
    for (const candidateId of waitingQueue) {
      if (candidateId !== userId) {
        const candidate = clients.get(candidateId);
        if (candidate && candidate.chatMode === client.chatMode) {
          bestCandidateId = candidateId;
          break;
        }
      }
    }
  }

  return bestCandidateId;
}

function pairUsers(user1Id: string, user2Id: string) {
  const user1 = clients.get(user1Id);
  const user2 = clients.get(user2Id);
  if (!user1 || !user2) return;

  waitingQueue.delete(user1Id);
  waitingQueue.delete(user2Id);

  const roomId = `room_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const chatMode = user1.chatMode;
  const room: Room = {
    id: roomId,
    user1Id,
    user2Id,
    chatMode,
    createdAt: Date.now()
  };
  activeRooms.set(roomId, room);

  user1.currentRoomId = roomId;
  user1.partnerId = user2Id;
  user1.lastMatchedWith = user2Id;

  user2.currentRoomId = roomId;
  user2.partnerId = user1Id;
  user2.lastMatchedWith = user1Id;

  const sharedInterests = user1.interests.filter(i => user2.interests.includes(i));

  // User 1 is designated caller (will initiate WebRTC offer if video mode)
  if (user1.ws.readyState === WebSocket.OPEN) {
    user1.ws.send(JSON.stringify({
      type: 'match_found',
      roomId,
      isCaller: true,
      partnerId: user2.id,
      partnerCountry: user2.country,
      sharedInterests,
      partnerInterests: user2.interests,
      chatMode
    }));
  }

  // User 2 is callee (will await WebRTC offer if video mode)
  if (user2.ws.readyState === WebSocket.OPEN) {
    user2.ws.send(JSON.stringify({
      type: 'match_found',
      roomId,
      isCaller: false,
      partnerId: user1.id,
      partnerCountry: user1.country,
      sharedInterests,
      partnerInterests: user1.interests,
      chatMode
    }));
  }

  broadcastStats();
}

function leaveRoom(userId: string, reason: 'skipped' | 'disconnected' | 'left' = 'left') {
  const client = clients.get(userId);
  if (!client || !client.currentRoomId) return;

  const roomId = client.currentRoomId;
  const partnerId = client.partnerId;
  activeRooms.delete(roomId);

  client.currentRoomId = null;
  client.partnerId = null;

  if (partnerId) {
    const partner = clients.get(partnerId);
    if (partner) {
      partner.currentRoomId = null;
      partner.partnerId = null;
      if (partner.ws.readyState === WebSocket.OPEN) {
        partner.ws.send(JSON.stringify({
          type: 'stranger_disconnected',
          reason
        }));
      }
    }
  }

  broadcastStats();
}

wss.on('connection', (ws) => {
  let clientId = `usr_${Math.random().toString(36).substring(2, 9)}`;

  const clientInfo: ClientInfo = {
    ws,
    id: clientId,
    username: 'Stranger',
    country: 'Global',
    interests: [],
    chatMode: 'video',
    currentRoomId: null,
    partnerId: null,
    lastMatchedWith: null,
    joinedAt: Date.now()
  };

  clients.set(clientId, clientInfo);

  // Send greeting and connection confirmation
  ws.send(JSON.stringify({
    type: 'connected',
    userId: clientId,
    totalOnline: clients.size,
    inQueue: waitingQueue.size
  }));

  broadcastStats();

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());

      switch (msg.type) {
        case 'set_profile': {
          clientInfo.country = msg.country || 'Global';
          clientInfo.interests = Array.isArray(msg.interests) ? msg.interests : [];
          if (msg.chatMode) clientInfo.chatMode = msg.chatMode;
          if (msg.username) clientInfo.username = msg.username;
          break;
        }

        case 'join_queue': {
          // If already in a room, leave it first
          if (clientInfo.currentRoomId) {
            leaveRoom(clientId, 'skipped');
          }
          waitingQueue.delete(clientId);

          clientInfo.country = msg.country || clientInfo.country;
          clientInfo.interests = Array.isArray(msg.interests) ? msg.interests : clientInfo.interests;
          if (msg.chatMode) clientInfo.chatMode = msg.chatMode;

          const matchPartnerId = findMatchFor(clientId);
          if (matchPartnerId) {
            pairUsers(clientId, matchPartnerId);
          } else {
            waitingQueue.add(clientId);
            ws.send(JSON.stringify({
              type: 'queue_status',
              status: 'waiting',
              queueLength: waitingQueue.size
            }));
            broadcastStats();
          }
          break;
        }

        case 'leave_queue': {
          waitingQueue.delete(clientId);
          ws.send(JSON.stringify({
            type: 'queue_status',
            status: 'idle'
          }));
          broadcastStats();
          break;
        }

        case 'next_stranger': {
          leaveRoom(clientId, 'skipped');
          waitingQueue.delete(clientId);
          if (msg.country) clientInfo.country = msg.country;
          if (Array.isArray(msg.interests)) clientInfo.interests = msg.interests;
          if (msg.chatMode) clientInfo.chatMode = msg.chatMode;

          // Re-enter matchmaking queue immediately
          const matchPartnerId = findMatchFor(clientId);
          if (matchPartnerId) {
            pairUsers(clientId, matchPartnerId);
          } else {
            waitingQueue.add(clientId);
            ws.send(JSON.stringify({
              type: 'queue_status',
              status: 'waiting',
              queueLength: waitingQueue.size
            }));
            broadcastStats();
          }
          break;
        }

        case 'stop_call': {
          leaveRoom(clientId, 'left');
          waitingQueue.delete(clientId);
          ws.send(JSON.stringify({
            type: 'call_stopped'
          }));
          broadcastStats();
          break;
        }

        case 'webrtc_offer': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'webrtc_offer',
                sdp: msg.sdp
              }));
            }
          }
          break;
        }

        case 'webrtc_answer': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'webrtc_answer',
                sdp: msg.sdp
              }));
            }
          }
          break;
        }

        case 'ice_candidate': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'ice_candidate',
                candidate: msg.candidate
              }));
            }
          }
          break;
        }

        case 'chat_message': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'chat_message',
                sender: 'stranger',
                text: msg.text,
                timestamp: Date.now()
              }));
            }
          }
          break;
        }

        case 'chat_typing': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'chat_typing',
                isTyping: !!msg.isTyping
              }));
            }
          }
          break;
        }

        case 'send_icebreaker': {
          const prompt = msg.prompt || CURATED_ICEBREAKERS[Math.floor(Math.random() * CURATED_ICEBREAKERS.length)];
          // Send to sender
          ws.send(JSON.stringify({
            type: 'icebreaker_prompt',
            prompt,
            initiatedByMe: true
          }));
          // Send to partner
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'icebreaker_prompt',
                prompt,
                initiatedByMe: false
              }));
            }
          }
          break;
        }

        case 'send_reaction': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'reaction_received',
                emoji: msg.emoji,
                id: Math.random().toString(36).substring(2, 8)
              }));
            }
          }
          break;
        }

        case 'report_stranger': {
          // Immediately disconnect pair and log report
          console.warn(`[REPORT] User ${clientId} reported stranger in room ${clientInfo.currentRoomId}. Reason: ${msg.reason}`);
          leaveRoom(clientId, 'left');
          ws.send(JSON.stringify({
            type: 'report_acknowledged',
            message: 'Thank you for keeping StrangerSync safe. The user has been disconnected.'
          }));
          break;
        }
      }
    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  (ws as WebSocket & { isAlive?: boolean }).isAlive = true;
  ws.on('pong', () => {
    (ws as WebSocket & { isAlive?: boolean }).isAlive = true;
  });

  ws.on('close', () => {
    waitingQueue.delete(clientId);
    leaveRoom(clientId, 'disconnected');
    clients.delete(clientId);
    broadcastStats();
  });
});

// Sweep dead WebSocket connections so nobody matches with a stale ghost user
const heartbeatInterval = setInterval(() => {
  let removed = false;
  for (const [id, client] of clients.entries()) {
    const sock = client.ws as WebSocket & { isAlive?: boolean };
    if (sock.isAlive === false) {
      waitingQueue.delete(id);
      leaveRoom(id, 'disconnected');
      clients.delete(id);
      sock.terminate();
      removed = true;
      continue;
    }
    sock.isAlive = false;
    if (sock.readyState === WebSocket.OPEN) {
      sock.ping();
    }
  }
  if (removed) {
    broadcastStats();
  }
}, 25000);

wss.on('close', () => {
  clearInterval(heartbeatInterval);
});

// REST API endpoints
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    online: clients.size,
    inQueue: waitingQueue.size,
    activeCalls: activeRooms.size
  });
});

app.get('/api/icebreakers', (_req, res) => {
  res.json({ icebreakers: CURATED_ICEBREAKERS });
});

function addDirectoryToZip(zip: JSZip, localDir: string, zipPrefix: string, excludeDirs = new Set(['node_modules', '.git', 'dist'])) {
  if (!fs.existsSync(localDir)) return;
  const entries = fs.readdirSync(localDir, { withFileTypes: true });
  for (const entry of entries) {
    if (excludeDirs.has(entry.name)) continue;
    const fullPath = path.join(localDir, entry.name);
    const targetPath = zipPrefix ? `${zipPrefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      addDirectoryToZip(zip, fullPath, targetPath, excludeDirs);
    } else if (entry.isFile()) {
      zip.file(targetPath, fs.readFileSync(fullPath));
    }
  }
}

// Download complete APK-ready Android Studio Gradle project ZIP (bundles built app into assets/www)
app.get('/api/download-android-zip', async (req, res) => {
  try {
    const rawPkg = typeof req.query.packageName === 'string' ? req.query.packageName : 'com.strangersync';
    const safePackage = rawPkg.replace(/[^a-zA-Z0-9_.]/g, '') || 'com.strangersync';
    const packagePath = safePackage.replace(/\./g, '/');

    const rawAppId = typeof req.query.appId === 'string' ? req.query.appId : 'ca-app-pub-9670799162361917~4119297613';
    const safeAppId = rawAppId.replace(/[^a-zA-Z0-9~/_-]/g, '') || 'ca-app-pub-9670799162361917~4119297613';

    const rawAppOpen = typeof req.query.appOpenUnitId === 'string' ? req.query.appOpenUnitId : 'ca-app-pub-9670799162361917/9179393460';
    const safeAppOpenUnitId = rawAppOpen.replace(/[^a-zA-Z0-9~/_-]/g, '') || 'ca-app-pub-9670799162361917/9179393460';

    const rawBanner = typeof req.query.bannerUnitId === 'string' ? req.query.bannerUnitId : 'ca-app-pub-9670799162361917/6300978111';
    const safeBannerUnitId = rawBanner.replace(/[^a-zA-Z0-9~/_-]/g, '') || 'ca-app-pub-9670799162361917/6300978111';

    const rawAlias = typeof req.query.keyAlias === 'string' ? req.query.keyAlias : 'strangersync-release-key';
    const keyAlias = rawAlias.replace(/[^a-zA-Z0-9._-]/g, '') || 'strangersync-release-key';

    const rawKeystore = typeof req.query.keystore === 'string' ? req.query.keystore : 'my-release-key.jks';
    const keystoreFilename = rawKeystore.replace(/[^a-zA-Z0-9._-]/g, '') || 'my-release-key.jks';

    const hostHeader = req.get('host') || 'ais-pre-a7ozikrbtumsd7bsp3ecei-863895830917.asia-northeast1.run.app';
    const defaultServerUrl = hostHeader.includes('localhost')
      ? 'https://ais-pre-a7ozikrbtumsd7bsp3ecei-863895830917.asia-northeast1.run.app'
      : `https://${hostHeader}`;
    const serverUrl = typeof req.query.serverUrl === 'string' && req.query.serverUrl.startsWith('http')
      ? req.query.serverUrl
      : defaultServerUrl;

    const zip = new JSZip();

    // Bundle compiled app from dist/ into app/src/main/assets/www/
    const distDir = path.join(__dirname, 'dist');
    const hasBundledDist = fs.existsSync(path.join(distDir, 'index.html'));
    if (hasBundledDist) {
      addDirectoryToZip(zip, distDir, 'app/src/main/assets/www', new Set());
    }

    const startUrl = hasBundledDist
      ? `https://appassets.androidplatform.net/assets/www/index.html?androidApp=1&server=${encodeURIComponent(serverUrl)}`
      : `${serverUrl}?androidApp=1`;

    // AndroidManifest.xml
    zip.file('app/src/main/AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
    <uses-feature android:name="android.hardware.microphone" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.StrangerSync"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="false">

        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="${safeAppId}" />

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`);

    // MainActivity.java
    zip.file(`app/src/main/java/${packagePath}/MainActivity.java`, `package ${safePackage};

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private AppOpenAd appOpenAd;
    private AdView bannerAdView;
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final String APP_OPEN_AD_UNIT = "${safeAppOpenUnitId}";
    private static final String BANNER_AD_UNIT = "${safeBannerUnitId}";
    private static final String START_URL = "${startUrl}";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
            }, PERMISSION_REQUEST_CODE);
        }

        MobileAds.initialize(this, initializationStatus -> {
            loadAppOpenAd();
            loadBannerAd();
        });

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        webView.loadUrl(START_URL);
    }

    private void loadAppOpenAd() {
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(this, APP_OPEN_AD_UNIT, request, new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull AppOpenAd ad) {
                appOpenAd = ad;
                appOpenAd.show(MainActivity.this);
            }
        });
    }

    private void loadBannerAd() {
        FrameLayout adContainer = findViewById(R.id.ad_container);
        bannerAdView = new AdView(this);
        bannerAdView.setAdUnitId(BANNER_AD_UNIT);
        bannerAdView.setAdSize(AdSize.BANNER);
        adContainer.removeAllViews();
        adContainer.addView(bannerAdView);
        bannerAdView.loadAd(new AdRequest.Builder().build());
    }

    @Override
    protected void onDestroy() {
        if (bannerAdView != null) bannerAdView.destroy();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
`);

    // Layout XML
    zip.file('app/src/main/res/layout/activity_main.xml', `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:background="#020617">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1" />

    <FrameLayout
        android:id="@+id/ad_container"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="#020617" />
</LinearLayout>
`);

    // Resources
    zip.file('app/src/main/res/values/strings.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">StrangerSync</string>
</resources>
`);

    zip.file('app/src/main/res/values/themes.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.StrangerSync" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="android:statusBarColor">#020617</item>
        <item name="android:navigationBarColor">#020617</item>
    </style>
</resources>
`);

    zip.file('app/src/main/res/drawable/ic_launcher.xml', `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path android:fillColor="#4F46E5" android:pathData="M0,0h108v108h-108z"/>
    <path android:fillColor="#FFFFFF" android:pathData="M34,38h28c4.4,0 8,3.6 8,8v16c0,4.4 -3.6,8 -8,8H34c-4.4,0 -8,-3.6 -8,-8V46C26,41.6 29.6,38 34,38zM72,49l12,-9v28l-12,-9V49z"/>
</vector>
`);

    // Gradle configs
    zip.file('app/build.gradle', `import java.util.Properties

plugins {
    id 'com.android.application'
}

def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file("keystore.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    namespace '${safePackage}'
    compileSdk 34

    defaultConfig {
        applicationId "${safePackage}"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
            }
        }
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            if (keystorePropertiesFile.exists()) {
                signingConfig signingConfigs.release
            }
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'androidx.webkit:webkit:1.11.0'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'com.google.android.gms:play-services-ads:23.6.0'
}
`);

    zip.file('app/proguard-rules.pro', `-keep class com.google.android.gms.ads.** { *; }
`);

    zip.file('build.gradle', `plugins {
    id 'com.android.application' version '8.5.2' apply false
}
`);

    zip.file('settings.gradle', `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "StrangerSync"
include ':app'
`);

    zip.file('gradle.properties', `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
`);

    zip.file('gradle/wrapper/gradle-wrapper.properties', `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`);

    zip.file('keystore.properties.example', `# Rename to keystore.properties to sign your release APK/AAB locally
storeFile=../${keystoreFilename}
storePassword=YOUR_STORE_PASSWORD
keyAlias=${keyAlias}
keyPassword=YOUR_KEY_PASSWORD
`);

    // GitHub Actions workflow so the user can also build APK in the cloud without Android Studio
    zip.file('.github/workflows/build-apk.yml', `name: Build Android APK
on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'
      - name: Build Debug APK
        run: gradle assembleDebug
      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: StrangerSync-debug-apk
          path: app/build/outputs/apk/debug/*.apk
`);

    zip.file('README.md', `# StrangerSync Native Android Project

This archive contains a complete Android Studio Gradle project with the compiled app bundled locally in \`app/src/main/assets/www/\`, WebRTC permissions, and Google AdMob SDK integration.

## Configured IDs
- Package Name: \`${safePackage}\`
- AdMob App ID: \`${safeAppId}\`
- App Open Ad Unit: \`${safeAppOpenUnitId}\`
- Banner Ad Unit: \`${safeBannerUnitId}\`
- Matchmaking Backend: \`${serverUrl}\`

## Build an APK (2 Ways)
1. **Android Studio**: Extract ZIP -> Open in Android Studio -> **Build > Generate Signed App Bundle / APK...** -> Select your \`.jks\` keystore and alias (\`${keyAlias}\`).
2. **GitHub Actions (No PC Setup Needed)**: Upload this folder to a GitHub repo -> Open the **Actions** tab -> Run **Build Android APK** -> Download \`StrangerSync-debug-apk\`.
`);

    const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="strangersync-android-apk-project.zip"');
    res.send(buffer);
  } catch (err) {
    console.error('Error building Android ZIP:', err);
    res.status(500).json({ error: 'Failed to generate Android ZIP' });
  }
});

// Download original full project source code ZIP (including Capacitor config for CLI conversion)
app.get('/api/download-source-zip', async (_req, res) => {
  try {
    const zip = new JSZip();

    const rootFiles = ['package.json', 'tsconfig.json', 'vite.config.ts', 'index.html', 'metadata.json', 'server.ts', '.env.example'];
    for (const file of rootFiles) {
      const p = path.join(__dirname, file);
      if (fs.existsSync(p)) {
        zip.file(file, fs.readFileSync(p));
      }
    }

    addDirectoryToZip(zip, path.join(__dirname, 'src'), 'src', new Set());
    addDirectoryToZip(zip, path.join(__dirname, 'public'), 'public', new Set());

    // Ready-to-use Capacitor config for converting this source project into Android APK
    zip.file('capacitor.config.json', JSON.stringify({
      appId: 'com.strangersync',
      appName: 'StrangerSync',
      webDir: 'dist',
      server: {
        androidScheme: 'https'
      }
    }, null, 2));

    zip.file('CONVERT_TO_APK.md', `# Convert Original Source to Android APK

1. Extract this ZIP and run:
   \`\`\`bash
   npm install
   npm run build
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap add android
   npx cap sync android
   npx cap open android
   \`\`\`
2. Or download the pre-built Android Studio project ZIP directly from \`/api/download-android-zip\`.
`);

    const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="strangersync-original-source.zip"');
    res.send(buffer);
  } catch (err) {
    console.error('Error building Source ZIP:', err);
    res.status(500).json({ error: 'Failed to generate source ZIP' });
  }
});

// Mount Vite middleware in development, or serve dist in production
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, () => {
    console.log(`StrangerSync server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
