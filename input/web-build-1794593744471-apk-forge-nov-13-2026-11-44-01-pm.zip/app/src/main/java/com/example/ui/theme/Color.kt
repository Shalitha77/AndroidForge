package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Precision Forge Studio Palette - Obsidian Slate + Emerald Circuit + Forge Amber
val StudioEmerald = Color(0xFF10B981)
val StudioEmeraldBright = Color(0xFF34D399)
val StudioEmeraldDim = Color(0xFF059669)
val StudioEmeraldContainerDark = Color(0xFF064E3B)
val StudioEmeraldOnContainerDark = Color(0xFFA7F3D0)

val ForgeAmber = Color(0xFFF59E0B)
val ForgeAmberSoft = Color(0xFFFBBF24)
val ForgeAmberContainerDark = Color(0xFF451A03)
val ForgeAmberOnContainerDark = Color(0xFFFDE68A)

val StudioCyan = Color(0xFF22D3EE)
val StudioCyanContainerDark = Color(0xFF083344)
val StudioCyanOnContainerDark = Color(0xFFA5F3FC)

val ObsidianBg = Color(0xFF0B1017)
val ObsidianSurface = Color(0xFF121923)
val ObsidianSurfaceVariant = Color(0xFF1B2432)
val ObsidianSurfaceElevated = Color(0xFF222D3D)
val ObsidianOutline = Color(0xFF303D52)
val ObsidianOutlineVariant = Color(0xFF232D3E)

val StudioTextPrimary = Color(0xFFF1F5F9)
val StudioTextSecondary = Color(0xFF94A3B8)

val ForgeErrorDark = Color(0xFFF87171)
val ForgeErrorContainerDark = Color(0xFF450A0A)
val ForgeOnErrorContainerDark = Color(0xFFFECACA)

// Light Theme equivalents for high contrast daylight readability
val LightBg = Color(0xFFF4F7F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6EDF3)
val LightOutline = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightEmerald = Color(0xFF047857)
val LightEmeraldContainer = Color(0xFFD1FAE5)
val LightAmber = Color(0xFFB45309)
val LightAmberContainer = Color(0xFFFEF3C7)
val LightCyan = Color(0xFF0E7490)
val LightCyanContainer = Color(0xFFCFFAFE)
