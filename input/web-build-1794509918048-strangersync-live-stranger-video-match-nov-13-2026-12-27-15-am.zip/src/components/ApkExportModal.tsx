import React, { useState } from 'react';
import { X, Smartphone, Download, Check, ShieldCheck, KeyRound, Sparkles } from 'lucide-react';
import JSZip from 'jszip';
import { AdMobConfig } from '../types';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AdMobConfig;
}

export const ApkExportModal: React.FC<ApkExportModalProps> = ({
  isOpen,
  onClose,
  config,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'download' | 'signing' | 'instructions'>('download');

  // Optional non-sensitive signing metadata (never stores private passwords in ZIP)
  const [packageName, setPackageName] = useState('com.strangersync.app');
  const [keyAlias, setKeyAlias] = useState('strangersync-release-key');
  const [keystoreFilename, setKeystoreFilename] = useState('my-release-key.jks');

  if (!isOpen) return null;

  const safeAppId = config.appId || 'ca-app-pub-9670799162361917~4119297613';
  const safeAppOpenUnitId = config.appOpenUnitId || 'ca-app-pub-9670799162361917/9179393460';
  const safePackage = packageName.trim() || 'com.strangersync.app';
  const packagePath = safePackage.replace(/\./g, '/');

  // Generate and download full Android Studio project ZIP with signing template
  const handleDownloadAndroidProject = async () => {
    setIsGenerating(true);
    try {
      const zip = new JSZip();
      const appUrl = typeof window !== 'undefined'
        ? window.location.origin
        : 'https://ais-pre-a7ozikrbtumsd7bsp3ecei-863895830917.asia-northeast1.run.app';

      // 1. AndroidManifest.xml
      const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
    <uses-feature android:name="android.hardware.microphone" android:required="false" />

    <application
        android:allowBackup="true"
        android:label="StrangerSync"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.DayNight.NoActionBar"
        android:hardwareAccelerated="true">

        <!-- Google AdMob Application ID -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="${safeAppId}" />

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

      // 2. MainActivity.java with Google Mobile Ads SDK & App Open Ad
      const mainActivityJava = `package ${safePackage};

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private AppOpenAd appOpenAd;
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final String APP_OPEN_AD_UNIT = "${safeAppOpenUnitId}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Request Android runtime Camera & Microphone permissions for WebRTC
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
            }, PERMISSION_REQUEST_CODE);
        }

        // 1. Initialize Google Mobile Ads SDK
        MobileAds.initialize(this, initializationStatus -> loadAppOpenAd());

        // 2. Setup WebView with WebRTC & Camera permissions
        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("${appUrl}");
    }

    private void loadAppOpenAd() {
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(this, APP_OPEN_AD_UNIT, request, new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(AppOpenAd ad) {
                appOpenAd = ad;
                appOpenAd.show(MainActivity.this);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}`;

      // 3. app/build.gradle with release signingConfig reading from keystore.properties
      const buildGradle = `import java.util.Properties

plugins {
    id 'com.android.application'
}

def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file("keystore.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    namespace '${safePackage}'
    compileSdk 34

    defaultConfig {
        applicationId "${safePackage}"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
            }
        }
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            if (keystorePropertiesFile.exists()) {
                signingConfig signingConfigs.release
            }
        }
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    // Google AdMob SDK
    implementation 'com.google.android.gms:play-services-ads:23.6.0'
}`;

      // 4. keystore.properties.example (safe template for user's own signing key)
      const keystorePropertiesExample = `# Rename this file to keystore.properties (never commit real passwords to git!)
# Place your .jks or .keystore file in the project root or provide its absolute path.
storeFile=../${keystoreFilename || 'my-release-key.jks'}
storePassword=YOUR_STORE_PASSWORD
keyAlias=${keyAlias || 'strangersync-release-key'}
keyPassword=YOUR_KEY_PASSWORD
`;

      // 5. Root settings.gradle & build.gradle
      const settingsGradle = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "StrangerSync"
include ':app'
`;

      const rootBuildGradle = `plugins {
    id 'com.android.application' version '8.5.2' apply false
}
`;

      const proguardRules = `-keep class com.google.android.gms.ads.** { *; }
`;

      // 6. README with signing instructions using user's own key
      const readmeMd = `# StrangerSync Android APK / Play Store Project
Configured with Google AdMob:
- Package Name: ${safePackage}
- App ID: ${safeAppId}
- App Open Ad Unit ID: ${safeAppOpenUnitId}

## How to Sign & Build Release APK / AAB Using Your Own Key:

### Option A: Android Studio GUI (Recommended)
1. Extract this ZIP and open the folder in **Android Studio**.
2. Click **Build > Generate Signed App Bundle / APK...**
3. Choose **APK** (for direct install) or **Android App Bundle (AAB)** (for Google Play Store).
4. Click **Choose existing...** and select your \`.jks\` / \`.keystore\` file (or **Create new...** to generate a new key).
5. Enter your key alias (\`${keyAlias || 'strangersync-release-key'}\`) and passwords, select **release**, and click **Create**.

### Option B: Command Line with \`keystore.properties\`
1. Copy \`keystore.properties.example\` to \`keystore.properties\` and fill in your keystore path, alias, and passwords.
2. Run \`./gradlew assembleRelease\` (for signed APK) or \`./gradlew bundleRelease\` (for Play Store AAB).
3. Your signed output will be in \`app/build/outputs/apk/release/app-release.apk\`.

### Option C: Sign an existing unsigned APK with \`apksigner\`
\`\`\`bash
apksigner sign --ks ${keystoreFilename || 'my-release-key.jks'} --ks-key-alias ${keyAlias || 'strangersync-release-key'} --out app-release-signed.apk app-release-unsigned.apk
\`\`\`
`;

      // 7. Layout XML
      const activityMainXml = `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>`;

      // Add files to ZIP
      zip.file('README.md', readmeMd);
      zip.file('settings.gradle', settingsGradle);
      zip.file('build.gradle', rootBuildGradle);
      zip.file('keystore.properties.example', keystorePropertiesExample);
      zip.file('app/build.gradle', buildGradle);
      zip.file('app/proguard-rules.pro', proguardRules);
      zip.file('app/src/main/AndroidManifest.xml', manifestXml);
      zip.file(`app/src/main/java/${packagePath}/MainActivity.java`, mainActivityJava);
      zip.file('app/src/main/res/layout/activity_main.xml', activityMainXml);

      // Generate zip blob
      const content = await zip.generateAsync({ type: 'blob' });
      const downloadUrl = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `strangersync-android-admob-signed-ready.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Error generating APK bundle:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2 mb-2 text-indigo-400">
          <Smartphone size={24} />
          <h3 className="text-xl font-bold text-white">Android APK & Release Signing</h3>
        </div>
        <p className="text-xs text-slate-400 mb-5 leading-relaxed">
          Export the Android Studio project with your AdMob App Open IDs and pre-wired release <code className="text-slate-300">signingConfigs</code> so you can sign the APK/AAB with your own keystore key.
        </p>

        {/* TABS */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl mb-4 border border-slate-800 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('download')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'download'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Project Download
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('signing')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'signing'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign With Your Key
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('instructions')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'instructions'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            AdMob IDs
          </button>
        </div>

        {activeTab === 'download' && (
          <div className="space-y-4 text-xs text-slate-300 overflow-y-auto pr-1">
            {/* CURRENT ADMOB STATUS BOX */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-white">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <ShieldCheck size={16} />
                  <span>Configured AdMob Units</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Signing-Ready Bundle</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono mt-2">
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">App ID:</span>
                  <span className="text-slate-200 select-all">{safeAppId}</span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">App Open Ad Unit:</span>
                  <span className="text-indigo-300 select-all">{safeAppOpenUnitId}</span>
                </div>
              </div>
            </div>

            {/* DOWNLOAD ACTION CARD */}
            <div className="p-4 bg-gradient-to-br from-indigo-950/60 to-slate-950 rounded-xl border border-indigo-900/40 space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Sparkles size={16} className="text-indigo-400" />
                <span>Complete Android Studio Project Bundle (.ZIP)</span>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Includes <code className="text-indigo-300">AndroidManifest.xml</code>, <code className="text-indigo-300">MainActivity.java</code> with Google Mobile Ads SDK, runtime WebRTC permissions, <code className="text-indigo-300">app/build.gradle</code> signing setup, and <code className="text-indigo-300">keystore.properties.example</code>.
              </p>

              <button
                onClick={handleDownloadAndroidProject}
                disabled={isGenerating}
                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer text-xs"
              >
                {downloadSuccess ? (
                  <>
                    <Check size={16} className="text-emerald-300" />
                    <span>Android Project ZIP Downloaded!</span>
                  </>
                ) : isGenerating ? (
                  <span>Generating Android Project...</span>
                ) : (
                  <>
                    <Download size={16} />
                    <span>Download Android Studio Project (.ZIP)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'signing' && (
          <div className="space-y-3 text-xs text-slate-300 overflow-y-auto max-h-[55vh] pr-1">
            <div className="p-3 bg-emerald-950/30 border border-emerald-800/50 rounded-xl flex items-start gap-2.5">
              <KeyRound size={16} className="text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-[11px] leading-relaxed">
                <strong className="text-emerald-300 block mb-0.5">Yes — sign locally with your own private keystore!</strong>
                Never upload your <code className="text-slate-200">.jks</code> or passwords online. Configure your package ID &amp; key alias below so the exported <code className="text-slate-200">build.gradle</code> and <code className="text-slate-200">keystore.properties.example</code> match your key, then sign locally in Android Studio or via <code className="text-slate-200">apksigner</code>.
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Android Package ID</label>
                <input
                  type="text"
                  value={packageName}
                  onChange={(e) => setPackageName(e.target.value)}
                  placeholder="com.strangersync.app"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Keystore File Name</label>
                <input
                  type="text"
                  value={keystoreFilename}
                  onChange={(e) => setKeystoreFilename(e.target.value)}
                  placeholder="my-release-key.jks"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Key Alias</label>
              <input
                type="text"
                value={keyAlias}
                onChange={(e) => setKeyAlias(e.target.value)}
                placeholder="strangersync-release-key"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-[11px]">
              <h4 className="font-bold text-white">Commands to sign with your key locally:</h4>
              <pre className="p-2.5 bg-slate-900 rounded-lg text-[10px] font-mono text-emerald-400 overflow-x-auto">
{`# 1. Generate a new key (skip if you already have a .jks key)
keytool -genkey -v -keystore ${keystoreFilename || 'my-release-key.jks'} \\
  -keyalg RSA -keysize 2048 -validity 10000 -alias ${keyAlias || 'strangersync-release-key'}

# 2. Or sign via Gradle after copying keystore.properties.example -> keystore.properties
./gradlew assembleRelease   # Signed APK
./gradlew bundleRelease     # Signed Play Store AAB`}
              </pre>
            </div>
          </div>
        )}

        {activeTab === 'instructions' && (
          <div className="space-y-4 text-xs text-slate-300 overflow-y-auto max-h-[50vh] pr-1">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <span className="text-slate-400 text-[10px] block font-sans">AndroidManifest.xml snippet:</span>
              <pre className="text-emerald-400 overflow-x-auto p-2 bg-slate-900 rounded">
{`<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="${safeAppId}"/>`}
              </pre>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <span className="text-slate-400 text-[10px] block font-sans">MainActivity.java App Open Ad Loader:</span>
              <pre className="text-indigo-300 overflow-x-auto p-2 bg-slate-900 rounded">
{`AppOpenAd.load(this, "${safeAppOpenUnitId}", request, callback);`}
              </pre>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-[11px]">
              <h4 className="font-bold text-white">Signed Release Build in Android Studio:</h4>
              <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1">
                <li>Download the ZIP from the <strong>Project Download</strong> tab.</li>
                <li>Open the extracted folder in Android Studio.</li>
                <li>Click <strong>Build &gt; Generate Signed App Bundle / APK</strong>.</li>
                <li>Select your own <code>.jks</code> / <code>.keystore</code> file and key alias to output a signed release APK or Google Play AAB.</li>
              </ol>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-3 mt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
