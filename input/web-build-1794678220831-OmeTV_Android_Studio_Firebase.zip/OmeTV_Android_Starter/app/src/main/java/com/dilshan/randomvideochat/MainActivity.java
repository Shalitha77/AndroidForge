package com.dilshan.randomvideochat;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends AppCompatActivity {
    private TextView status;
    private Button startButton;
    private boolean searching = false;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        initializeServices();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(0xFF10111A);

        TextView logo = new TextView(this);
        logo.setText("◉  RANDOM CHAT");
        logo.setTextColor(0xFFFFFFFF);
        logo.setTextSize(25);
        logo.setGravity(Gravity.CENTER);
        logo.setTypeface(null, 1);
        root.addView(logo, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Meet new people around the world");
        subtitle.setTextColor(0xFFB8B8C8);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.topMargin = 12;
        root.addView(subtitle, subParams);

        TextView preview = new TextView(this);
        preview.setText("VIDEO PREVIEW\n\nCamera and live video matching will appear here");
        preview.setTextColor(0xFFDADAE5);
        preview.setTextSize(16);
        preview.setGravity(Gravity.CENTER);
        preview.setBackgroundColor(0xFF252638);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        previewParams.topMargin = 32;
        previewParams.bottomMargin = 24;
        root.addView(preview, previewParams);

        status = new TextView(this);
        status.setText("Ready to meet someone?");
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        root.addView(status, matchWrap());

        startButton = new Button(this);
        startButton.setText("START CHAT");
        startButton.setAllCaps(false);
        LinearLayout.LayoutParams buttonParams = matchWrap();
        buttonParams.topMargin = 18;
        root.addView(startButton, buttonParams);

        Button safety = new Button(this);
        safety.setText("Safety & Community Rules");
        safety.setAllCaps(false);
        root.addView(safety, matchWrap());
        safety.setOnClickListener(v -> new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Stay safe")
                .setMessage("Never share passwords, financial details, or your home address. End a chat and report anyone who behaves inappropriately. This starter app does not yet include a live report service.")
                .setPositiveButton("OK", null).show());

        TextView footer = new TextView(this);
        footer.setText("Be respectful • Be safe • Have fun");
        footer.setTextColor(0xFF8D8DA0);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerParams = matchWrap();
        footerParams.topMargin = 14;
        root.addView(footer, footerParams);

        setContentView(root);
        startButton.setOnClickListener(v -> toggleSearch());
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void initializeServices() {
        try {
            FirebaseApp.initializeApp(this);
            auth = FirebaseAuth.getInstance();
            if (auth.getCurrentUser() == null) {
                auth.signInAnonymously().addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Toast.makeText(this,
                                "Firebase setup required. See README.",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
        } catch (Exception e) {
            Toast.makeText(this, "Add your Firebase configuration to enable sign-in.",
                    Toast.LENGTH_LONG).show();
        }

        MobileAds.initialize(this, initializationStatus -> { });
    }

    private void toggleSearch() {
        if (!searching) {
            searching = true;
            status.setText("Searching for a partner…");
            startButton.setText("CANCEL");
            Toast.makeText(this,
                    "Demo screen only: connect a matchmaking and WebRTC server to enable real calls.",
                    Toast.LENGTH_LONG).show();
        } else {
            searching = false;
            status.setText("Search cancelled. Ready when you are.");
            startButton.setText("START CHAT");
        }
    }
}
