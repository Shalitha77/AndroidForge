# Random Video Chat — Android Studio starter

This is a native Android Studio **starter project** for an OmeTV-style random video chat app. It includes:
- Native Android home screen and basic search/cancel interaction
- Firebase anonymous-auth initialization hook
- Firebase Firestore dependency for future matchmaking/signaling
- Google Mobile Ads SDK with Google's **sample app ID** (test/development only)
- Camera and microphone permissions declared
- Basic safety notice

## Important: what is not implemented yet
This ZIP is a starter, **not a finished working video-chat service**. Real stranger-to-stranger video calls need:
1. A matchmaking/signaling backend (Firestore alone needs carefully designed secure rules and signaling logic).
2. WebRTC media implementation on both clients.
3. A TURN server for reliable calls across mobile networks/NATs.
4. Camera/microphone runtime permission flow, call lifecycle, disconnect handling.
5. Reporting, blocking, moderation, age-safety controls, and abuse response.
Do not publish this demo as a functioning video-chat app.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `OmeTV_Android_Starter` folder in Android Studio.
3. Allow Gradle sync. Use JDK 17 with Android Gradle Plugin 8.7.3.
4. Connect an Android phone and run the `app` configuration.

## Firebase setup
1. Create a project at https://console.firebase.google.com/
2. Add an Android app with package name `com.dilshan.randomvideochat`.
3. Download `google-services.json`.
4. Put it in the `app/` folder (same level as `build.gradle.kts`).
5. In Firebase Authentication, enable **Anonymous** sign-in.
6. Create a Firestore database and configure restrictive security rules before using it.

The project intentionally does not include a Firebase config file or credentials.

## AdMob setup
The manifest currently uses Google's official sample app ID for development. Replace it with your own AdMob app ID only after the app is correctly configured. Use Google's test ad unit IDs while testing. Never click your own live ads. AdMob approval and policy compliance are not guaranteed.

## Package name
`com.dilshan.randomvideochat`

To change it, update `namespace`, `applicationId`, the Java package declaration, and folder path consistently.
