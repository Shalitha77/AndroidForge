import JSZip from 'jszip';

const rawModules = import.meta.glob('/android-studio-project/**/*', {
  query: '?raw',
  import: 'default',
  eager: true,
}) as Record<string, string>;

export type FileCategory =
  | 'kotlin-ui'
  | 'webrtc-ads'
  | 'firebase'
  | 'gradle-manifest'
  | 'docs';

export interface ProjectFile {
  path: string;
  name: string;
  content: string;
  category: FileCategory;
  lines: number;
}

function classifyFile(path: string): FileCategory {
  if (path.includes('/firebase/') || path.includes('/data/')) return 'firebase';
  if (path.includes('/webrtc/') || path.includes('/ads/')) return 'webrtc-ads';
  if (
    path.endsWith('.kts') ||
    path.endsWith('.toml') ||
    path.endsWith('.pro') ||
    path.endsWith('.properties') ||
    path.endsWith('.properties.example') ||
    path.endsWith('AndroidManifest.xml') ||
    path.endsWith('.template') ||
    path.includes('/res/')
  ) {
    return 'gradle-manifest';
  }
  if (path.includes('/docs/')) return 'docs';
  return 'kotlin-ui';
}

export const PROJECT_FILES: ProjectFile[] = Object.entries(rawModules)
  .map(([fullPath, content]) => {
    const cleanPath = fullPath.replace(/^\/android-studio-project\//, '');
    const parts = cleanPath.split('/');
    return {
      path: cleanPath,
      name: parts[parts.length - 1],
      content,
      category: classifyFile(cleanPath),
      lines: content.split('\n').length,
    };
  })
  .sort((a, b) => a.path.localeCompare(b.path));

export async function downloadAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();
  const rootFolder = zip.folder('RandomTalk-Android');
  if (!rootFolder) return;

  for (const file of PROJECT_FILES) {
    rootFolder.file(file.path, file.content);
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'random-talk-android-studio.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
