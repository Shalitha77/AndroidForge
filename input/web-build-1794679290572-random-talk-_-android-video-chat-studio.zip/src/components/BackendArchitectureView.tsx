import React, { useState } from 'react';
import { Database, Lock, Radio, Server, ShieldAlert } from 'lucide-react';

interface BackendArchitectureViewProps {
  onJumpToFile: (pathFragment: string) => void;
}

const RTDB_NODES = [
  {
    path: '/stats/online_count',
    access: 'Auth read · Server-only write',
    purpose: 'Maintained automatically by onPresenceChanged Cloud Function so clients see accurate online counts without reading /presence.',
  },
  {
    path: '/presence/{uid}',
    access: 'Owner read/write · onDisconnect().removeValue()',
    purpose: 'Tracks active WebSocket sessions using .info/connected and removes disconnected users immediately.',
  },
  {
    path: '/users/{uid}/blocked/{targetUid}',
    access: 'Owner read/write · Self-block disallowed',
    purpose: 'Personal block list checked atomically by findRandomMatch before pairing two users.',
  },
  {
    path: '/blocked_by/{targetUid}/{blockerUid}',
    access: 'Blocker write · Server read',
    purpose: 'Reverse index enabling O(1) bidirectional block filtering during Cloud Function matchmaking.',
  },
  {
    path: '/matchmaking_queue/{uid}',
    access: 'Owner read/write · Banned users blocked',
    purpose: 'Holds countryCode, selfGender, preferredGender, and WAITING/MATCHED status with onDisconnect cleanup.',
  },
  {
    path: '/call_rooms/{roomId}/signals',
    access: 'Room participants only',
    purpose: 'Stores ephemeral WebRTC SDP offer, SDP answer, and ICE candidates under /candidates/{uid}.',
  },
  {
    path: '/reports/{reportId}',
    access: 'Create-only (reporterUid == auth.uid)',
    purpose: 'Triggers onReportCreated Cloud Function to flag or auto-ban accounts exceeding abuse thresholds.',
  },
];

export const BackendArchitectureView: React.FC<BackendArchitectureViewProps> = ({
  onJumpToFile,
}) => {
  const [selectedNode, setSelectedNode] = useState(RTDB_NODES[0]);

  return (
    <div className="space-y-8">
      {/* WebRTC + Signaling Sequence */}
      <div className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-xl font-bold tracking-tight">
              Real-Time WebRTC &amp; Atomic Matchmaking Pipeline
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              End-to-end encrypted DTLS-SRTP media with Firebase App Check, STUN/TURN traversal, and automatic ICE restart.
            </p>
          </div>
          <button
            onClick={() => onJumpToFile('WebRtcClient.kt')}
            className="px-4 py-2 rounded-lg bg-slate-900 dark:bg-sky-600 text-white text-xs font-semibold whitespace-nowrap shrink-0"
          >
            Inspect WebRtcClient.kt
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            {
              step: '01. Auth & App Check',
              icon: Lock,
              detail: 'Firebase Anonymous or Google Credential Manager login protected by Play Integrity App Check.',
              file: 'AuthRepository.kt',
            },
            {
              step: '02. Atomic Pairing',
              icon: Server,
              detail: 'findRandomMatch Cloud Function runs a transaction on partner queue node, blocking duplicates & blocked pairs.',
              file: 'functions/src/index.ts',
            },
            {
              step: '03. STUN & Ephemeral TURN',
              icon: Radio,
              detail: 'getTurnCredentials issues 1-hour HMAC-SHA1 coturn credentials alongside Google STUN servers.',
              file: 'IceServerProvider.kt',
            },
            {
              step: '04. ICE Restart & Low BW',
              icon: ShieldAlert,
              detail: 'Monitors IceConnectionState for automatic ICE restart and caps RtpSender to 250 kbps / 15 fps when enabled.',
              file: 'VideoCallViewModel.kt',
            },
          ].map((item) => (
            <div
              key={item.step}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 flex flex-col justify-between gap-3"
            >
              <div>
                <item.icon className="w-5 h-5 text-sky-600 dark:text-sky-400 mb-2.5" />
                <div className="text-sm font-semibold">{item.step}</div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed">
                  {item.detail}
                </p>
              </div>
              <button
                onClick={() => onJumpToFile(item.file)}
                className="text-left text-xs font-mono text-sky-600 dark:text-sky-400 hover:underline"
              >
                {item.file} →
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Firebase RTDB Schema Explorer */}
      <div className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
        <div className="lg:col-span-5 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 p-5">
          <div className="flex items-center gap-2 mb-4">
            <Database className="w-4 h-4 text-sky-600 dark:text-sky-400" />
            <h3 className="text-base font-bold">Firebase Realtime Database Nodes</h3>
          </div>
          <div className="space-y-1.5">
            {RTDB_NODES.map((node) => {
              const active = selectedNode.path === node.path;
              return (
                <button
                  key={node.path}
                  onClick={() => setSelectedNode(node)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-mono transition-colors ${
                    active
                      ? 'bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 font-semibold'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {node.path}
                </button>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-7 p-6 flex flex-col justify-between gap-4">
          <div className="space-y-3">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Selected Node Contract
            </div>
            <div className="text-lg font-mono font-bold text-slate-900 dark:text-white">
              {selectedNode.path}
            </div>
            <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              Security Rule: {selectedNode.access}
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed pt-1">
              {selectedNode.purpose}
            </p>
          </div>

          <div className="flex flex-wrap gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => onJumpToFile('database.rules.json')}
              className="px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              View database.rules.json
            </button>
            <button
              onClick={() => onJumpToFile('functions/src/index.ts')}
              className="px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              View Cloud Functions
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
