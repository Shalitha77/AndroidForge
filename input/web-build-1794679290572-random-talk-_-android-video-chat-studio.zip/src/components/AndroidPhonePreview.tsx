import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Ban,
  Camera,
  Check,
  ChevronRight,
  Flag,
  Globe,
  Mic,
  MicOff,
  PhoneOff,
  RefreshCw,
  Settings,
  Shield,
  SkipForward,
  Sparkles,
  Sun,
  Moon,
  Users,
  Video,
  VideoOff,
  Wifi,
} from 'lucide-react';
import remoteCallerImg from '../assets/images/caller_remote_clean_1794676625918.jpg';
import localPipImg from '../assets/images/caller_local_pip_1794676612477.jpg';

export type PreviewScreen =
  | 'age_gate'
  | 'home'
  | 'video_call'
  | 'interstitial'
  | 'settings'
  | 'legal';

export interface PreviewInspectorState {
  screen: PreviewScreen;
  callPhase: 'searching' | 'signaling' | 'connected' | 'reconnecting';
  androidDark: boolean;
  country: string;
  gender: string;
  lowBandwidth: boolean;
  micMuted: boolean;
  cameraOn: boolean;
  isFrontCam: boolean;
}

interface AndroidPhonePreviewProps {
  onStateChange: (state: PreviewInspectorState) => void;
  onJumpToFile: (pathFragment: string) => void;
}

const COUNTRIES = [
  { code: 'GLOBAL', label: 'Global (Worldwide)', flag: '🌐' },
  { code: 'US', label: 'United States', flag: '🇺🇸' },
  { code: 'GB', label: 'United Kingdom', flag: '🇬🇧' },
  { code: 'JP', label: 'Japan', flag: '🇯🇵' },
  { code: 'DE', label: 'Germany', flag: '🇩🇪' },
  { code: 'BR', label: 'Brazil', flag: '🇧🇷' },
];

const GENDERS = ['Everyone', 'Female', 'Male', 'Non-binary'];

export const AndroidPhonePreview: React.FC<AndroidPhonePreviewProps> = ({
  onStateChange,
  onJumpToFile,
}) => {
  const [screen, setScreen] = useState<PreviewScreen>('home');
  const [androidDark, setAndroidDark] = useState(true);
  const [ageChecked, setAgeChecked] = useState(true);
  const [guidelinesChecked, setGuidelinesChecked] = useState(true);

  const [country, setCountry] = useState(COUNTRIES[0]);
  const [gender, setGender] = useState('Everyone');
  const [showCountrySheet, setShowCountrySheet] = useState(false);
  const [showGenderSheet, setShowGenderSheet] = useState(false);

  const [callPhase, setCallPhase] = useState<
    'searching' | 'signaling' | 'connected' | 'reconnecting'
  >('searching');
  const [micMuted, setMicMuted] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [isFrontCam, setIsFrontCam] = useState(true);
  const [lowBandwidth, setLowBandwidth] = useState(false);
  const [showReportSheet, setShowReportSheet] = useState(false);
  const [reportReason, setReportReason] = useState('Harassment or Bullying');
  const [reportToast, setReportToast] = useState<string | null>(null);
  const [completedCalls, setCompletedCalls] = useState(0);
  const [afterInterstitialTarget, setAfterInterstitialTarget] = useState<
    'home' | 'video_call'
  >('video_call');
  const [legalTitle, setLegalTitle] = useState('Privacy Policy');
  const [googleLinked, setGoogleLinked] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  useEffect(() => {
    onStateChange({
      screen,
      callPhase,
      androidDark,
      country: country.label,
      gender,
      lowBandwidth,
      micMuted,
      cameraOn,
      isFrontCam,
    });
  }, [
    screen,
    callPhase,
    androidDark,
    country,
    gender,
    lowBandwidth,
    micMuted,
    cameraOn,
    isFrontCam,
    onStateChange,
  ]);

  // Simulate authentic matchmaking -> WebRTC SDP/ICE progression inside preview
  useEffect(() => {
    if (screen !== 'video_call') return;
    setCallPhase('searching');
    const t1 = window.setTimeout(() => setCallPhase('signaling'), 900);
    const t2 = window.setTimeout(() => setCallPhase('connected'), 1800);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [screen]);

  const handleNextUser = () => {
    const nextCount = completedCalls + 1;
    setCompletedCalls(nextCount);
    if (callPhase === 'connected' && nextCount % 2 === 0) {
      setAfterInterstitialTarget('video_call');
      setScreen('interstitial');
    } else {
      setCallPhase('searching');
      window.setTimeout(() => setCallPhase('signaling'), 800);
      window.setTimeout(() => setCallPhase('connected'), 1600);
    }
  };

  const handleEndCall = () => {
    const nextCount = completedCalls + 1;
    setCompletedCalls(nextCount);
    if (callPhase === 'connected' && nextCount % 2 === 0) {
      setAfterInterstitialTarget('home');
      setScreen('interstitial');
    } else {
      setScreen('home');
    }
  };

  const submitReport = () => {
    setShowReportSheet(false);
    setReportToast('Reported & blocked. Matching next partner...');
    setCallPhase('searching');
    window.setTimeout(() => {
      setReportToast(null);
      setCallPhase('connected');
    }, 1500);
  };

  const phoneSurface = androidDark
    ? 'bg-slate-950 text-slate-50'
    : 'bg-slate-50 text-slate-900';
  const cardSurface = androidDark
    ? 'bg-slate-900 border-slate-800 text-slate-100'
    : 'bg-white border-slate-200 text-slate-900';
  const mutedText = androidDark ? 'text-slate-400' : 'text-slate-600';

  return (
    <div className="flex flex-col items-center">
      {/* Quick Screen Switcher above device */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 mb-4 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
        {(
          [
            { id: 'age_gate', label: '18+ Gate' },
            { id: 'home', label: 'Home' },
            { id: 'video_call', label: 'Video Call' },
            { id: 'settings', label: 'Settings' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            onClick={() => setScreen(item.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              screen === item.id
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {item.label}
          </button>
        ))}
        <button
          onClick={() => setAndroidDark((prev) => !prev)}
          aria-label="Toggle Android device theme"
          className="px-2.5 py-1.5 text-xs font-medium rounded-md text-slate-600 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-slate-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          {androidDark ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
          <span>{androidDark ? 'Dark' : 'Light'}</span>
        </button>
      </div>

      {/* Pixel-style Android Device Frame */}
      <div className="relative w-[340px] h-[690px] rounded-[40px] border-[8px] border-slate-800 dark:border-slate-700 bg-slate-950 shadow-2xl overflow-hidden flex flex-col">
        {/* Android Status Bar */}
        <div
          className={`h-7 px-5 flex items-center justify-between text-[11px] font-medium shrink-0 ${
            screen === 'video_call' || screen === 'interstitial'
              ? 'bg-slate-950 text-white'
              : phoneSurface
          }`}
        >
          <span className="tabular-nums">09:16</span>
          <div className="w-16 h-3.5 rounded-full bg-black/80 border border-slate-800" />
          <div className="flex items-center gap-1.5 tabular-nums">
            <Wifi className="w-3 h-3" />
            <span>5G</span>
          </div>
        </div>

        {/* Screen Viewport */}
        <div className={`relative flex-1 overflow-hidden flex flex-col ${phoneSurface}`}>
          {screen === 'age_gate' && (
            <div className="flex-1 flex flex-col justify-between p-5 overflow-y-auto">
              <div>
                <div className="w-10 h-10 rounded-xl bg-sky-600/15 text-sky-500 flex items-center justify-center mb-3">
                  <Shield className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold tracking-tight">Welcome to Random Talk</h3>
                <p className={`text-xs mt-1.5 leading-relaxed ${mutedText}`}>
                  Global peer-to-peer WebRTC video chat. Confirm age and community standards before connecting.
                </p>

                <div className={`mt-4 p-3.5 rounded-2xl border text-xs space-y-1.5 ${cardSurface}`}>
                  <div className="font-semibold">Safety Commitments</div>
                  <p className={mutedText}>• Strictly 18+ only. Underage users are banned.</p>
                  <p className={mutedText}>• Zero nudity, harassment, or spam tolerance.</p>
                  <p className={mutedText}>• P2P WebRTC video is never recorded on servers.</p>
                </div>

                <div className="mt-4 space-y-2.5 text-xs">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={ageChecked}
                      onChange={(e) => setAgeChecked(e.target.checked)}
                      className="mt-0.5 rounded border-slate-400"
                    />
                    <span>I confirm that I am at least 18 years old.</span>
                  </label>
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={guidelinesChecked}
                      onChange={(e) => setGuidelinesChecked(e.target.checked)}
                      className="mt-0.5 rounded border-slate-400"
                    />
                    <span>I accept the Community Guidelines &amp; Privacy Policy.</span>
                  </label>
                </div>
              </div>

              <button
                disabled={!ageChecked || !guidelinesChecked}
                onClick={() => setScreen('home')}
                className="w-full py-3 rounded-xl bg-sky-600 disabled:opacity-40 text-white text-xs font-semibold transition-opacity"
              >
                Continue to Random Talk
              </button>
            </div>
          )}

          {screen === 'home' && (
            <div className="flex-1 flex flex-col justify-between overflow-y-auto">
              <div className="p-4 space-y-4">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white">
                      <Video className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-bold leading-tight">Random Talk</div>
                      <div className={`text-[11px] flex items-center gap-1 tabular-nums ${mutedText}`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                        <span>14,820 online</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setScreen('settings')}
                    aria-label="Open Settings"
                    className={`w-9 h-9 rounded-lg flex items-center justify-center border ${cardSurface}`}
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </div>

                <div>
                  <h3 className="text-xl font-bold tracking-tight leading-snug">
                    Meet someone new face to face
                  </h3>
                  <p className={`text-xs mt-1 leading-relaxed ${mutedText}`}>
                    Encrypted WebRTC video matching across countries. Tap Start when ready.
                  </p>
                </div>

                {/* Country & Gender Filters */}
                <div className={`rounded-2xl border divide-y ${cardSurface} ${androidDark ? 'divide-slate-800' : 'divide-slate-100'}`}>
                  <button
                    onClick={() => setShowCountrySheet(true)}
                    className="w-full px-3.5 py-3 flex items-center justify-between text-left"
                  >
                    <div className="flex items-center gap-2.5">
                      <Globe className="w-4 h-4 text-sky-500" />
                      <div>
                        <div className={`text-[10px] ${mutedText}`}>Country</div>
                        <div className="text-xs font-semibold">
                          {country.flag} {country.label}
                        </div>
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 ${mutedText}`} />
                  </button>

                  <button
                    onClick={() => setShowGenderSheet(true)}
                    className="w-full px-3.5 py-3 flex items-center justify-between text-left"
                  >
                    <div className="flex items-center gap-2.5">
                      <Users className="w-4 h-4 text-sky-500" />
                      <div>
                        <div className={`text-[10px] ${mutedText}`}>Match Preference</div>
                        <div className="text-xs font-semibold">{gender}</div>
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 ${mutedText}`} />
                  </button>
                </div>

                {/* Primary Start Video Chat CTA */}
                <button
                  onClick={() => setScreen('video_call')}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-lg shadow-sky-600/20 active:scale-[0.98] transition-transform"
                >
                  <Video className="w-4 h-4" />
                  <span>Start Video Chat</span>
                </button>

                {/* Native Ad Card (Separated cleanly from CTA) */}
                <div className={`rounded-xl border p-3 ${cardSurface}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-indigo-500/15 text-indigo-500 flex items-center justify-center shrink-0">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="inline-block text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          Ad
                        </span>
                        <div className="text-xs font-semibold truncate mt-0.5">
                          Learn Languages Live
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold px-2.5 py-1 rounded-md bg-sky-600 text-white shrink-0">
                      Install
                    </span>
                  </div>
                </div>
              </div>

              {/* Policy-compliant Home Banner Ad */}
              <div
                className={`border-t px-3 py-2 text-center ${
                  androidDark
                    ? 'bg-slate-900 border-slate-800 text-slate-400'
                    : 'bg-slate-100 border-slate-200 text-slate-600'
                }`}
              >
                <div className="text-[10px] font-medium">
                  AdMob 320x50 Banner · Test Unit ID · Safe 16dp Margin
                </div>
              </div>
            </div>
          )}

          {screen === 'video_call' && (
            <div className="relative flex-1 bg-slate-950 text-white overflow-hidden">
              {/* Remote Peer Video Feed */}
              {callPhase === 'connected' ? (
                <img
                  src={remoteCallerImg}
                  alt="Matched remote peer camera stream"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center px-6 text-center bg-slate-950">
                  <div className="w-10 h-10 rounded-full border-2 border-sky-500 border-t-transparent animate-spin mb-3" />
                  <div className="text-sm font-semibold">
                    {callPhase === 'searching' && 'Searching matchmaking queue...'}
                    {callPhase === 'signaling' && 'Exchanging SDP & ICE candidates...'}
                    {callPhase === 'reconnecting' && 'ICE Restart: Reconnecting stream...'}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    {country.label} · {gender}
                  </div>
                </div>
              )}

              {/* Top Scrim: Status + Report/Block (ZERO ads over active call) */}
              <div className="absolute top-0 inset-x-0 p-3 bg-gradient-to-b from-black/75 to-transparent flex items-center justify-between">
                <div className="px-2.5 py-1.5 rounded-lg bg-slate-900/80 backdrop-blur-sm text-[11px] font-medium flex items-center gap-1.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      callPhase === 'connected' ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}
                  />
                  <span>
                    {callPhase === 'connected' ? '🇺🇸 United States · Connected' : 'Connecting'}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setCallPhase((p) => (p === 'reconnecting' ? 'connected' : 'reconnecting'))}
                    title="Simulate ICE reconnect"
                    className="w-8 h-8 rounded-full bg-slate-900/80 flex items-center justify-center"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={submitReport}
                    title="Block user"
                    className="w-8 h-8 rounded-full bg-slate-900/80 flex items-center justify-center"
                  >
                    <Ban className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setShowReportSheet(true)}
                    title="Report user"
                    className="w-8 h-8 rounded-full bg-red-600/85 flex items-center justify-center"
                  >
                    <Flag className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {reportToast && (
                <div className="absolute top-14 inset-x-4 px-3 py-2 rounded-lg bg-slate-900/95 border border-slate-700 text-[11px] text-center">
                  {reportToast}
                </div>
              )}

              {/* Local PiP Camera */}
              <div className="absolute right-3 bottom-20 w-24 h-32 rounded-2xl overflow-hidden border border-white/25 shadow-xl bg-slate-900 flex items-center justify-center">
                {cameraOn ? (
                  <img
                    src={localPipImg}
                    alt="Local front camera PiP preview"
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover ${isFrontCam ? 'scale-x-[-1]' : ''}`}
                  />
                ) : (
                  <VideoOff className="w-5 h-5 text-slate-400" />
                )}
              </div>

              {/* Call Controls Bar */}
              <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/85 to-transparent flex items-center justify-between">
                <button
                  onClick={() => setMicMuted((v) => !v)}
                  aria-label="Toggle microphone"
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    micMuted ? 'bg-red-600' : 'bg-slate-800/85'
                  }`}
                >
                  {micMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => setCameraOn((v) => !v)}
                  aria-label="Toggle camera"
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    !cameraOn ? 'bg-red-600' : 'bg-slate-800/85'
                  }`}
                >
                  {cameraOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => setIsFrontCam((v) => !v)}
                  aria-label="Switch front/back camera"
                  className="w-10 h-10 rounded-full bg-slate-800/85 flex items-center justify-center"
                >
                  <Camera className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setLowBandwidth((v) => !v)}
                  aria-label="Toggle low bandwidth"
                  className={`px-2.5 h-10 rounded-full text-[10px] font-semibold ${
                    lowBandwidth ? 'bg-amber-600 text-white' : 'bg-slate-800/85 text-slate-200'
                  }`}
                >
                  {lowBandwidth ? '250k' : 'HD'}
                </button>

                <button
                  onClick={handleNextUser}
                  aria-label="Next partner"
                  className="w-11 h-11 rounded-full bg-sky-600 flex items-center justify-center"
                >
                  <SkipForward className="w-4 h-4" />
                </button>

                <button
                  onClick={handleEndCall}
                  aria-label="End call"
                  className="w-11 h-11 rounded-full bg-red-600 flex items-center justify-center"
                >
                  <PhoneOff className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {screen === 'interstitial' && (
            <div className="flex-1 bg-slate-950 text-white p-5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Post-Session AdMob Interstitial</span>
                <button
                  onClick={() => setScreen(afterInterstitialTarget)}
                  className="px-2.5 py-1 rounded bg-slate-800 text-white font-semibold"
                >
                  Close Ad
                </button>
              </div>
              <div className="text-center space-y-2">
                <div className="text-[11px] uppercase tracking-wider text-sky-400 font-semibold">
                  Test Interstitial Placeholder
                </div>
                <h4 className="text-lg font-bold">Shown Only Between Completed Calls</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Enforces a 90-second cooldown and never interrupts or overlays an active WebRTC video stream.
                </p>
              </div>
              <button
                onClick={() => setScreen(afterInterstitialTarget)}
                className="w-full py-3 rounded-xl bg-sky-600 text-xs font-semibold"
              >
                Continue to {afterInterstitialTarget === 'video_call' ? 'Next Match' : 'Home'}
              </button>
            </div>
          )}

          {screen === 'settings' && (
            <div className="flex-1 flex flex-col overflow-y-auto">
              <div className="px-4 py-3 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800">
                <button onClick={() => setScreen('home')} aria-label="Back to Home">
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <span className="text-sm font-bold">Settings</span>
              </div>

              <div className="p-4 space-y-4 text-xs">
                <div>
                  <div className="font-semibold text-sky-500 mb-2">Appearance</div>
                  <div className={`grid grid-cols-2 gap-1 p-1 rounded-lg border ${cardSurface}`}>
                    <button
                      onClick={() => setAndroidDark(false)}
                      className={`py-1.5 rounded font-medium ${
                        !androidDark ? 'bg-sky-600 text-white' : ''
                      }`}
                    >
                      Light
                    </button>
                    <button
                      onClick={() => setAndroidDark(true)}
                      className={`py-1.5 rounded font-medium ${
                        androidDark ? 'bg-sky-600 text-white' : ''
                      }`}
                    >
                      Dark
                    </button>
                  </div>
                </div>

                <div className={`p-3 rounded-xl border flex items-center justify-between ${cardSurface}`}>
                  <div className="pr-2">
                    <div className="font-semibold">Low-Bandwidth Mode</div>
                    <div className={`text-[11px] ${mutedText}`}>250 kbps · 15 fps cap</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={lowBandwidth}
                    onChange={(e) => setLowBandwidth(e.target.checked)}
                  />
                </div>

                <div className={`p-3 rounded-xl border space-y-2 ${cardSurface}`}>
                  <div className="font-semibold">
                    {googleLinked ? 'Google Account Linked' : 'Anonymous Firebase Auth'}
                  </div>
                  <div className={`text-[11px] font-mono ${mutedText}`}>UID: rt_9f38a1c0b2...</div>
                  {!googleLinked && (
                    <button
                      onClick={() => setGoogleLinked(true)}
                      className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-semibold"
                    >
                      Link Google Account
                    </button>
                  )}
                </div>

                <div className={`rounded-xl border divide-y ${cardSurface} ${androidDark ? 'divide-slate-800' : 'divide-slate-100'}`}>
                  {['Privacy Policy', 'Terms & Conditions', 'Community Guidelines'].map((doc) => (
                    <button
                      key={doc}
                      onClick={() => {
                        setLegalTitle(doc);
                        setScreen('legal');
                      }}
                      className="w-full px-3 py-2.5 flex items-center justify-between text-left"
                    >
                      <span>{doc}</span>
                      <ChevronRight className={`w-3.5 h-3.5 ${mutedText}`} />
                    </button>
                  ))}
                  <div className="px-3 py-2.5 flex items-center justify-between">
                    <span>About Random Talk</span>
                    <span className={mutedText}>v1.0.0</span>
                  </div>
                </div>

                <button
                  onClick={() => setShowDeleteDialog(true)}
                  className="w-full py-2.5 rounded-xl bg-red-600 text-white font-semibold"
                >
                  Delete Account &amp; Data
                </button>
              </div>
            </div>
          )}

          {screen === 'legal' && (
            <div className="flex-1 flex flex-col overflow-y-auto">
              <div className="px-4 py-3 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800">
                <button onClick={() => setScreen('settings')} aria-label="Back to Settings">
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <span className="text-sm font-bold">{legalTitle}</span>
              </div>
              <div className={`p-4 text-xs leading-relaxed space-y-2 ${mutedText}`}>
                <p>
                  Random Talk connects adults 18+ worldwide over peer-to-peer WebRTC (DTLS-SRTP) encrypted channels. Video and audio are never recorded on backend servers.
                </p>
                <p>
                  Personal identifiers (email or Google identity) are never revealed to matched peers. Block lists and abuse reports are enforced server-side in Firebase Cloud Functions.
                </p>
              </div>
            </div>
          )}

          {/* Country Bottom Sheet */}
          {showCountrySheet && (
            <div className="absolute inset-0 bg-black/50 flex items-end z-20">
              <div className={`w-full rounded-t-2xl p-4 space-y-2 border-t ${cardSurface}`}>
                <div className="text-xs font-bold mb-2">Select Country</div>
                {COUNTRIES.map((c) => (
                  <button
                    key={c.code}
                    onClick={() => {
                      setCountry(c);
                      setShowCountrySheet(false);
                    }}
                    className="w-full py-2 flex items-center justify-between text-xs"
                  >
                    <span>
                      {c.flag} {c.label}
                    </span>
                    {country.code === c.code && <Check className="w-3.5 h-3.5 text-sky-500" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Gender Bottom Sheet */}
          {showGenderSheet && (
            <div className="absolute inset-0 bg-black/50 flex items-end z-20">
              <div className={`w-full rounded-t-2xl p-4 space-y-2 border-t ${cardSurface}`}>
                <div className="text-xs font-bold">Match Preference</div>
                <p className={`text-[10px] ${mutedText}`}>
                  Available where legally &amp; technically supported.
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {GENDERS.map((g) => (
                    <button
                      key={g}
                      onClick={() => {
                        setGender(g);
                        setShowGenderSheet(false);
                      }}
                      className={`py-2 rounded-lg text-xs font-medium border ${
                        gender === g
                          ? 'bg-sky-600 border-sky-600 text-white'
                          : cardSurface
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Safety Report Modal */}
          {showReportSheet && (
            <div className="absolute inset-0 bg-black/60 flex items-end z-20">
              <div className={`w-full rounded-t-2xl p-4 space-y-2.5 border-t ${cardSurface}`}>
                <div className="flex items-center gap-2 text-xs font-bold text-red-500">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Report Safety Violation</span>
                </div>
                {['Harassment or Bullying', 'Nudity or Sexual Content', 'Underage User (<18)', 'Spam or Bot'].map(
                  (reason) => (
                    <button
                      key={reason}
                      onClick={() => setReportReason(reason)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs border ${
                        reportReason === reason
                          ? 'border-red-500 bg-red-500/10'
                          : cardSurface
                      }`}
                    >
                      {reason}
                    </button>
                  )
                )}
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => setShowReportSheet(false)}
                    className={`flex-1 py-2 rounded-lg text-xs border ${cardSurface}`}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={submitReport}
                    className="flex-1 py-2 rounded-lg text-xs font-semibold bg-red-600 text-white"
                  >
                    Report &amp; Block
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Delete Account Confirm */}
          {showDeleteDialog && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center p-4 z-20">
              <div className={`w-full rounded-2xl p-4 space-y-3 border ${cardSurface}`}>
                <div className="text-xs font-bold">Delete Account Permanently?</div>
                <p className={`text-[11px] ${mutedText}`}>
                  Calls deleteUserAccountData Cloud Function and wipes Auth + RTDB profile.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowDeleteDialog(false)}
                    className={`flex-1 py-2 rounded-lg text-xs border ${cardSurface}`}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      setShowDeleteDialog(false);
                      setScreen('age_gate');
                    }}
                    className="flex-1 py-2 rounded-lg text-xs font-semibold bg-red-600 text-white"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Android Gesture Pill */}
        <div
          className={`h-4 flex items-center justify-center shrink-0 ${
            screen === 'video_call' || screen === 'interstitial'
              ? 'bg-slate-950'
              : phoneSurface
          }`}
        >
          <div className="w-24 h-1 rounded-full bg-slate-500/50" />
        </div>
      </div>

      <button
        onClick={() =>
          onJumpToFile(
            screen === 'video_call'
              ? 'VideoCallScreen.kt'
              : screen === 'settings'
                ? 'SettingsScreen.kt'
                : screen === 'age_gate'
                  ? 'AgeGateScreen.kt'
                  : 'HomeScreen.kt'
          )
        }
        className="mt-3 text-xs font-medium text-sky-600 dark:text-sky-400 hover:underline"
      >
        Inspect Kotlin source for this screen →
      </button>
    </div>
  );
};
