import React, { useMemo, useState } from 'react';
import { Check, Copy, FileCode2, FolderOpen, Search } from 'lucide-react';
import { FileCategory, PROJECT_FILES, ProjectFile } from '../lib/projectFiles';

interface SourceExplorerProps {
  initialSelectedPath?: string | null;
}

const CATEGORIES: { id: 'all' | FileCategory; label: string }[] = [
  { id: 'all', label: 'All Files' },
  { id: 'kotlin-ui', label: 'Kotlin & Compose' },
  { id: 'webrtc-ads', label: 'WebRTC & AdMob' },
  { id: 'firebase', label: 'Firebase Backend' },
  { id: 'gradle-manifest', label: 'Gradle & Manifest' },
  { id: 'docs', label: 'Docs & Policy' },
];

export const SourceExplorer: React.FC<SourceExplorerProps> = ({ initialSelectedPath }) => {
  const [category, setCategory] = useState<'all' | FileCategory>('all');
  const [query, setQuery] = useState('');
  const [selectedPath, setSelectedPath] = useState<string>(() => {
    if (initialSelectedPath) {
      const match = PROJECT_FILES.find((f) => f.path.includes(initialSelectedPath));
      if (match) return match.path;
    }
    return PROJECT_FILES[0]?.path ?? '';
  });
  const [copied, setCopied] = useState(false);

  React.useEffect(() => {
    if (initialSelectedPath) {
      const match = PROJECT_FILES.find((f) => f.path.includes(initialSelectedPath));
      if (match) {
        setCategory('all');
        setQuery('');
        setSelectedPath(match.path);
      }
    }
  }, [initialSelectedPath]);

  const filteredFiles = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PROJECT_FILES.filter((file) => {
      const matchesCat = category === 'all' || file.category === category;
      const matchesQuery =
        !q ||
        file.path.toLowerCase().includes(q) ||
        file.content.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });
  }, [category, query]);

  const activeFile: ProjectFile | undefined =
    PROJECT_FILES.find((f) => f.path === selectedPath) ?? filteredFiles[0];

  const handleCopy = async () => {
    if (!activeFile) return;
    await navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[680px]">
      {/* Left Sidebar: File Browser */}
      <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 flex flex-col">
        <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search Kotlin, Gradle, Firebase..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="flex flex-wrap gap-1">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={`px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  category === cat.id
                    ? 'bg-slate-900 dark:bg-sky-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/70 max-h-[580px]">
          {filteredFiles.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              No files match your filter.
            </div>
          ) : (
            filteredFiles.map((file) => {
              const selected = activeFile?.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedPath(file.path)}
                  className={`w-full px-3.5 py-2.5 text-left flex items-center justify-between gap-2 transition-colors ${
                    selected
                      ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FileCode2 className="w-4 h-4 shrink-0 opacity-70" />
                    <div className="min-w-0">
                      <div className="text-xs font-medium truncate">{file.name}</div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate font-mono">
                        {file.path}
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
                    {file.lines}L
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Right Code Viewer */}
      <div className="lg:col-span-8 flex flex-col bg-slate-950 text-slate-100">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-4 bg-slate-900/60">
          <div className="flex items-center gap-2 min-w-0">
            <FolderOpen className="w-4 h-4 text-sky-400 shrink-0" />
            <span className="text-xs font-mono truncate text-slate-200">
              {activeFile?.path ?? 'No file selected'}
            </span>
          </div>
          {activeFile && (
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-100 flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy File'}</span>
            </button>
          )}
        </div>

        <div className="flex-1 overflow-auto p-4 max-h-[620px]">
          {activeFile ? (
            <pre className="text-xs leading-relaxed font-mono text-slate-200 whitespace-pre">
              {activeFile.content}
            </pre>
          ) : null}
        </div>
      </div>
    </div>
  );
};
