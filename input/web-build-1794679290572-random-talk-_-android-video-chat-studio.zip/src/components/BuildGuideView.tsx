import React, { useState } from 'react';
import { CheckCircle2, Circle, ShieldCheck, Smartphone, Terminal } from 'lucide-react';

interface BuildGuideViewProps {
  onJumpToFile: (pathFragment: string) => void;
}

const CHECKLIST_ITEMS = [
  {
    id: 'firebase-json',
    title: 'Add google-services.json for com.randomtalk.videochat',
    desc: 'Register your Android app in Firebase Console, add SHA-1/SHA-256 keys, and replace app/google-services.json.template with app/google-services.json.',
    file: 'google-services.json.template',
  },
  {
    id: 'auth-providers',
    title: 'Enable Anonymous & Google Authentication',
    desc: 'Enable both providers in Firebase Authentication and place your Web Client ID inside local.properties as GOOGLE_WEB_CLIENT_ID.',
    file: 'local.properties.example',
  },
  {
    id: 'rtdb-functions',
    title: 'Deploy RTDB Rules, App Check & Cloud Functions',
    desc: 'Run firebase deploy --only database,functions and activate Play Integrity in Firebase App Check.',
    file: 'database.rules.json',
  },
  {
    id: 'turn-server',
    title: 'Configure TURN Relay Credentials (coturn / Metered)',
    desc: 'Set TURN_SHARED_SECRET and TURN_SERVER_URL in Firebase Functions secrets so getTurnCredentials issues ephemeral 1-hour relay tokens.',
    file: 'IceServerProvider.kt',
  },
  {
    id: 'admob-ump',
    title: 'Configure AdMob Production IDs & UMP Consent',
    desc: 'Debug builds use Google Test Ad IDs automatically. Populate ADMOB_PROD_* keys in local.properties and set GDPR/CCPA messaging in AdMob Console.',
    file: 'AdMobManager.kt',
  },
];

export const BuildGuideView: React.FC<BuildGuideViewProps> = ({ onJumpToFile }) => {
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  const toggle = (id: string) => {
    setChecked((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const completedCount = Object.values(checked).filter(Boolean).length;

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Production Release Checklist */}
        <div className="lg:col-span-7 border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 p-6">
          <div className="flex items-center justify-between gap-4 mb-5">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Production Configuration Checklist</h2>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                Complete these steps before generating your signed Google Play release bundle.
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums font-semibold text-sky-600 dark:text-sky-400">
              {completedCount}/{CHECKLIST_ITEMS.length}
            </span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {CHECKLIST_ITEMS.map((item) => {
              const done = !!checked[item.id];
              return (
                <div key={item.id} className="py-4 flex items-start gap-3">
                  <button
                    onClick={() => toggle(item.id)}
                    className="mt-0.5 text-sky-600 dark:text-sky-400 shrink-0"
                    aria-label={`Mark ${item.title} complete`}
                  >
                    {done ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5 text-slate-400" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm font-semibold ${done ? 'line-through opacity-60' : ''}`}>
                      {item.title}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                      {item.desc}
                    </p>
                    <button
                      onClick={() => onJumpToFile(item.file)}
                      className="mt-2 text-xs font-mono text-sky-600 dark:text-sky-400 hover:underline"
                    >
                      Open {item.file} →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: AdMob Policy & Gradle Build Commands */}
        <div className="lg:col-span-5 space-y-6">
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 p-6 space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <h3 className="text-base font-bold">AdMob &amp; Play Policy Guarantees</h3>
            </div>
            <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-2 leading-relaxed">
              <li>• Zero advertisements are rendered over or during active WebRTC video calls.</li>
              <li>• Home Banner and Native Ad cards maintain 16dp+ vertical clearance from Start Chat buttons.</li>
              <li>• Post-session Interstitials enforce a minimum 2-call interval and 90-second cooldown.</li>
              <li>• Google UMP consent runs at launch with a Settings privacy options trigger.</li>
            </ul>
          </div>

          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-slate-950 text-slate-100 p-6 space-y-3">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-sky-400" />
              <h3 className="text-sm font-bold">Build Android APK / AAB</h3>
            </div>
            <pre className="text-xs font-mono text-slate-300 bg-slate-900 p-3.5 rounded-xl overflow-x-auto leading-relaxed">
{`# 1. Deploy Firebase RTDB rules & functions
cd firebase
firebase deploy --only database,functions

# 2. Build Debug APK (uses Test AdMob IDs)
./gradlew assembleDebug

# 3. Build Release Play Store Bundle
./gradlew bundleRelease`}
            </pre>
            <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
              <Smartphone className="w-3.5 h-3.5" />
              <span>minSdk 23 · targetSdk 35 · Kotlin 2.1 · Compose BOM</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
