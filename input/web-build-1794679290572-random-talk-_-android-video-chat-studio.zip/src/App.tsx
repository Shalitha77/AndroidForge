import React, { useState } from 'react';
import { Download, Moon, Sun } from 'lucide-react';
import { AndroidPhonePreview, PreviewInspectorState } from './components/AndroidPhonePreview';
import { SourceExplorer } from './components/SourceExplorer';
import { BackendArchitectureView } from './components/BackendArchitectureView';
import { BuildGuideView } from './components/BuildGuideView';
import { downloadAndroidProjectZip, PROJECT_FILES } from './lib/projectFiles';

type StudioTab = 'preview' | 'source' | 'backend' | 'guide';

const INSPECTOR_MAP: Record<
  PreviewInspectorState['screen'],
  {
    kotlinFile: string;
    firebasePath: string;
    adMobRule: string;
    summary: string;
  }
> = {
  age_gate: {
    kotlinFile: 'ui/screens/onboarding/AgeGateScreen.kt',
    firebasePath: 'DataStore: adult_confirmed & guidelines_accepted',
    adMobRule: 'UMP ConsentInformation checks run before MobileAds.initialize()',
    summary: 'Blocks underage entry (<18) and requires explicit acceptance of Community Guidelines.',
  },
  home: {
    kotlinFile: 'ui/screens/home/HomeScreen.kt',
    firebasePath: 'RTDB: /stats/online_count & /presence/{uid}',
    adMobRule: 'HomeBannerAd + NativeAdCard with 16dp clearance from Start CTA',
    summary: 'Displays real-time online counter, Country/Gender filters, and Settings entry.',
  },
  video_call: {
    kotlinFile: 'ui/screens/call/VideoCallScreen.kt',
    firebasePath: 'RTDB: /matchmaking_queue/{uid} & /call_rooms/{roomId}/signals',
    adMobRule: 'Strict Policy Lock: Zero ads allowed over active video calls',
    summary: 'Streams encrypted WebRTC peer-to-peer media with ICE restart, low-BW cap, Report & Block.',
  },
  interstitial: {
    kotlinFile: 'ads/AdMobManager.kt',
    firebasePath: 'Post-session transition only (isCallActive = false)',
    adMobRule: '90s cooldown + min 2 completed calls frequency cap',
    summary: 'Shown strictly between completed sessions when switching to Next User or exiting.',
  },
  settings: {
    kotlinFile: 'ui/screens/settings/SettingsScreen.kt',
    firebasePath: 'Auth: Anonymous -> Google Link & deleteUserAccountData()',
    adMobRule: 'Exposes UserMessagingPlatform.showPrivacyOptionsForm() for GDPR/CCPA',
    summary: 'Controls Dark/Light theme, 250kbps mode, legal documents, support, and account deletion.',
  },
  legal: {
    kotlinFile: 'ui/screens/legal/LegalDocumentScreen.kt',
    firebasePath: 'Local in-app legal text + BuildConfig URLs',
    adMobRule: 'Privacy Policy discloses UMP consent and P2P non-recording guarantees',
    summary: 'Provides offline-accessible Privacy Policy, Terms & Conditions, and Community Guidelines.',
  },
};

export function App() {
  const [activeTab, setActiveTab] = useState<StudioTab>('preview');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [downloading, setDownloading] = useState(false);
  const [jumpFilePath, setJumpFilePath] = useState<string | null>(null);
  const [inspector, setInspector] = useState<PreviewInspectorState>({
    screen: 'home',
    callPhase: 'searching',
    androidDark: true,
    country: 'Global (Worldwide)',
    gender: 'Everyone',
    lowBandwidth: false,
    micMuted: false,
    cameraOn: true,
    isFrontCam: true,
  });

  React.useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  const handleDownloadZip = async () => {
    setDownloading(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setDownloading(false);
    }
  };

  const handleJumpToFile = (fragment: string) => {
    setJumpFilePath(fragment);
    setActiveTab('source');
  };

  const currentMeta = INSPECTOR_MAP[inspector.screen];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-element Brand Wordmark */}
          <button
            onClick={() => setActiveTab('preview')}
            className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
          >
            Random Talk Studio
          </button>

          {/* Zone 2: 4 single-line Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {(
              [
                { id: 'preview', label: 'Interactive Preview' },
                { id: 'source', label: 'Source Explorer' },
                { id: 'backend', label: 'Backend & WebRTC' },
                { id: 'guide', label: 'Build & AdMob' },
              ] as const
            ).map((nav) => (
              <button
                key={nav.id}
                onClick={() => setActiveTab(nav.id)}
                className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 ${
                  activeTab === nav.id
                    ? 'border-sky-600 text-slate-900 dark:text-white'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {nav.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: 1 Primary Action Button */}
          <div className="shrink-0">
            <button
              onClick={handleDownloadZip}
              disabled={downloading}
              className="px-4 py-2 rounded-lg bg-slate-900 dark:bg-sky-600 hover:bg-slate-800 dark:hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{downloading ? 'Packaging ZIP...' : 'Download Project ZIP'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Bar (visible < md) */}
      <div className="md:hidden border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-2 flex items-center gap-2 overflow-x-auto">
        {(
          [
            { id: 'preview', label: 'Preview' },
            { id: 'source', label: 'Source' },
            { id: 'backend', label: 'Backend' },
            { id: 'guide', label: 'Build Guide' },
          ] as const
        ).map((nav) => (
          <button
            key={nav.id}
            onClick={() => setActiveTab(nav.id)}
            className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 ${
              activeTab === nav.id
                ? 'bg-slate-900 dark:bg-sky-600 text-white'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {nav.label}
          </button>
        ))}
      </div>

      {/* Workspace Toolbar */}
      <div className="max-w-7xl w-full mx-auto px-6 pt-6 pb-2 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span className="font-mono text-slate-800 dark:text-slate-200 font-medium">
            com.randomtalk.videochat
          </span>
          <span aria-hidden="true">·</span>
          <span>Kotlin + Jetpack Compose M3</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">{PROJECT_FILES.length} project files</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">SDK 23–35</span>
        </div>

        <button
          onClick={() => setDarkMode((prev) => !prev)}
          className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-medium flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          {darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          <span>{darkMode ? 'Light Workspace' : 'Dark Workspace'}</span>
        </button>
      </div>

      {/* Main Content Area */}
      <main className="max-w-7xl w-full mx-auto px-6 py-6 flex-1">
        {activeTab === 'preview' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left: Interactive Android Device Simulator */}
            <div className="lg:col-span-5 flex justify-center">
              <AndroidPhonePreview
                onStateChange={setInspector}
                onJumpToFile={handleJumpToFile}
              />
            </div>

            {/* Right: Architecture & Live State Inspector */}
            <div className="lg:col-span-7 space-y-6">
              <div>
                <h1 className="text-3xl font-extrabold tracking-tight text-balance">
                  Random Talk Android Architecture
                </h1>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-2 leading-relaxed max-w-2xl">
                  Production-ready native Android video chat application built with Kotlin, Material Design 3, Stream WebRTC Android, Firebase Realtime Database, Cloud Functions, App Check, and policy-compliant Google AdMob + UMP.
                </p>
              </div>

              {/* Active Screen Mapping */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 p-6 space-y-4">
                <div className="flex items-center justify-between gap-4">
                  <h2 className="text-base font-bold">Live Screen Inspector</h2>
                  <button
                    onClick={() => handleJumpToFile(currentMeta.kotlinFile)}
                    className="text-xs font-mono text-sky-600 dark:text-sky-400 hover:underline"
                  >
                    {currentMeta.kotlinFile} →
                  </button>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {currentMeta.summary}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <div>
                    <div className="text-slate-500 dark:text-slate-400 mb-1">Backend / Storage</div>
                    <div className="font-mono text-slate-900 dark:text-slate-100">
                      {currentMeta.firebasePath}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500 dark:text-slate-400 mb-1">AdMob Policy Guard</div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">
                      {currentMeta.adMobRule}
                    </div>
                  </div>
                </div>
              </div>

              {/* Core Modules Summary Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  {
                    title: 'WebRTC Media Engine',
                    body: 'Camera2 front/back switching, acoustic echo cancellation, ICE restart reconnection, and 250 kbps low-bandwidth mode.',
                    target: 'WebRtcClient.kt',
                  },
                  {
                    title: 'Atomic Matchmaking',
                    body: 'Cloud Function transactions prevent duplicate rooms, enforce mutual block lists, and remove disconnected peers via onDisconnect.',
                    target: 'MatchmakingRepository.kt',
                  },
                  {
                    title: 'Auth & Safety Controls',
                    body: 'Anonymous + Google Credential Manager login, 18+ age gate, 1-tap Report & Block, and auto-ban threshold moderation.',
                    target: 'SafetyRepository.kt',
                  },
                  {
                    title: 'AdMob & UMP Consent',
                    body: 'Configurable Test/Production IDs in Gradle, GDPR/CCPA UMP consent form, Banner/Native on Home, Interstitial strictly between calls.',
                    target: 'AdMobManager.kt',
                  },
                ].map((card) => (
                  <div
                    key={card.title}
                    className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 p-5 flex flex-col justify-between gap-3"
                  >
                    <div>
                      <h3 className="text-sm font-bold">{card.title}</h3>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed">
                        {card.body}
                      </p>
                    </div>
                    <button
                      onClick={() => handleJumpToFile(card.target)}
                      className="text-left text-xs font-mono text-sky-600 dark:text-sky-400 hover:underline"
                    >
                      Open {card.target} →
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'source' && <SourceExplorer initialSelectedPath={jumpFilePath} />}

        {activeTab === 'backend' && <BackendArchitectureView onJumpToFile={handleJumpToFile} />}

        {activeTab === 'guide' && <BuildGuideView onJumpToFile={handleJumpToFile} />}
      </main>

      {/* Quiet Minimal Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 py-5 px-6 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <span>Random Talk (`com.randomtalk.videochat`) · Native Kotlin Android Studio Project</span>
          <button
            onClick={() => handleJumpToFile('PRIVACY_POLICY.md')}
            className="hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            Privacy Policy Template
          </button>
        </div>
      </footer>
    </div>
  );
}

export default App;
