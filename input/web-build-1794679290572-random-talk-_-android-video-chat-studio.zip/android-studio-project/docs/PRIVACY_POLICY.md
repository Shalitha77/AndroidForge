# Privacy Policy — Random Talk (`com.randomtalk.videochat`)

Effective Date: November 2026

## 1. Eligibility (18+ Only)
Random Talk is strictly intended for adults aged 18 and older. We do not knowingly collect data from or allow access to anyone under 18.

## 2. Information We Process
- **Account Identifiers**: An anonymous Firebase UID or optional Google Sign-In UID. We never publicly display your email address, real name, or phone number to other callers.
- **Matchmaking Preferences**: Selected country filter and optional match preference stored temporarily while searching.
- **Safety & Moderation Logs**: User-submitted abuse reports and personal block lists so blocked users are never matched again.

## 3. Real-Time Video & Audio
Video and audio streams are transmitted directly peer-to-peer using WebRTC (DTLS-SRTP). Streams are **not** recorded or stored on our servers.

## 4. Advertising & Consent (AdMob + UMP)
We display banner, native, and post-session interstitial advertisements via Google AdMob. Users in regulated regions (EEA, UK, US states) are presented with a Google UMP consent dialog and can update consent preferences anytime in **Settings -> Ad Privacy & Consent Options**. Ads are never shown over active video calls.

## 5. Account & Data Deletion
You can delete your account and all associated Realtime Database data immediately inside the app via **Settings -> Delete Account & Data**, or by emailing `support@randomtalk.app`.
