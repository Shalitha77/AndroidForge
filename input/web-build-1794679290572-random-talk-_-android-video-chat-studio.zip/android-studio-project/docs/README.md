# Random Talk (`com.randomtalk.videochat`) — Production Build & Setup Guide

## 1. Architecture Overview
- **UI**: Kotlin + Jetpack Compose + Material 3 (Dark & Light themes, minSdk 23, targetSdk 35)
- **DI**: Hilt (`AppModule.kt`)
- **Media**: `io.getstream:stream-webrtc-android` (Camera2 front/back switching, Acoustic Echo Cancellation, Hardware Video Codecs, ICE Restart, Low-Bandwidth 250 kbps / 15 fps cap)
- **Backend & Signaling**: Firebase Authentication (Anonymous + Google Credential Manager), Firebase Realtime Database (`onDisconnect` cleanup), Firebase Cloud Functions v2, Firebase App Check (Play Integrity)
- **Monetization**: Google Mobile Ads SDK + Google User Messaging Platform (UMP) consent

## 2. Firebase Configuration
1. Create a Firebase project in the Firebase Console.
2. Register Android app with package name `com.randomtalk.videochat` and add your debug & release SHA-1 / SHA-256 fingerprints.
3. Download `google-services.json` and place it at `app/google-services.json` (replace `google-services.json.template`).
4. Enable **Authentication** providers:
   - Anonymous
   - Google (copy the Web Client ID into `local.properties` as `GOOGLE_WEB_CLIENT_ID`)
5. Create a **Realtime Database** instance and deploy security rules:
   ```bash
   cd firebase
   firebase deploy --only database
   ```
6. Enable **Firebase App Check** using **Play Integrity** for release builds and register your debug token in Logcat for local development.

## 3. Deploy Cloud Functions & Ephemeral TURN
1. Install dependencies & deploy functions:
   ```bash
   cd firebase/functions
   npm install
   firebase functions:secrets:set TURN_SHARED_SECRET # optional for coturn
   firebase deploy --only functions
   ```
2. Configure a TURN relay (e.g., self-hosted `coturn` with `use-auth-secret` or a managed TURN provider like Metered / Twilio) so peer-to-peer calls succeed behind strict symmetric NATs and carrier-grade mobile firewalls.

## 4. Google AdMob & UMP Setup
- Debug builds automatically use official Google Test Ad Unit IDs.
- Before releasing to Google Play:
  1. Create an App and Banner / Interstitial / Native ad units in AdMob.
  2. Configure GDPR & US State privacy messages in AdMob -> Privacy & Messaging (UMP).
  3. Copy `local.properties.example` to `local.properties` and set:
     - `ADMOB_PROD_APP_ID`
     - `ADMOB_PROD_BANNER_ID`
     - `ADMOB_PROD_INTERSTITIAL_ID`
     - `ADMOB_PROD_NATIVE_ID`

## 5. Build APK / Release App Bundle
```bash
./gradlew assembleDebug
./gradlew bundleRelease
```
