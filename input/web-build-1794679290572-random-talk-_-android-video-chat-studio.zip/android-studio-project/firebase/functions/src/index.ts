import * as admin from "firebase-admin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { onValueCreated, onValueWritten } from "firebase-functions/v2/database";
import { onSchedule } from "firebase-functions/v2/scheduler";
import * as crypto from "crypto";

admin.initializeApp();
const db = admin.database();

interface QueueEntry {
  uid: string;
  countryCode: string;
  selfGender: string;
  preferredGender: string;
  status: string;
  roomId?: string;
  createdAt: number;
}

/**
 * Atomic server-side matchmaking with Firebase App Check enforcement.
 * Prevents duplicate rooms, honors mutual block lists, and verifies ban status.
 */
export const findRandomMatch = onCall(
  { enforceAppCheck: true },
  async (request) => {
    const uid = request.auth?.uid;
    if (!uid) {
      throw new HttpsError("unauthenticated", "Authentication required.");
    }

    const banSnap = await db.ref(`moderation/${uid}/isBanned`).get();
    if (banSnap.val() === true) {
      throw new HttpsError("permission-denied", "Account is suspended.");
    }

    const countryCode = String(request.data?.countryCode ?? "GLOBAL");
    const selfGender = String(request.data?.selfGender ?? "ANY");
    const preferredGender = String(request.data?.preferredGender ?? "ANY");

    const [myBlockedSnap, blockedByMeSnap, queueSnap] = await Promise.all([
      db.ref(`users/${uid}/blocked`).get(),
      db.ref(`blocked_by/${uid}`).get(),
      db.ref("matchmaking_queue").orderByChild("status").equalTo("WAITING").limitToFirst(50).get(),
    ]);

    const myBlocked = new Set<string>(Object.keys(myBlockedSnap.val() ?? {}));
    const blockedByOthers = new Set<string>(Object.keys(blockedByMeSnap.val() ?? {}));

    const candidates: QueueEntry[] = [];
    queueSnap.forEach((child) => {
      const entry = child.val() as QueueEntry;
      if (!entry || entry.uid === uid) return;
      if (myBlocked.has(entry.uid) || blockedByOthers.has(entry.uid)) return;

      const countryMatch =
        countryCode === "GLOBAL" ||
        entry.countryCode === "GLOBAL" ||
        entry.countryCode === countryCode;

      const iWantPartner =
        preferredGender === "ANY" || entry.selfGender === "ANY" || entry.selfGender === preferredGender;
      const partnerWantsMe =
        entry.preferredGender === "ANY" || selfGender === "ANY" || entry.preferredGender === selfGender;

      if (countryMatch && iWantPartner && partnerWantsMe) {
        candidates.push(entry);
      }
    });

    if (candidates.length === 0) {
      return { matched: false };
    }

    // Shuffle candidates for fair random pairing
    const partner = candidates[Math.floor(Math.random() * candidates.length)];
    const roomId = db.ref("call_rooms").push().key!;

    // Atomic transaction on partner's queue node to prevent duplicate matches
    const partnerRef = db.ref(`matchmaking_queue/${partner.uid}`);
    const txResult = await partnerRef.transaction((current: QueueEntry | null) => {
      if (!current || current.status !== "WAITING") {
        return; // Abort if another peer matched them first
      }
      return {
        ...current,
        status: "MATCHED",
        roomId,
        partnerUid: uid,
        partnerCountryCode: countryCode,
        isOfferer: false,
      };
    });

    if (!txResult.committed) {
      return { matched: false };
    }

    // Atomically create room & update caller's queue entry
    const updates: Record<string, unknown> = {
      [`call_rooms/${roomId}`]: {
        roomId,
        createdAt: admin.database.ServerValue.TIMESTAMP,
        participants: {
          [uid]: true,
          [partner.uid]: true,
        },
      },
      [`matchmaking_queue/${uid}`]: {
        uid,
        countryCode,
        selfGender,
        preferredGender,
        status: "MATCHED",
        roomId,
        partnerUid: partner.uid,
        partnerCountryCode: partner.countryCode,
        isOfferer: true,
        createdAt: admin.database.ServerValue.TIMESTAMP,
      },
    };
    await db.ref().update(updates);

    return {
      matched: true,
      roomId,
      partnerUid: partner.uid,
      partnerCountryCode: partner.countryCode,
      isOfferer: true,
    };
  }
);

/**
 * Generates short-lived HMAC-SHA1 ephemeral TURN credentials (coturn use-auth-secret).
 * Set TURN_SECRET and TURN_URLS in Firebase Functions environment variables.
 */
export const getTurnCredentials = onCall(
  { enforceAppCheck: true },
  async (request) => {
    const uid = request.auth?.uid;
    if (!uid) {
      throw new HttpsError("unauthenticated", "Authentication required.");
    }

    const turnSecret = process.env.TURN_SHARED_SECRET ?? "";
    const turnUrl = process.env.TURN_SERVER_URL ?? "";

    if (!turnSecret || !turnUrl) {
      return { iceServers: [] };
    }

    const ttlSeconds = 3600;
    const timestamp = Math.floor(Date.now() / 1000) + ttlSeconds;
    const username = `${timestamp}:${uid}`;
    const hmac = crypto.createHmac("sha1", turnSecret);
    hmac.update(username);
    const credential = hmac.digest("base64");

    return {
      iceServers: [
        {
          urls: [turnUrl],
          username,
          credential,
        },
      ],
    };
  }
);

/**
 * Maintains server-authoritative online user count.
 */
export const onPresenceChanged = onValueWritten("/presence/{uid}", async () => {
  const snap = await db.ref("presence").get();
  await db.ref("stats/online_count").set(snap.numChildren());
});

/**
 * Automated abuse-prevention threshold: suspends accounts receiving >= 5 distinct user reports.
 */
export const onReportCreated = onValueCreated("/reports/{reportId}", async (event) => {
  const report = event.data.val() as {
    reportedUid?: string;
    reporterUid?: string;
    reason?: string;
  } | null;

  if (!report?.reportedUid || !report?.reporterUid) return;

  const modRef = db.ref(`moderation/${report.reportedUid}`);
  await modRef.transaction((current) => {
    const existing = current ?? { reportCount: 0, reporters: {}, isBanned: false };
    if (existing.reporters?.[report.reporterUid!]) {
      return existing; // Ignore duplicate reports from same reporter
    }
    const nextCount = (existing.reportCount ?? 0) + 1;
    const isBanned = nextCount >= 5 || report.reason === "UNDERAGE";
    return {
      ...existing,
      reportCount: nextCount,
      isBanned,
      lastReportedAt: Date.now(),
      reporters: {
        ...(existing.reporters ?? {}),
        [report.reporterUid!]: true,
      },
    };
  });
});

/**
 * Deletes all Realtime Database records owned by a user upon account deletion.
 */
export const deleteUserAccountData = onCall(
  { enforceAppCheck: true },
  async (request) => {
    const uid = request.auth?.uid;
    if (!uid) {
      throw new HttpsError("unauthenticated", "Authentication required.");
    }

    const updates: Record<string, null> = {
      [`users/${uid}`]: null,
      [`presence/${uid}`]: null,
      [`matchmaking_queue/${uid}`]: null,
      [`blocked_by/${uid}`]: null,
    };
    await db.ref().update(updates);
    return { deleted: true };
  }
);

/**
 * Periodic cleanup for ended or stale WebRTC call rooms (> 30 minutes old).
 */
export const cleanupStaleRooms = onSchedule("every 30 minutes", async () => {
  const cutoff = Date.now() - 30 * 60 * 1000;
  const snap = await db.ref("call_rooms").orderByChild("createdAt").endAt(cutoff).get();
  const updates: Record<string, null> = {};
  snap.forEach((child) => {
    updates[`call_rooms/${child.key}`] = null;
  });
  if (Object.keys(updates).length > 0) {
    await db.ref().update(updates);
  }
});
