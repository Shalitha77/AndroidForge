# WebRTC native JNI classes
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# Firebase Realtime Database & Auth models
-keepattributes Signature
-keepattributes *Annotation*
-keepclassmembers class com.randomtalk.videochat.domain.model.** { *; }
-keepclassmembers class com.randomtalk.videochat.data.** { *; }

# Firebase App Check
-keep class com.google.firebase.appcheck.** { *; }

# Google Mobile Ads & UMP Consent
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.ump.** { *; }

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
