import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.google.services)
}

val localProps = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) {
        file.inputStream().use { load(it) }
    }
}

fun propOrDefault(key: String, default: String): String =
    localProps.getProperty(key)?.takeIf { it.isNotBlank() } ?: default

android {
    namespace = "com.randomtalk.videochat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.randomtalk.videochat"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"${propOrDefault("GOOGLE_WEB_CLIENT_ID", "")}\"")
        buildConfigField("String", "STUN_SERVER_URL", "\"${propOrDefault("STUN_SERVER_URL", "stun:stun.l.google.com:19302")}\"")
        buildConfigField("String", "TURN_SERVER_URL", "\"${propOrDefault("TURN_SERVER_URL", "")}\"")
        buildConfigField("String", "TURN_USERNAME", "\"${propOrDefault("TURN_USERNAME", "")}\"")
        buildConfigField("String", "TURN_CREDENTIAL", "\"${propOrDefault("TURN_CREDENTIAL", "")}\"")
        buildConfigField("String", "SUPPORT_EMAIL", "\"${propOrDefault("SUPPORT_EMAIL", "support@randomtalk.app")}\"")
        buildConfigField("String", "PRIVACY_POLICY_URL", "\"${propOrDefault("PRIVACY_POLICY_URL", "https://randomtalk.app/privacy")}\"")
        buildConfigField("String", "TERMS_URL", "\"${propOrDefault("TERMS_URL", "https://randomtalk.app/terms")}\"")
    }

    buildTypes {
        debug {
            // Official Google Mobile Ads Test IDs
            manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
            buildConfigField("String", "ADMOB_BANNER_ID", "\"ca-app-pub-3940256099942544/6300978111\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-3940256099942544/1033173712\"")
            buildConfigField("String", "ADMOB_NATIVE_ID", "\"ca-app-pub-3940256099942544/2247696110\"")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Configurable Production AdMob IDs from local.properties (falls back to test IDs if unset)
            manifestPlaceholders["admobAppId"] = propOrDefault("ADMOB_PROD_APP_ID", "ca-app-pub-3940256099942544~3347511713")
            buildConfigField("String", "ADMOB_BANNER_ID", "\"${propOrDefault("ADMOB_PROD_BANNER_ID", "ca-app-pub-3940256099942544/6300978111")}\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"${propOrDefault("ADMOB_PROD_INTERSTITIAL_ID", "ca-app-pub-3940256099942544/1033173712")}\"")
            buildConfigField("String", "ADMOB_NATIVE_ID", "\"${propOrDefault("ADMOB_PROD_NATIVE_ID", "ca-app-pub-3940256099942544/2247696110")}\"")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)
    debugImplementation(libs.androidx.ui.tooling)

    implementation(libs.androidx.datastore.preferences)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.play.services)
    implementation(libs.kotlinx.serialization.json)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.auth.ktx)
    implementation(libs.firebase.database.ktx)
    implementation(libs.firebase.functions.ktx)
    implementation(libs.firebase.appcheck.playintegrity)
    debugImplementation(libs.firebase.appcheck.debug)

    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.play.services)
    implementation(libs.google.identity.googleid)

    implementation(libs.stream.webrtc.android)
    implementation(libs.play.services.ads)
    implementation(libs.google.ump)
}
