package com.randomtalk.videochat.ads

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.randomtalk.videochat.R
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AdMobManager @Inject constructor(
    private val consentManager: ConsentManager
) {
    private val isMobileAdsInitialized = AtomicBoolean(false)
    private var interstitialAd: InterstitialAd? = null
    private var lastInterstitialShownAt = 0L
    private var completedCallCount = 0

    fun initializeMobileAds(context: Context) {
        if (!consentManager.canRequestAds) return
        if (isMobileAdsInitialized.getAndSet(true)) return

        MobileAds.initialize(context.applicationContext) {
            preloadInterstitial(context.applicationContext)
        }
    }

    fun preloadInterstitial(context: Context) {
        if (!consentManager.canRequestAds) return
        if (interstitialAd != null) return

        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context.applicationContext,
            AdMobConfig.interstitialAdUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    /**
     * Policy rule: ONLY show interstitial ads AFTER a video call session completes/ends,
     * never over an active video stream, and always honor frequency caps.
     */
    fun maybeShowPostSessionInterstitial(
        activity: Activity,
        isCallActive: Boolean,
        onComplete: () -> Unit
    ) {
        if (isCallActive || !consentManager.canRequestAds) {
            onComplete()
            return
        }

        completedCallCount++
        val now = System.currentTimeMillis()
        val cooldownSatisfied = (now - lastInterstitialShownAt) >= AdMobConfig.INTERSTITIAL_COOLDOWN_MS
        val frequencySatisfied = completedCallCount >= AdMobConfig.MIN_CALLS_BEFORE_INTERSTITIAL

        val ad = interstitialAd
        if (ad != null && cooldownSatisfied && frequencySatisfied) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    lastInterstitialShownAt = System.currentTimeMillis()
                    preloadInterstitial(activity)
                    onComplete()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    interstitialAd = null
                    preloadInterstitial(activity)
                    onComplete()
                }
            }
            ad.show(activity)
        } else {
            if (ad == null) preloadInterstitial(activity)
            onComplete()
        }
    }
}

@Composable
fun HomeBannerAd(
    canRequestAds: Boolean,
    modifier: Modifier = Modifier
) {
    if (!canRequestAds) return

    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = AdMobConfig.bannerAdUnitId
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

@Composable
fun NativeAdCard(
    canRequestAds: Boolean,
    modifier: Modifier = Modifier
) {
    if (!canRequestAds) return

    var loadedAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            loadedAd?.destroy()
        }
    }

    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { context ->
            val view = LayoutInflater.from(context)
                .inflate(R.layout.native_ad_card, null, false) as NativeAdView

            val loader = AdLoader.Builder(context, AdMobConfig.nativeAdUnitId)
                .forNativeAd { nativeAd ->
                    loadedAd?.destroy()
                    loadedAd = nativeAd
                    populateNativeAdView(nativeAd, view)
                    view.visibility = View.VISIBLE
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        view.visibility = View.GONE
                    }
                })
                .build()

            view.visibility = View.GONE
            loader.loadAd(AdRequest.Builder().build())
            view
        }
    )
}

private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
    val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
    val bodyView = adView.findViewById<TextView>(R.id.ad_body)
    val ctaView = adView.findViewById<Button>(R.id.ad_call_to_action)
    val iconView = adView.findViewById<ImageView>(R.id.ad_app_icon)
    val advertiserView = adView.findViewById<TextView>(R.id.ad_advertiser)

    adView.headlineView = headlineView
    adView.bodyView = bodyView
    adView.callToActionView = ctaView
    adView.iconView = iconView
    adView.advertiserView = advertiserView

    headlineView.text = nativeAd.headline
    bodyView.text = nativeAd.body ?: ""
    bodyView.visibility = if (nativeAd.body != null) View.VISIBLE else View.GONE

    if (nativeAd.callToAction != null) {
        ctaView.text = nativeAd.callToAction
        ctaView.visibility = View.VISIBLE
    } else {
        ctaView.visibility = View.GONE
    }

    if (nativeAd.icon != null) {
        iconView.setImageDrawable(nativeAd.icon?.drawable)
        iconView.visibility = View.VISIBLE
    } else {
        iconView.visibility = View.GONE
    }

    advertiserView.text = nativeAd.advertiser ?: "Sponsored"
    adView.setNativeAd(nativeAd)
}
