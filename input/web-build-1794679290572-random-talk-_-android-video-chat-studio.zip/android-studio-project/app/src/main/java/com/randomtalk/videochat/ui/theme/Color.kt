package com.randomtalk.videochat.ui.theme

import androidx.compose.ui.graphics.Color

val OceanPrimary = Color(0xFF0284C7)
val OceanPrimaryLight = Color(0xFF38BDF8)
val IndigoSecondary = Color(0xFF4F46E5)
val EmeraldOnline = Color(0xFF16A34A)
val AmberWarning = Color(0xFFD97706)
val CrimsonDanger = Color(0xFFDC2626)

val DarkBackground = Color(0xFF070B14)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceMuted = Color(0xFF94A3B8)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceMuted = Color(0xFF475569)
