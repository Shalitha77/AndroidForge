package com.randomtalk.videochat.ads

import com.randomtalk.videochat.BuildConfig

object AdMobConfig {
    val bannerAdUnitId: String = BuildConfig.ADMOB_BANNER_ID
    val interstitialAdUnitId: String = BuildConfig.ADMOB_INTERSTITIAL_ID
    val nativeAdUnitId: String = BuildConfig.ADMOB_NATIVE_ID

    // Policy: Minimum 2 completed sessions and 90s cooldown between interstitials
    const val MIN_CALLS_BEFORE_INTERSTITIAL = 2
    const val INTERSTITIAL_COOLDOWN_MS = 90_000L
}
