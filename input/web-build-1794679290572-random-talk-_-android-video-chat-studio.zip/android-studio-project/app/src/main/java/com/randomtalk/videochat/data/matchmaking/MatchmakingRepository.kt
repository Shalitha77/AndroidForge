package com.randomtalk.videochat.data.matchmaking

import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import com.google.firebase.functions.FirebaseFunctions
import com.randomtalk.videochat.domain.model.CallSession
import com.randomtalk.videochat.domain.model.GenderOption
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import javax.inject.Inject
import javax.inject.Singleton

sealed interface SignalingEvent {
    data class RemoteOffer(val sdp: String) : SignalingEvent
    data class RemoteAnswer(val sdp: String) : SignalingEvent
    data class RemoteIceCandidate(
        val sdpMid: String,
        val sdpMLineIndex: Int,
        val sdp: String
    ) : SignalingEvent
    data object PartnerDisconnected : SignalingEvent
}

@Singleton
class MatchmakingRepository @Inject constructor(
    private val database: FirebaseDatabase,
    private val functions: FirebaseFunctions
) {
    private val rootRef = database.reference

    fun observeOnlineUsersCount(): Flow<Int> = callbackFlow {
        val statsRef = rootRef.child("stats").child("online_count")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val count = snapshot.getValue(Long::class.java)?.toInt() ?: 0
                trySend(count.coerceAtLeast(1))
            }

            override fun onCancelled(error: DatabaseError) {
                // Keep last emitted count
            }
        }
        statsRef.addValueEventListener(listener)
        awaitClose { statsRef.removeEventListener(listener) }
    }

    fun registerPresence(uid: String) {
        val connectedRef = database.getReference(".info/connected")
        val userPresenceRef = rootRef.child("presence").child(uid)
        val userQueueRef = rootRef.child("matchmaking_queue").child(uid)

        connectedRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) == true
                if (connected) {
                    userPresenceRef.onDisconnect().removeValue()
                    userQueueRef.onDisconnect().removeValue()
                    userPresenceRef.setValue(
                        mapOf(
                            "online" to true,
                            "lastSeen" to ServerValue.TIMESTAMP
                        )
                    )
                }
            }

            override fun onCancelled(error: DatabaseError) = Unit
        })
    }

    suspend fun enterQueueAndFindMatch(
        uid: String,
        countryCode: String,
        selfGender: GenderOption,
        preferredGender: GenderOption
    ): Result<CallSession?> = runCatching {
        val queueRef = rootRef.child("matchmaking_queue").child(uid)
        queueRef.onDisconnect().removeValue().await()

        val ticket = mapOf(
            "uid" to uid,
            "countryCode" to countryCode,
            "selfGender" to selfGender.code,
            "preferredGender" to preferredGender.code,
            "status" to "WAITING",
            "roomId" to "",
            "createdAt" to ServerValue.TIMESTAMP
        )
        queueRef.setValue(ticket).await()

        // Invoke atomic Cloud Function matchmaking (enforces block lists, gender/country filters, and prevents duplicate rooms)
        val response = functions
            .getHttpsCallable("findRandomMatch")
            .call(
                mapOf(
                    "countryCode" to countryCode,
                    "selfGender" to selfGender.code,
                    "preferredGender" to preferredGender.code
                )
            )
            .await()

        @Suppress("UNCHECKED_CAST")
        val data = response.getData() as? Map<String, Any?> ?: return@runCatching null
        val matched = data["matched"] as? Boolean ?: false
        if (!matched) return@runCatching null

        CallSession(
            roomId = data["roomId"] as String,
            localUid = uid,
            partnerUid = data["partnerUid"] as String,
            partnerCountryCode = (data["partnerCountryCode"] as? String) ?: "GLOBAL",
            isOfferer = data["isOfferer"] as? Boolean ?: false
        )
    }

    fun observeMatchAssignment(uid: String): Flow<CallSession?> = callbackFlow {
        val queueRef = rootRef.child("matchmaking_queue").child(uid)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val status = snapshot.child("status").getValue(String::class.java)
                val roomId = snapshot.child("roomId").getValue(String::class.java)
                val partnerUid = snapshot.child("partnerUid").getValue(String::class.java)
                val partnerCountry = snapshot.child("partnerCountryCode").getValue(String::class.java) ?: "GLOBAL"
                val isOfferer = snapshot.child("isOfferer").getValue(Boolean::class.java) ?: false

                if (status == "MATCHED" && !roomId.isNullOrBlank() && !partnerUid.isNullOrBlank()) {
                    trySend(
                        CallSession(
                            roomId = roomId,
                            localUid = uid,
                            partnerUid = partnerUid,
                            partnerCountryCode = partnerCountry,
                            isOfferer = isOfferer
                        )
                    )
                }
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        queueRef.addValueEventListener(listener)
        awaitClose { queueRef.removeEventListener(listener) }
    }

    suspend fun leaveQueue(uid: String) {
        runCatching {
            rootRef.child("matchmaking_queue").child(uid).removeValue().await()
        }
    }

    suspend fun sendOffer(roomId: String, uid: String, description: SessionDescription) {
        val offerMap = mapOf(
            "type" to description.type.canonicalForm(),
            "sdp" to description.description,
            "senderUid" to uid,
            "createdAt" to ServerValue.TIMESTAMP
        )
        rootRef.child("call_rooms").child(roomId).child("signals").child("offer").setValue(offerMap).await()
    }

    suspend fun sendAnswer(roomId: String, uid: String, description: SessionDescription) {
        val answerMap = mapOf(
            "type" to description.type.canonicalForm(),
            "sdp" to description.description,
            "senderUid" to uid,
            "createdAt" to ServerValue.TIMESTAMP
        )
        rootRef.child("call_rooms").child(roomId).child("signals").child("answer").setValue(answerMap).await()
    }

    suspend fun sendIceCandidate(roomId: String, uid: String, candidate: IceCandidate) {
        val candidateMap = mapOf(
            "sdpMid" to candidate.sdpMid,
            "sdpMLineIndex" to candidate.sdpMLineIndex,
            "sdp" to candidate.sdp
        )
        rootRef.child("call_rooms")
            .child(roomId)
            .child("signals")
            .child("candidates")
            .child(uid)
            .push()
            .setValue(candidateMap)
            .await()
    }

    fun observeRoomSignals(session: CallSession): Flow<SignalingEvent> = callbackFlow {
        val roomRef = rootRef.child("call_rooms").child(session.roomId)
        val signalsRef = roomRef.child("signals")
        val partnerCandidatesRef = signalsRef.child("candidates").child(session.partnerUid)
        val partnerParticipantRef = roomRef.child("participants").child(session.partnerUid)

        // Ensure room auto-marks participant disconnected on unexpected network drop
        roomRef.child("participants").child(session.localUid).onDisconnect().setValue(false)
        roomRef.child("participants").child(session.localUid).setValue(true)

        val offerOrAnswerKey = if (session.isOfferer) "answer" else "offer"
        val sdpRef = signalsRef.child(offerOrAnswerKey)

        val sdpListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                if (session.isOfferer) {
                    trySend(SignalingEvent.RemoteAnswer(sdp))
                } else {
                    trySend(SignalingEvent.RemoteOffer(sdp))
                }
            }

            override fun onCancelled(error: DatabaseError) = Unit
        }

        val candidateListener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val sdpMid = snapshot.child("sdpMid").getValue(String::class.java) ?: return
                val mLineIndex = snapshot.child("sdpMLineIndex").getValue(Int::class.java) ?: return
                val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                trySend(SignalingEvent.RemoteIceCandidate(sdpMid, mLineIndex, sdp))
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) = Unit
            override fun onChildRemoved(snapshot: DataSnapshot) = Unit
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) = Unit
            override fun onCancelled(error: DatabaseError) = Unit
        }

        val partnerPresenceListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val active = snapshot.getValue(Boolean::class.java)
                if (active == false || (!snapshot.exists() && snapshot.key == session.partnerUid)) {
                    trySend(SignalingEvent.PartnerDisconnected)
                }
            }

            override fun onCancelled(error: DatabaseError) = Unit
        }

        sdpRef.addValueEventListener(sdpListener)
        partnerCandidatesRef.addChildEventListener(candidateListener)
        partnerParticipantRef.addValueEventListener(partnerPresenceListener)

        awaitClose {
            sdpRef.removeEventListener(sdpListener)
            partnerCandidatesRef.removeEventListener(candidateListener)
            partnerParticipantRef.removeEventListener(partnerPresenceListener)
        }
    }

    suspend fun endRoom(roomId: String, localUid: String) {
        runCatching {
            val roomRef = rootRef.child("call_rooms").child(roomId)
            roomRef.child("participants").child(localUid).setValue(false).await()
            roomRef.child("endedAt").setValue(ServerValue.TIMESTAMP).await()
        }
    }
}
