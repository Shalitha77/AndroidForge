package com.randomtalk.videochat.data.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.randomtalk.videochat.domain.model.AppThemeMode
import com.randomtalk.videochat.domain.model.GenderOption
import com.randomtalk.videochat.domain.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserPreferencesRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ADULT_CONFIRMED = booleanPreferencesKey("adult_confirmed")
        val GUIDELINES_ACCEPTED = booleanPreferencesKey("guidelines_accepted")
        val COUNTRY_CODE = stringPreferencesKey("selected_country_code")
        val SELF_GENDER = stringPreferencesKey("self_gender")
        val PREFERRED_GENDER = stringPreferencesKey("preferred_gender")
        val LOW_BANDWIDTH = booleanPreferencesKey("low_bandwidth_mode")
    }

    val preferencesFlow: Flow<UserPreferences> = dataStore.data.map { prefs ->
        UserPreferences(
            themeMode = prefs[Keys.THEME_MODE]?.let {
                runCatching { AppThemeMode.valueOf(it) }.getOrNull()
            } ?: AppThemeMode.SYSTEM,
            isAdultConfirmed = prefs[Keys.ADULT_CONFIRMED] ?: false,
            guidelinesAccepted = prefs[Keys.GUIDELINES_ACCEPTED] ?: false,
            selectedCountryCode = prefs[Keys.COUNTRY_CODE] ?: "GLOBAL",
            selfGender = prefs[Keys.SELF_GENDER]?.let {
                runCatching { GenderOption.valueOf(it) }.getOrNull()
            } ?: GenderOption.ANY,
            preferredGender = prefs[Keys.PREFERRED_GENDER]?.let {
                runCatching { GenderOption.valueOf(it) }.getOrNull()
            } ?: GenderOption.ANY,
            lowBandwidthMode = prefs[Keys.LOW_BANDWIDTH] ?: false
        )
    }

    suspend fun confirmAdultAndGuidelines() {
        dataStore.edit { prefs ->
            prefs[Keys.ADULT_CONFIRMED] = true
            prefs[Keys.GUIDELINES_ACCEPTED] = true
        }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setSelectedCountry(countryCode: String) {
        dataStore.edit { it[Keys.COUNTRY_CODE] = countryCode }
    }

    suspend fun setSelfGender(gender: GenderOption) {
        dataStore.edit { it[Keys.SELF_GENDER] = gender.name }
    }

    suspend fun setPreferredGender(gender: GenderOption) {
        dataStore.edit { it[Keys.PREFERRED_GENDER] = gender.name }
    }

    suspend fun setLowBandwidthMode(enabled: Boolean) {
        dataStore.edit { it[Keys.LOW_BANDWIDTH] = enabled }
    }

    suspend fun clearAll() {
        dataStore.edit { it.clear() }
    }

    companion object {
        val DEFAULT_PREFERENCES = UserPreferences()
    }
}
