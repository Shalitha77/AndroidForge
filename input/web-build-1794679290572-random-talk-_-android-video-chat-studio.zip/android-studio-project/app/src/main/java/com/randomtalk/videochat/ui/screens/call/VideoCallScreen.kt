package com.randomtalk.videochat.ui.screens.call

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.DataSaverOn
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VideocamOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.randomtalk.videochat.domain.model.CallConnectionState
import com.randomtalk.videochat.ui.screens.safety.ReportUserSheet
import com.randomtalk.videochat.ui.theme.CrimsonDanger
import com.randomtalk.videochat.ui.theme.EmeraldOnline
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

@Composable
fun VideoCallScreen(
    onExitCall: () -> Unit,
    viewModel: VideoCallViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val activity = context as Activity
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var hasPermissions by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasPermissions = (grants[Manifest.permission.CAMERA] == true) &&
            (grants[Manifest.permission.RECORD_AUDIO] == true)
    }

    LaunchedEffect(Unit) {
        if (!hasPermissions) {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    if (!hasPermissions) {
        PermissionGateView(
            onRequestPermissions = {
                permissionLauncher.launch(
                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                )
            },
            onCancel = onExitCall
        )
        return
    }

    var showReportSheet by remember { mutableStateOf(false) }

    val localRenderer = remember { SurfaceViewRenderer(context) }
    val remoteRenderer = remember { SurfaceViewRenderer(context) }

    DisposableEffect(Unit) {
        val eglContext = viewModel.webRtcClient.eglBase.eglBaseContext
        remoteRenderer.init(eglContext, null)
        remoteRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
        remoteRenderer.setEnableHardwareScaler(true)

        localRenderer.init(eglContext, null)
        localRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
        localRenderer.setZOrderMediaOverlay(true)
        localRenderer.setMirror(true)

        viewModel.initializeMediaAndStartSearch(localRenderer, remoteRenderer)

        onDispose {
            localRenderer.release()
            remoteRenderer.release()
        }
    }

    // IMPORTANT: Zero ads are ever rendered on top of or during an active video call screen.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060911))
    ) {
        // Remote peer WebRTC video renderer
        AndroidView(
            factory = { remoteRenderer },
            modifier = Modifier.fillMaxSize()
        )

        // Searching / Reconnecting overlay when remote stream isn't active
        if (state.connectionState != CallConnectionState.CONNECTED) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC070B14)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = state.statusMessage,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                }
            }
        }

        // Top Bar Scrim: Connection Status + Partner Country + Report/Block
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xB3000000), Color.Transparent)
                    )
                )
                .safeDrawingPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0x880F172A)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                if (state.connectionState == CallConnectionState.CONNECTED) {
                                    EmeraldOnline
                                } else {
                                    Color(0xFFF59E0B)
                                }
                            )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = state.partnerCountryLabel.ifBlank { state.connectionState.name },
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            if (state.currentSession != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = { viewModel.blockCurrentPartner() },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0x880F172A))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Block,
                            contentDescription = "Block user",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = { showReportSheet = true },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0x88DC2626))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Flag,
                            contentDescription = "Report user",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Local Camera Picture-in-Picture Preview
        Surface(
            shape = RoundedCornerShape(16.dp),
            shadowElevation = 6.dp,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 108.dp)
                .size(width = 108.dp, height = 152.dp)
        ) {
            if (state.isCameraEnabled) {
                AndroidView(
                    factory = { localRenderer },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1E293B)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VideocamOff,
                        contentDescription = "Camera off",
                        tint = Color.White
                    )
                }
            }
        }

        // Bottom Controls Bar
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xCC000000))
                    )
                )
                .safeDrawingPadding()
                .padding(horizontal = 16.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ControlCircleButton(
                icon = if (state.isMicMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                label = if (state.isMicMuted) "Unmute" else "Mute",
                active = !state.isMicMuted,
                onClick = viewModel::toggleMute
            )

            ControlCircleButton(
                icon = if (state.isCameraEnabled) Icons.Rounded.Videocam else Icons.Rounded.VideocamOff,
                label = "Cam",
                active = state.isCameraEnabled,
                onClick = viewModel::toggleCamera
            )

            ControlCircleButton(
                icon = Icons.Rounded.Cameraswitch,
                label = "Flip",
                active = true,
                onClick = viewModel::switchCamera
            )

            ControlCircleButton(
                icon = Icons.Rounded.DataSaverOn,
                label = if (state.isLowBandwidth) "Low BW" else "HD",
                active = !state.isLowBandwidth,
                onClick = viewModel::toggleLowBandwidth
            )

            IconButton(
                onClick = { viewModel.nextPartner(activity) },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
            ) {
                Icon(
                    imageVector = Icons.Rounded.SkipNext,
                    contentDescription = "Next user",
                    tint = Color.White
                )
            }

            IconButton(
                onClick = { viewModel.endCall(activity, onExitCall) },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(CrimsonDanger)
            ) {
                Icon(
                    imageVector = Icons.Rounded.CallEnd,
                    contentDescription = "End call",
                    tint = Color.White
                )
            }
        }
    }

    if (showReportSheet) {
        ReportUserSheet(
            onDismiss = { showReportSheet = false },
            onSubmitReport = { reason, details, alsoBlock ->
                showReportSheet = false
                viewModel.reportAndBlockCurrentPartner(reason, details, alsoBlock)
            }
        )
    }
}

@Composable
private fun ControlCircleButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(if (active) Color(0x881E293B) else Color(0xCCDC2626))
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color.White
        )
    }
}

@Composable
private fun PermissionGateView(
    onRequestPermissions: () -> Unit,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Camera & Microphone Access Required",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = "Random Talk uses your camera and microphone exclusively for live WebRTC peer-to-peer calls.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequestPermissions, modifier = Modifier.fillMaxWidth()) {
            Text("Grant Permissions")
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onCancel) {
            Text("Go Back")
        }
    }
}
