package com.randomtalk.videochat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.randomtalk.videochat.ads.AdMobManager
import com.randomtalk.videochat.ads.ConsentManager
import com.randomtalk.videochat.data.preferences.UserPreferencesRepository
import com.randomtalk.videochat.domain.model.AppThemeMode
import com.randomtalk.videochat.ui.navigation.RandomTalkNavGraph
import com.randomtalk.videochat.ui.theme.RandomTalkTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var preferencesRepository: UserPreferencesRepository

    @Inject
    lateinit var consentManager: ConsentManager

    @Inject
    lateinit var adMobManager: AdMobManager

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        consentManager.gatherConsent(
            activity = this,
            onConsentReady = { canRequestAds ->
                if (canRequestAds) {
                    adMobManager.initializeMobileAds(this)
                }
            }
        )

        setContent {
            val prefs by preferencesRepository.preferencesFlow.collectAsStateWithLifecycle(
                initialValue = UserPreferencesRepository.DEFAULT_PREFERENCES
            )

            val darkTheme = when (prefs.themeMode) {
                AppThemeMode.DARK -> true
                AppThemeMode.LIGHT -> false
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
            }

            RandomTalkTheme(darkTheme = darkTheme) {
                RandomTalkNavGraph(
                    preferences = prefs,
                    onShowPrivacyOptions = {
                        consentManager.showPrivacyOptionsForm(this) {}
                    }
                )
            }
        }
    }
}
