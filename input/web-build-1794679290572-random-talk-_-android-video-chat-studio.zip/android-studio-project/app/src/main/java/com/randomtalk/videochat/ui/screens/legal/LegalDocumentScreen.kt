package com.randomtalk.videochat.ui.screens.legal

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

enum class LegalDocType(val title: String) {
    PRIVACY_POLICY("Privacy Policy"),
    TERMS("Terms & Conditions"),
    COMMUNITY_GUIDELINES("Community Guidelines")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalDocumentScreen(
    docType: LegalDocType,
    onBack: () -> Unit
) {
    Scaffold(
        modifier = Modifier.safeDrawingPadding(),
        topBar = {
            TopAppBar(
                title = { Text(docType.title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text(
                text = when (docType) {
                    LegalDocType.PRIVACY_POLICY -> PRIVACY_TEXT
                    LegalDocType.TERMS -> TERMS_TEXT
                    LegalDocType.COMMUNITY_GUIDELINES -> GUIDELINES_TEXT
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}

private const val PRIVACY_TEXT = """Random Talk Privacy Policy

1. Data We Process
• Anonymous or Optional Google Firebase Authentication UID (never shared publicly with other callers).
• Country & match preference filters stored in Firebase Realtime Database for matchmaking.
• Ephemeral WebRTC signaling messages (SDP offer/answer and ICE candidates) automatically removed after calls end.
• Safety reports and block lists to prevent abuse and avoid re-matching blocked peers.

2. Video & Audio Streams
All real-time video and audio streams occur peer-to-peer via WebRTC encrypted DTLS-SRTP channels. Random Talk does not record or store live video or audio on backend servers.

3. Advertising & Consent
We use Google AdMob and Google User Messaging Platform (UMP) to honor GDPR/CCPA consent preferences. Ads are never displayed over active video calls.

4. Account Deletion
You may permanently delete your account and associated Realtime Database records at any time from Settings -> Delete Account & Data."""

private const val TERMS_TEXT = """Random Talk Terms & Conditions

1. Eligibility
You must be at least 18 years old to use Random Talk.

2. Acceptable Use
You agree not to transmit illegal content, nudity, hate speech, harassment, threats, or automated spam. Violations result in immediate suspension.

3. Disclaimer
Random Talk connects users randomly worldwide. Exercise personal caution and never share private financial or identifying details during video chats."""

private const val GUIDELINES_TEXT = """Random Talk Community Guidelines

• Be Respectful: Treat strangers with courtesy and dignity.
• No Nudity or Explicit Conduct: Keep clothing and surroundings appropriate for a public conversation.
• No Harassment or Hate Speech: Bullying, slurs, or intimidation are strictly prohibited.
• Adults Only (18+): Report anyone who appears underage immediately using the Report button.
• Zero Spam or Scams: Commercial solicitation, bots, and phishing links lead to permanent bans."""
