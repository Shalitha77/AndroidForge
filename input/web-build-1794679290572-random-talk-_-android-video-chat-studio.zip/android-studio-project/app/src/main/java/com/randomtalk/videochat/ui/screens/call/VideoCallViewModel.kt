package com.randomtalk.videochat.ui.screens.call

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.randomtalk.videochat.ads.AdMobManager
import com.randomtalk.videochat.data.auth.AuthRepository
import com.randomtalk.videochat.data.matchmaking.MatchmakingRepository
import com.randomtalk.videochat.data.matchmaking.SignalingEvent
import com.randomtalk.videochat.data.preferences.UserPreferencesRepository
import com.randomtalk.videochat.data.safety.SafetyRepository
import com.randomtalk.videochat.domain.model.CallConnectionState
import com.randomtalk.videochat.domain.model.CallSession
import com.randomtalk.videochat.domain.model.CountryOption
import com.randomtalk.videochat.domain.model.ReportReason
import com.randomtalk.videochat.webrtc.IceServerProvider
import com.randomtalk.videochat.webrtc.WebRtcCallbacks
import com.randomtalk.videochat.webrtc.WebRtcClient
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.webrtc.IceCandidate
import org.webrtc.PeerConnection
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import javax.inject.Inject

data class VideoCallUiState(
    val connectionState: CallConnectionState = CallConnectionState.SEARCHING,
    val currentSession: CallSession? = null,
    val isMicMuted: Boolean = false,
    val isCameraEnabled: Boolean = true,
    val isFrontCamera: Boolean = true,
    val isLowBandwidth: Boolean = false,
    val statusMessage: String = "Looking for a partner worldwide...",
    val partnerCountryLabel: String = "",
    val reportSubmittedMessage: String? = null
)

@HiltViewModel
class VideoCallViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val matchmakingRepository: MatchmakingRepository,
    private val safetyRepository: SafetyRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val iceServerProvider: IceServerProvider,
    val webRtcClient: WebRtcClient,
    private val adMobManager: AdMobManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(VideoCallUiState())
    val uiState: StateFlow<VideoCallUiState> = _uiState.asStateFlow()

    private var remoteRenderer: SurfaceViewRenderer? = null
    private var currentRemoteVideoTrack: VideoTrack? = null
    private var matchListenerJob: Job? = null
    private var signalingJob: Job? = null
    private var reconnectAttempts = 0

    fun initializeMediaAndStartSearch(
        localRenderer: SurfaceViewRenderer,
        remoteSurface: SurfaceViewRenderer
    ) {
        remoteRenderer = remoteSurface
        viewModelScope.launch {
            val prefs = preferencesRepository.preferencesFlow.first()
            _uiState.update { it.copy(isLowBandwidth = prefs.lowBandwidthMode) }
            webRtcClient.startLocalMedia(localRenderer, prefs.lowBandwidthMode)
            startMatchSearch()
        }
    }

    fun startMatchSearch() {
        cancelActiveJobsAndRoom()
        viewModelScope.launch {
            val user = authRepository.ensureSignedIn().getOrNull() ?: run {
                _uiState.update {
                    it.copy(
                        connectionState = CallConnectionState.ERROR,
                        statusMessage = "Unable to authenticate session."
                    )
                }
                return@launch
            }

            val prefs = preferencesRepository.preferencesFlow.first()
            _uiState.update {
                it.copy(
                    connectionState = CallConnectionState.SEARCHING,
                    currentSession = null,
                    statusMessage = "Finding a compatible match...",
                    partnerCountryLabel = "",
                    reportSubmittedMessage = null
                )
            }

            // Listen for passive match assignment in case another peer pairs with us first
            matchListenerJob = launch {
                matchmakingRepository.observeMatchAssignment(user.uid).collect { session ->
                    if (session != null && _uiState.value.currentSession?.roomId != session.roomId) {
                        onMatchFound(session)
                    }
                }
            }

            val immediateMatch = matchmakingRepository.enterQueueAndFindMatch(
                uid = user.uid,
                countryCode = prefs.selectedCountryCode,
                selfGender = prefs.selfGender,
                preferredGender = prefs.preferredGender
            ).getOrNull()

            if (immediateMatch != null && _uiState.value.currentSession?.roomId != immediateMatch.roomId) {
                onMatchFound(immediateMatch)
            }
        }
    }

    private fun onMatchFound(session: CallSession) {
        matchListenerJob?.cancel()
        reconnectAttempts = 0
        val country = CountryOption.byCode(session.partnerCountryCode)
        _uiState.update {
            it.copy(
                connectionState = CallConnectionState.MATCHED_SIGNALING,
                currentSession = session,
                partnerCountryLabel = "${country.flagEmoji} ${country.name}",
                statusMessage = "Matched! Negotiating encrypted stream..."
            )
        }

        viewModelScope.launch {
            val iceServers = iceServerProvider.getIceServers()
            webRtcClient.createPeerConnection(
                iceServers = iceServers,
                callbacks = object : WebRtcCallbacks {
                    override fun onLocalIceCandidate(candidate: IceCandidate) {
                        viewModelScope.launch {
                            matchmakingRepository.sendIceCandidate(session.roomId, session.localUid, candidate)
                        }
                    }

                    override fun onIceConnectionStateChanged(state: PeerConnection.IceConnectionState) {
                        handleIceStateChange(session, state)
                    }

                    override fun onRemoteVideoTrackReceived(track: VideoTrack) {
                        currentRemoteVideoTrack = track
                        remoteRenderer?.let { track.addSink(it) }
                    }

                    override fun onRenegotiationNeeded() = Unit
                }
            )

            signalingJob = launch {
                matchmakingRepository.observeRoomSignals(session).collect { event ->
                    when (event) {
                        is SignalingEvent.RemoteOffer -> {
                            val offerSdp = SessionDescription(SessionDescription.Type.OFFER, event.sdp)
                            webRtcClient.setRemoteDescription(offerSdp) {
                                webRtcClient.createAnswer { answer ->
                                    viewModelScope.launch {
                                        matchmakingRepository.sendAnswer(session.roomId, session.localUid, answer)
                                    }
                                }
                            }
                        }
                        is SignalingEvent.RemoteAnswer -> {
                            val answerSdp = SessionDescription(SessionDescription.Type.ANSWER, event.sdp)
                            webRtcClient.setRemoteDescription(answerSdp)
                        }
                        is SignalingEvent.RemoteIceCandidate -> {
                            webRtcClient.addIceCandidate(
                                IceCandidate(event.sdpMid, event.sdpMLineIndex, event.sdp)
                            )
                        }
                        SignalingEvent.PartnerDisconnected -> {
                            _uiState.update {
                                it.copy(
                                    connectionState = CallConnectionState.PARTNER_LEFT,
                                    statusMessage = "Partner disconnected. Finding next user..."
                                )
                            }
                            delay(1_200)
                            startMatchSearch()
                        }
                    }
                }
            }

            if (session.isOfferer) {
                _uiState.update { it.copy(connectionState = CallConnectionState.CONNECTING_ICE) }
                webRtcClient.createOffer(iceRestart = false) { offer ->
                    viewModelScope.launch {
                        matchmakingRepository.sendOffer(session.roomId, session.localUid, offer)
                    }
                }
            }
        }
    }

    private fun handleIceStateChange(session: CallSession, state: PeerConnection.IceConnectionState) {
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED,
            PeerConnection.IceConnectionState.COMPLETED -> {
                reconnectAttempts = 0
                _uiState.update {
                    it.copy(
                        connectionState = CallConnectionState.CONNECTED,
                        statusMessage = "Connected"
                    )
                }
            }
            PeerConnection.IceConnectionState.DISCONNECTED -> {
                if (reconnectAttempts < 2 && session.isOfferer) {
                    reconnectAttempts++
                    _uiState.update {
                        it.copy(
                            connectionState = CallConnectionState.RECONNECTING,
                            statusMessage = "Connection unstable. Reconnecting..."
                        )
                    }
                    viewModelScope.launch {
                        delay(1_500)
                        webRtcClient.createOffer(iceRestart = true) { offer ->
                            viewModelScope.launch {
                                matchmakingRepository.sendOffer(session.roomId, session.localUid, offer)
                            }
                        }
                    }
                }
            }
            PeerConnection.IceConnectionState.FAILED -> {
                _uiState.update {
                    it.copy(
                        connectionState = CallConnectionState.ERROR,
                        statusMessage = "Network unreachable. Switching to next partner..."
                    )
                }
                viewModelScope.launch {
                    delay(1_200)
                    startMatchSearch()
                }
            }
            else -> Unit
        }
    }

    fun nextPartner(activity: Activity) {
        val wasConnected = _uiState.value.connectionState == CallConnectionState.CONNECTED
        cancelActiveJobsAndRoom()
        if (wasConnected) {
            // Policy: interstitial only AFTER completed call session ends, never over active video
            adMobManager.maybeShowPostSessionInterstitial(
                activity = activity,
                isCallActive = false
            ) {
                startMatchSearch()
            }
        } else {
            startMatchSearch()
        }
    }

    fun endCall(activity: Activity, onFinished: () -> Unit) {
        val wasConnected = _uiState.value.connectionState == CallConnectionState.CONNECTED
        cancelActiveJobsAndRoom()
        if (wasConnected) {
            adMobManager.maybeShowPostSessionInterstitial(
                activity = activity,
                isCallActive = false
            ) {
                onFinished()
            }
        } else {
            onFinished()
        }
    }

    fun toggleMute() {
        val nextMuted = !_uiState.value.isMicMuted
        webRtcClient.setMicMuted(nextMuted)
        _uiState.update { it.copy(isMicMuted = nextMuted) }
    }

    fun toggleCamera() {
        val nextEnabled = !_uiState.value.isCameraEnabled
        webRtcClient.setCameraEnabled(nextEnabled)
        _uiState.update { it.copy(isCameraEnabled = nextEnabled) }
    }

    fun switchCamera() {
        webRtcClient.switchCamera { isFront ->
            _uiState.update { it.copy(isFrontCamera = isFront) }
        }
    }

    fun toggleLowBandwidth() {
        val next = !_uiState.value.isLowBandwidth
        webRtcClient.setLowBandwidthMode(next)
        _uiState.update { it.copy(isLowBandwidth = next) }
        viewModelScope.launch {
            preferencesRepository.setLowBandwidthMode(next)
        }
    }

    fun reportAndBlockCurrentPartner(reason: ReportReason, details: String, alsoBlock: Boolean) {
        val session = _uiState.value.currentSession ?: return
        viewModelScope.launch {
            safetyRepository.reportUser(
                reporterUid = session.localUid,
                reportedUid = session.partnerUid,
                roomId = session.roomId,
                reason = reason,
                details = details,
                alsoBlock = alsoBlock
            )
            _uiState.update {
                it.copy(reportSubmittedMessage = "Report submitted. Finding a new match...")
            }
            cancelActiveJobsAndRoom()
            delay(800)
            startMatchSearch()
        }
    }

    fun blockCurrentPartner() {
        val session = _uiState.value.currentSession ?: return
        viewModelScope.launch {
            safetyRepository.blockUser(session.localUid, session.partnerUid)
            cancelActiveJobsAndRoom()
            startMatchSearch()
        }
    }

    private fun cancelActiveJobsAndRoom() {
        matchListenerJob?.cancel()
        signalingJob?.cancel()
        currentRemoteVideoTrack?.let { track ->
            remoteRenderer?.let { renderer -> track.removeSink(renderer) }
        }
        currentRemoteVideoTrack = null
        webRtcClient.closePeerConnectionOnly()

        val activeSession = _uiState.value.currentSession
        val uid = authRepository.currentUser?.uid
        viewModelScope.launch {
            if (activeSession != null) {
                matchmakingRepository.endRoom(activeSession.roomId, activeSession.localUid)
            }
            if (uid != null) {
                matchmakingRepository.leaveQueue(uid)
            }
        }
    }

    override fun onCleared() {
        cancelActiveJobsAndRoom()
        webRtcClient.releaseAll()
        super.onCleared()
    }
}
