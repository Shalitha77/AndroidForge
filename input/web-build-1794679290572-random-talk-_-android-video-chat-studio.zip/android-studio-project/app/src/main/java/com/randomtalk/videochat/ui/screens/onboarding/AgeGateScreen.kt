package com.randomtalk.videochat.ui.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.randomtalk.videochat.data.preferences.UserPreferencesRepository
import com.randomtalk.videochat.ui.theme.RandomTalkGradients
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AgeGateViewModel @Inject constructor(
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {
    suspend fun confirm() = preferencesRepository.confirmAdultAndGuidelines()
}

@Composable
fun AgeGateScreen(
    onAccepted: () -> Unit,
    onOpenGuidelines: () -> Unit,
    onOpenPrivacy: () -> Unit,
    viewModel: AgeGateViewModel = hiltViewModel()
) {
    var ageChecked by remember { mutableStateOf(false) }
    var guidelinesChecked by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RandomTalkGradients.homeBackdrop(isDark))
            .safeDrawingPadding()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Spacer(Modifier.height(16.dp))
            Icon(
                imageVector = Icons.Rounded.VerifiedUser,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Welcome to Random Talk",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Connect worldwide with real-time peer-to-peer video conversations. Before entering, confirm age eligibility and community safety rules.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(24.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.padding(6.dp))
                        Text(
                            text = "Safety & Privacy Commitments",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "• Strictly 18+ only. Underage accounts are immediately blocked.\n" +
                            "• Zero tolerance for nudity, harassment, hate speech, or spam.\n" +
                            "• Video & audio stream peer-to-peer via WebRTC without server recording.\n" +
                            "• Your profile never displays personal email or real identity publicly.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(checked = ageChecked, onCheckedChange = { ageChecked = it })
                Text(
                    text = "I confirm that I am at least 18 years of age.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(checked = guidelinesChecked, onCheckedChange = { guidelinesChecked = it })
                Text(
                    text = "I agree to follow the Community Guidelines and Privacy Policy.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = onOpenGuidelines) {
                    Text("Community Guidelines")
                }
                TextButton(onClick = onOpenPrivacy) {
                    Text("Privacy Policy")
                }
            }
        }

        Button(
            onClick = {
                scope.launch {
                    viewModel.confirm()
                    onAccepted()
                }
            },
            enabled = ageChecked && guidelinesChecked,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) {
            Text(
                text = "Continue to Random Talk",
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
