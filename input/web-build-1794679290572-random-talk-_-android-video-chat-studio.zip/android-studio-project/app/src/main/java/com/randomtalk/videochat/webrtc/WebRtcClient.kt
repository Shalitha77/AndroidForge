package com.randomtalk.videochat.webrtc

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpParameters
import org.webrtc.RtpSender
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.audio.JavaAudioDeviceModule
import javax.inject.Inject

interface WebRtcCallbacks {
    fun onLocalIceCandidate(candidate: IceCandidate)
    fun onIceConnectionStateChanged(state: PeerConnection.IceConnectionState)
    fun onRemoteVideoTrackReceived(track: VideoTrack)
    fun onRenegotiationNeeded()
}

class WebRtcClient @Inject constructor(
    @ApplicationContext private val context: Context
) {
    val eglBase: EglBase = EglBase.create()

    private val peerConnectionFactory: PeerConnectionFactory by lazy {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )

        val audioDeviceModule = JavaAudioDeviceModule.builder(context)
            .setUseHardwareAcousticEchoCanceler(true)
            .setUseHardwareNoiseSuppressor(true)
            .createAudioDeviceModule()

        PeerConnectionFactory.builder()
            .setAudioDeviceModule(audioDeviceModule)
            .setVideoEncoderFactory(
                DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
            )
            .setVideoDecoderFactory(
                DefaultVideoDecoderFactory(eglBase.eglBaseContext)
            )
            .createPeerConnectionFactory()
    }

    private var peerConnection: PeerConnection? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var localVideoSource: VideoSource? = null
    private var localAudioSource: AudioSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var localAudioTrack: AudioTrack? = null
    private var videoSender: RtpSender? = null
    private var localRenderer: SurfaceViewRenderer? = null

    private var isFrontCamera = true
    private var isLowBandwidth = false

    private val _iceState = MutableStateFlow(PeerConnection.IceConnectionState.NEW)
    val iceState: StateFlow<PeerConnection.IceConnectionState> = _iceState.asStateFlow()

    fun startLocalMedia(
        renderer: SurfaceViewRenderer,
        lowBandwidth: Boolean
    ) {
        isLowBandwidth = lowBandwidth
        localRenderer = renderer

        val enumerator = Camera2Enumerator(context)
        val deviceNames = enumerator.deviceNames
        val frontName = deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
        val fallbackName = deviceNames.firstOrNull()
        val chosenCamera = frontName ?: fallbackName ?: return
        isFrontCamera = (chosenCamera == frontName)

        videoCapturer = enumerator.createCapturer(chosenCamera, null)
        surfaceTextureHelper = SurfaceTextureHelper.create("WebRtcCaptureThread", eglBase.eglBaseContext)
        localVideoSource = peerConnectionFactory.createVideoSource(videoCapturer?.isScreencast ?: false)
        videoCapturer?.initialize(surfaceTextureHelper, context, localVideoSource?.capturerObserver)

        val width = if (lowBandwidth) 480 else 720
        val height = if (lowBandwidth) 360 else 1280
        val fps = if (lowBandwidth) 15 else 30
        videoCapturer?.startCapture(width, height, fps)

        localVideoTrack = peerConnectionFactory.createVideoTrack("LOCAL_VIDEO", localVideoSource).apply {
            setEnabled(true)
            addSink(renderer)
        }

        val audioConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
        }
        localAudioSource = peerConnectionFactory.createAudioSource(audioConstraints)
        localAudioTrack = peerConnectionFactory.createAudioTrack("LOCAL_AUDIO", localAudioSource).apply {
            setEnabled(true)
        }
    }

    fun createPeerConnection(
        iceServers: List<PeerConnection.IceServer>,
        callbacks: WebRtcCallbacks
    ) {
        closePeerConnectionOnly()

        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            iceCandidatePoolSize = 4
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
        }

        peerConnection = peerConnectionFactory.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onIceCandidate(candidate: IceCandidate) {
                    callbacks.onLocalIceCandidate(candidate)
                }

                override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) {
                    _iceState.value = newState
                    callbacks.onIceConnectionStateChanged(newState)
                }

                override fun onTrack(transceiver: RtpTransceiver) {
                    val track = transceiver.receiver.track()
                    if (track is VideoTrack) {
                        callbacks.onRemoteVideoTrackReceived(track)
                    }
                }

                override fun onRenegotiationNeeded() {
                    callbacks.onRenegotiationNeeded()
                }

                override fun onSignalingChange(state: PeerConnection.SignalingState?) = Unit
                override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) = Unit
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) = Unit
                override fun onAddStream(stream: MediaStream?) = Unit
                override fun onRemoveStream(stream: MediaStream?) = Unit
                override fun onDataChannel(channel: DataChannel?) = Unit
            }
        )

        localVideoTrack?.let { vTrack ->
            videoSender = peerConnection?.addTrack(vTrack, listOf("RANDOM_TALK_STREAM"))
            applyBandwidthProfile(isLowBandwidth)
        }
        localAudioTrack?.let { aTrack ->
            peerConnection?.addTrack(aTrack, listOf("RANDOM_TALK_STREAM"))
        }
    }

    fun createOffer(iceRestart: Boolean = false, onCreated: (SessionDescription) -> Unit) {
        val pc = peerConnection ?: return
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
            if (iceRestart) {
                mandatory.add(MediaConstraints.KeyValuePair("IceRestart", "true"))
            }
        }
        pc.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc.setLocalDescription(SimpleSdpObserver(), desc)
                onCreated(desc)
            }
        }, constraints)
    }

    fun createAnswer(onCreated: (SessionDescription) -> Unit) {
        val pc = peerConnection ?: return
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
        }
        pc.createAnswer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc.setLocalDescription(SimpleSdpObserver(), desc)
                onCreated(desc)
            }
        }, constraints)
    }

    fun setRemoteDescription(sdp: SessionDescription, onSuccess: () -> Unit = {}) {
        peerConnection?.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() = onSuccess()
        }, sdp)
    }

    fun addIceCandidate(candidate: IceCandidate) {
        peerConnection?.addIceCandidate(candidate)
    }

    fun switchCamera(onSwitched: (isFront: Boolean) -> Unit) {
        videoCapturer?.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
            override fun onCameraSwitchDone(isFrontFacing: Boolean) {
                isFrontCamera = isFrontFacing
                localRenderer?.setMirror(isFrontFacing)
                onSwitched(isFrontFacing)
            }

            override fun onCameraSwitchError(errorDescription: String?) = Unit
        })
    }

    fun setMicMuted(muted: Boolean) {
        localAudioTrack?.setEnabled(!muted)
    }

    fun setCameraEnabled(enabled: Boolean) {
        localVideoTrack?.setEnabled(enabled)
    }

    fun setLowBandwidthMode(enabled: Boolean) {
        isLowBandwidth = enabled
        runCatching {
            videoCapturer?.changeCaptureFormat(
                if (enabled) 480 else 720,
                if (enabled) 360 else 1280,
                if (enabled) 15 else 30
            )
        }
        applyBandwidthProfile(enabled)
    }

    private fun applyBandwidthProfile(lowBandwidth: Boolean) {
        val sender = videoSender ?: return
        val params = sender.parameters ?: return
        if (params.encodings.isNotEmpty()) {
            params.encodings.forEach { encoding ->
                encoding.maxBitrateBps = if (lowBandwidth) 250_000 else 1_200_000
                encoding.maxFramerate = if (lowBandwidth) 15 else 30
            }
            params.degradationPreference = if (lowBandwidth) {
                RtpParameters.DegradationPreference.MAINTAIN_FRAMERATE
            } else {
                RtpParameters.DegradationPreference.BALANCED
            }
            sender.parameters = params
        }
    }

    fun closePeerConnectionOnly() {
        videoSender = null
        peerConnection?.close()
        peerConnection?.dispose()
        peerConnection = null
    }

    fun releaseAll() {
        closePeerConnectionOnly()
        runCatching { videoCapturer?.stopCapture() }
        videoCapturer?.dispose()
        videoCapturer = null
        localVideoTrack?.dispose()
        localVideoTrack = null
        localAudioTrack?.dispose()
        localAudioTrack = null
        localVideoSource?.dispose()
        localVideoSource = null
        localAudioSource?.dispose()
        localAudioSource = null
        surfaceTextureHelper?.dispose()
        surfaceTextureHelper = null
        eglBase.release()
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription) = Unit
        override fun onSetSuccess() = Unit
        override fun onCreateFailure(error: String?) = Unit
        override fun onSetFailure(error: String?) = Unit
    }
}
