package com.randomtalk.videochat.data.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.functions.FirebaseFunctions
import com.randomtalk.videochat.BuildConfig
import com.randomtalk.videochat.data.preferences.UserPreferencesRepository
import com.randomtalk.videochat.domain.model.GenderOption
import com.randomtalk.videochat.domain.model.UserProfile
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val database: FirebaseDatabase,
    private val functions: FirebaseFunctions,
    private val preferencesRepository: UserPreferencesRepository
) {
    val authStateFlow: Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    suspend fun ensureSignedIn(): Result<FirebaseUser> = runCatching {
        auth.currentUser?.let { existing ->
            syncUserProfileIfMissing(existing)
            return@runCatching existing
        }
        val result = auth.signInAnonymously().await()
        val user = result.user ?: error("Anonymous authentication returned null user")
        syncUserProfileIfMissing(user)
        user
    }

    suspend fun signInOrLinkWithGoogle(context: Context): Result<FirebaseUser> = runCatching {
        val webClientId = BuildConfig.GOOGLE_WEB_CLIENT_ID
        require(webClientId.isNotBlank()) {
            "GOOGLE_WEB_CLIENT_ID is missing. Configure it in local.properties."
        }

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        val credentialManager = CredentialManager.create(context)
        val credentialResponse = credentialManager.getCredential(context, request)
        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credentialResponse.credential.data)
        val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)

        val current = auth.currentUser
        val user = if (current != null && current.isAnonymous) {
            runCatching {
                current.linkWithCredential(firebaseCredential).await().user
            }.getOrElse {
                auth.signInWithCredential(firebaseCredential).await().user
            }
        } else {
            auth.signInWithCredential(firebaseCredential).await().user
        } ?: error("Google sign-in failed to produce a FirebaseUser")

        syncUserProfileIfMissing(user)
        user
    }

    suspend fun updateProfilePreferences(
        selfGender: GenderOption,
        preferredGender: GenderOption,
        countryCode: String
    ): Result<Unit> = runCatching {
        val user = auth.currentUser ?: return@runCatching
        val updates = mapOf(
            "selfGender" to selfGender.code,
            "preferredGender" to preferredGender.code,
            "preferredCountryCode" to countryCode,
            "isAnonymous" to user.isAnonymous,
            "updatedAt" to ServerValue.TIMESTAMP
        )
        database.reference.child("users").child(user.uid).updateChildren(updates).await()
    }

    suspend fun checkAccountBanned(uid: String): Boolean {
        return runCatching {
            val snapshot = database.reference
                .child("moderation")
                .child(uid)
                .child("isBanned")
                .get()
                .await()
            snapshot.getValue(Boolean::class.java) == true
        }.getOrDefault(false)
    }

    suspend fun signOut() {
        auth.signOut()
    }

    suspend fun deleteAccount(): Result<Unit> = runCatching {
        val user = auth.currentUser ?: error("No authenticated user")
        // Clean up RTDB records server-side before deleting Firebase Auth account
        runCatching {
            functions.getHttpsCallable("deleteUserAccountData").call().await()
        }.onFailure {
            // Fallback client cleanup within owner's permitted nodes
            database.reference.child("matchmaking_queue").child(user.uid).removeValue().await()
            database.reference.child("presence").child(user.uid).removeValue().await()
            database.reference.child("users").child(user.uid).removeValue().await()
        }
        user.delete().await()
        preferencesRepository.clearAll()
    }

    private suspend fun syncUserProfileIfMissing(user: FirebaseUser) {
        val ref = database.reference.child("users").child(user.uid)
        val snapshot = ref.get().await()
        if (!snapshot.exists()) {
            val initialProfile = mapOf(
                "uid" to user.uid,
                "isAnonymous" to user.isAnonymous,
                "selfGender" to GenderOption.ANY.code,
                "preferredGender" to GenderOption.ANY.code,
                "preferredCountryCode" to "GLOBAL",
                "createdAt" to ServerValue.TIMESTAMP
            )
            ref.setValue(initialProfile).await()
        } else {
            ref.child("isAnonymous").setValue(user.isAnonymous)
        }
    }
}
