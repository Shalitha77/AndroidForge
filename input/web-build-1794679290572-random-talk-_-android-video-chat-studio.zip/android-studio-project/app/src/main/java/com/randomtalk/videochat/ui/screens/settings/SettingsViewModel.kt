package com.randomtalk.videochat.ui.screens.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.randomtalk.videochat.ads.ConsentManager
import com.randomtalk.videochat.data.auth.AuthRepository
import com.randomtalk.videochat.data.preferences.UserPreferencesRepository
import com.randomtalk.videochat.domain.model.AppThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val lowBandwidthMode: Boolean = false,
    val uid: String = "",
    val isAnonymous: Boolean = true,
    val isPrivacyOptionsRequired: Boolean = false,
    val statusMessage: String? = null,
    val isWorking: Boolean = false
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val preferencesRepository: UserPreferencesRepository,
    consentManager: ConsentManager
) : ViewModel() {

    private val status = MutableStateFlow<String?>(null)
    private val working = MutableStateFlow(false)

    val uiState: StateFlow<SettingsUiState> = combine(
        preferencesRepository.preferencesFlow,
        authRepository.authStateFlow,
        consentManager.isPrivacyOptionsRequired,
        status,
        working
    ) { prefs, user, privacyRequired, msg, isWorking ->
        SettingsUiState(
            themeMode = prefs.themeMode,
            lowBandwidthMode = prefs.lowBandwidthMode,
            uid = user?.uid ?: "Not signed in",
            isAnonymous = user?.isAnonymous ?: true,
            isPrivacyOptionsRequired = privacyRequired,
            statusMessage = msg,
            isWorking = isWorking
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState()
    )

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun setLowBandwidthMode(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setLowBandwidthMode(enabled)
        }
    }

    fun linkGoogleAccount(context: Context) {
        viewModelScope.launch {
            working.value = true
            authRepository.signInOrLinkWithGoogle(context)
                .onSuccess {
                    status.value = "Google account linked safely."
                }
                .onFailure {
                    status.value = it.localizedMessage ?: "Google sign-in failed."
                }
            working.value = false
        }
    }

    fun deleteAccount(onDeleted: () -> Unit) {
        viewModelScope.launch {
            working.value = true
            authRepository.deleteAccount()
                .onSuccess {
                    working.value = false
                    onDeleted()
                }
                .onFailure {
                    working.value = false
                    status.value = "Re-authentication may be required before account deletion."
                }
        }
    }
}
