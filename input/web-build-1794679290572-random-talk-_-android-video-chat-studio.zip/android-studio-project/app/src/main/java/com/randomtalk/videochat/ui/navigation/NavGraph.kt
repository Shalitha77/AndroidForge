package com.randomtalk.videochat.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.randomtalk.videochat.domain.model.UserPreferences
import com.randomtalk.videochat.ui.screens.call.VideoCallScreen
import com.randomtalk.videochat.ui.screens.home.HomeScreen
import com.randomtalk.videochat.ui.screens.legal.LegalDocumentScreen
import com.randomtalk.videochat.ui.screens.legal.LegalDocType
import com.randomtalk.videochat.ui.screens.onboarding.AgeGateScreen
import com.randomtalk.videochat.ui.screens.settings.SettingsScreen

object Routes {
    const val AGE_GATE = "age_gate"
    const val HOME = "home"
    const val VIDEO_CALL = "video_call"
    const val SETTINGS = "settings"
    const val LEGAL = "legal/{docType}"

    fun legal(type: LegalDocType): String = "legal/${type.name}"
}

@Composable
fun RandomTalkNavGraph(
    preferences: UserPreferences,
    onShowPrivacyOptions: () -> Unit
) {
    val navController = rememberNavController()
    val startDestination = if (preferences.isAdultConfirmed && preferences.guidelinesAccepted) {
        Routes.HOME
    } else {
        Routes.AGE_GATE
    }

    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = { fadeIn() },
        exitTransition = { fadeOut() }
    ) {
        composable(Routes.AGE_GATE) {
            AgeGateScreen(
                onAccepted = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.AGE_GATE) { inclusive = true }
                    }
                },
                onOpenGuidelines = {
                    navController.navigate(Routes.legal(LegalDocType.COMMUNITY_GUIDELINES))
                },
                onOpenPrivacy = {
                    navController.navigate(Routes.legal(LegalDocType.PRIVACY_POLICY))
                }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                onStartVideoChat = {
                    navController.navigate(Routes.VIDEO_CALL)
                },
                onOpenSettings = {
                    navController.navigate(Routes.SETTINGS)
                }
            )
        }

        composable(Routes.VIDEO_CALL) {
            VideoCallScreen(
                onExitCall = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onShowPrivacyOptions = onShowPrivacyOptions,
                onOpenLegalDoc = { docType ->
                    navController.navigate(Routes.legal(docType))
                },
                onAccountDeleted = {
                    navController.navigate(Routes.AGE_GATE) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Routes.LEGAL,
            arguments = listOf(navArgument("docType") { type = NavType.StringType })
        ) { backStackEntry ->
            val rawType = backStackEntry.arguments?.getString("docType") ?: LegalDocType.PRIVACY_POLICY.name
            val docType = runCatching { LegalDocType.valueOf(rawType) }
                .getOrDefault(LegalDocType.PRIVACY_POLICY)
            LegalDocumentScreen(
                docType = docType,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
