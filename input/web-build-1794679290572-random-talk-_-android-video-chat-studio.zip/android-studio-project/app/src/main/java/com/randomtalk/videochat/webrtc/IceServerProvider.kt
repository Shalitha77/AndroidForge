package com.randomtalk.videochat.webrtc

import com.google.firebase.functions.FirebaseFunctions
import com.randomtalk.videochat.BuildConfig
import kotlinx.coroutines.tasks.await
import org.webrtc.PeerConnection
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IceServerProvider @Inject constructor(
    private val functions: FirebaseFunctions
) {
    /**
     * Fetches ephemeral TURN credentials via Cloud Functions (recommended for production)
     * and falls back to BuildConfig STUN/TURN entries if configured in local.properties.
     */
    suspend fun getIceServers(): List<PeerConnection.IceServer> {
        val servers = mutableListOf(
            PeerConnection.IceServer.builder(BuildConfig.STUN_SERVER_URL).createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )

        val remoteServers = runCatching {
            val res = functions.getHttpsCallable("getTurnCredentials").call().await()
            @Suppress("UNCHECKED_CAST")
            val data = res.getData() as? Map<String, Any?> ?: emptyMap()
            @Suppress("UNCHECKED_CAST")
            val rawIceServers = data["iceServers"] as? List<Map<String, Any?>> ?: emptyList()

            rawIceServers.mapNotNull { entry ->
                val urls = (entry["urls"] as? List<*>)?.filterIsInstance<String>()
                    ?: (entry["urls"] as? String)?.let { listOf(it) }
                    ?: return@mapNotNull null

                val builder = PeerConnection.IceServer.builder(urls)
                (entry["username"] as? String)?.let { builder.setUsername(it) }
                (entry["credential"] as? String)?.let { builder.setPassword(it) }
                builder.createIceServer()
            }
        }.getOrDefault(emptyList())

        if (remoteServers.isNotEmpty()) {
            servers.addAll(remoteServers)
        } else if (BuildConfig.TURN_SERVER_URL.isNotBlank()) {
            val turnBuilder = PeerConnection.IceServer.builder(BuildConfig.TURN_SERVER_URL)
            if (BuildConfig.TURN_USERNAME.isNotBlank()) {
                turnBuilder.setUsername(BuildConfig.TURN_USERNAME)
            }
            if (BuildConfig.TURN_CREDENTIAL.isNotBlank()) {
                turnBuilder.setPassword(BuildConfig.TURN_CREDENTIAL)
            }
            servers.add(turnBuilder.createIceServer())
        }

        return servers
    }
}
