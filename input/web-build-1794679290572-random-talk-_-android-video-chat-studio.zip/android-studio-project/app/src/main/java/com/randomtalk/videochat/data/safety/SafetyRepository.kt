package com.randomtalk.videochat.data.safety

import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.randomtalk.videochat.domain.model.ReportReason
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SafetyRepository @Inject constructor(
    private val database: FirebaseDatabase
) {
    private val rootRef = database.reference

    suspend fun reportUser(
        reporterUid: String,
        reportedUid: String,
        roomId: String,
        reason: ReportReason,
        details: String,
        alsoBlock: Boolean
    ): Result<Unit> = runCatching {
        val reportRef = rootRef.child("reports").push()
        val reportId = reportRef.key ?: error("Unable to allocate report ID")

        val payload = mapOf(
            "reportId" to reportId,
            "reporterUid" to reporterUid,
            "reportedUid" to reportedUid,
            "roomId" to roomId,
            "reason" to reason.code,
            "details" to details.trim().take(500),
            "createdAt" to ServerValue.TIMESTAMP
        )
        reportRef.setValue(payload).await()

        if (alsoBlock) {
            blockUser(blockerUid = reporterUid, targetUid = reportedUid).getOrThrow()
        }
    }

    suspend fun blockUser(blockerUid: String, targetUid: String): Result<Unit> = runCatching {
        require(blockerUid != targetUid) { "Cannot block self" }
        val updates = hashMapOf<String, Any>(
            "/users/$blockerUid/blocked/$targetUid" to ServerValue.TIMESTAMP,
            "/blocked_by/$targetUid/$blockerUid" to true
        )
        rootRef.updateChildren(updates).await()
    }

    suspend fun getBlockedUserIds(uid: String): Set<String> {
        return runCatching {
            val snapshot = rootRef.child("users").child(uid).child("blocked").get().await()
            snapshot.children.mapNotNull { it.key }.toSet()
        }.getOrDefault(emptySet())
    }
}
