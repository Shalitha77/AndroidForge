package com.randomtalk.videochat.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.randomtalk.videochat.ads.ConsentManager
import com.randomtalk.videochat.data.auth.AuthRepository
import com.randomtalk.videochat.data.matchmaking.MatchmakingRepository
import com.randomtalk.videochat.data.preferences.UserPreferencesRepository
import com.randomtalk.videochat.domain.model.CountryOption
import com.randomtalk.videochat.domain.model.GenderOption
import com.randomtalk.videochat.domain.model.UserPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val onlineUsersCount: Int = 1,
    val selectedCountry: CountryOption = CountryOption.ALL_COUNTRIES.first(),
    val selfGender: GenderOption = GenderOption.ANY,
    val preferredGender: GenderOption = GenderOption.ANY,
    val isAuthReady: Boolean = false,
    val isBanned: Boolean = false,
    val canRequestAds: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val matchmakingRepository: MatchmakingRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val consentManager: ConsentManager
) : ViewModel() {

    private val authReady = MutableStateFlow(false)
    private val banned = MutableStateFlow(false)
    private val error = MutableStateFlow<String?>(null)

    val uiState: StateFlow<HomeUiState> = combine(
        matchmakingRepository.observeOnlineUsersCount(),
        preferencesRepository.preferencesFlow,
        authReady,
        banned,
        error
    ) { count, prefs: UserPreferences, ready, isBanned, err ->
        HomeUiState(
            onlineUsersCount = count,
            selectedCountry = CountryOption.byCode(prefs.selectedCountryCode),
            selfGender = prefs.selfGender,
            preferredGender = prefs.preferredGender,
            isAuthReady = ready,
            isBanned = isBanned,
            canRequestAds = consentManager.canRequestAds,
            errorMessage = err
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState(canRequestAds = consentManager.canRequestAds)
    )

    init {
        initializeSession()
    }

    private fun initializeSession() {
        viewModelScope.launch {
            authRepository.ensureSignedIn()
                .onSuccess { user ->
                    val isBanned = authRepository.checkAccountBanned(user.uid)
                    banned.value = isBanned
                    if (!isBanned) {
                        matchmakingRepository.registerPresence(user.uid)
                    }
                    authReady.value = true
                }
                .onFailure { throwable ->
                    error.value = throwable.localizedMessage ?: "Authentication failed"
                }
        }
    }

    fun selectCountry(country: CountryOption) {
        viewModelScope.launch {
            preferencesRepository.setSelectedCountry(country.code)
            val current = uiState.value
            authRepository.updateProfilePreferences(
                selfGender = current.selfGender,
                preferredGender = current.preferredGender,
                countryCode = country.code
            )
        }
    }

    fun selectPreferredGender(gender: GenderOption) {
        viewModelScope.launch {
            preferencesRepository.setPreferredGender(gender)
            val current = uiState.value
            authRepository.updateProfilePreferences(
                selfGender = current.selfGender,
                preferredGender = gender,
                countryCode = current.selectedCountry.code
            )
        }
    }

    fun selectSelfGender(gender: GenderOption) {
        viewModelScope.launch {
            preferencesRepository.setSelfGender(gender)
            val current = uiState.value
            authRepository.updateProfilePreferences(
                selfGender = gender,
                preferredGender = current.preferredGender,
                countryCode = current.selectedCountry.code
            )
        }
    }
}
