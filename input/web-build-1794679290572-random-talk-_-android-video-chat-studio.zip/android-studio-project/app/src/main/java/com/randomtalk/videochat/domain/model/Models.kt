package com.randomtalk.videochat.domain.model

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

enum class GenderOption(val code: String, val label: String) {
    ANY("ANY", "Everyone"),
    FEMALE("FEMALE", "Female"),
    MALE("MALE", "Male"),
    NON_BINARY("NON_BINARY", "Non-binary")
}

data class CountryOption(
    val code: String,
    val name: String,
    val flagEmoji: String,
    val supportsGenderFilter: Boolean = true
) {
    companion object {
        val ALL_COUNTRIES = listOf(
            CountryOption("GLOBAL", "Global (Worldwide)", "🌐", supportsGenderFilter = true),
            CountryOption("US", "United States", "🇺🇸", supportsGenderFilter = true),
            CountryOption("GB", "United Kingdom", "🇬🇧", supportsGenderFilter = true),
            CountryOption("CA", "Canada", "🇨🇦", supportsGenderFilter = true),
            CountryOption("DE", "Germany", "🇩🇪", supportsGenderFilter = true),
            CountryOption("FR", "France", "🇫🇷", supportsGenderFilter = true),
            CountryOption("JP", "Japan", "🇯🇵", supportsGenderFilter = true),
            CountryOption("BR", "Brazil", "🇧🇷", supportsGenderFilter = true),
            CountryOption("IN", "India", "🇮🇳", supportsGenderFilter = true),
            CountryOption("AU", "Australia", "🇦🇺", supportsGenderFilter = true),
            CountryOption("KR", "South Korea", "🇰🇷", supportsGenderFilter = true),
            CountryOption("ES", "Spain", "🇪🇸", supportsGenderFilter = true)
        )

        fun byCode(code: String): CountryOption =
            ALL_COUNTRIES.firstOrNull { it.code == code } ?: ALL_COUNTRIES.first()
    }
}

data class UserProfile(
    val uid: String = "",
    val isAnonymous: Boolean = true,
    val selfGender: GenderOption = GenderOption.ANY,
    val preferredGender: GenderOption = GenderOption.ANY,
    val preferredCountryCode: String = "GLOBAL",
    val isBanned: Boolean = false,
    val createdAt: Long = 0L
)

data class UserPreferences(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val isAdultConfirmed: Boolean = false,
    val guidelinesAccepted: Boolean = false,
    val selectedCountryCode: String = "GLOBAL",
    val selfGender: GenderOption = GenderOption.ANY,
    val preferredGender: GenderOption = GenderOption.ANY,
    val lowBandwidthMode: Boolean = false
)

enum class CallConnectionState {
    IDLE,
    SEARCHING,
    MATCHED_SIGNALING,
    CONNECTING_ICE,
    CONNECTED,
    RECONNECTING,
    PARTNER_LEFT,
    ERROR
}

data class CallSession(
    val roomId: String,
    val localUid: String,
    val partnerUid: String,
    val partnerCountryCode: String,
    val isOfferer: Boolean
)

data class IceServerConfig(
    val urls: List<String>,
    val username: String? = null,
    val credential: String? = null
)

enum class ReportReason(val code: String, val label: String, val description: String) {
    NUDITY("NUDITY", "Nudity or Sexual Content", "Explicit, inappropriate, or non-consensual visual content"),
    HARASSMENT("HARASSMENT", "Harassment or Bullying", "Verbal abuse, threats, or targeted intimidation"),
    HATE_SPEECH("HATE_SPEECH", "Hate Speech", "Discriminatory slurs or hateful conduct"),
    UNDERAGE("UNDERAGE", "Underage User (Under 18)", "User appears to be under 18 years old"),
    SPAM_BOT("SPAM_BOT", "Spam, Scam, or Bot", "Automated stream, solicitation, or fraudulent links")
}

data class SafetyReport(
    val reportId: String = "",
    val reporterUid: String = "",
    val reportedUid: String = "",
    val roomId: String = "",
    val reason: String = "",
    val details: String = "",
    val createdAt: Long = 0L
)
