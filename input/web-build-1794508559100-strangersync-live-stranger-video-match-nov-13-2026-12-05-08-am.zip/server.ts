import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || 3000;

const app = express();
app.use(express.json());

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

interface ClientInfo {
  ws: WebSocket;
  id: string;
  username: string;
  country: string;
  interests: string[];
  chatMode: 'video' | 'text';
  currentRoomId: string | null;
  partnerId: string | null;
  lastMatchedWith: string | null;
  joinedAt: number;
}

interface Room {
  id: string;
  user1Id: string;
  user2Id: string;
  chatMode: 'video' | 'text';
  createdAt: number;
}

const clients = new Map<string, ClientInfo>();
const waitingQueue = new Set<string>();
const activeRooms = new Map<string, Room>();

const CURATED_ICEBREAKERS = [
  "What's the most spontaneous thing you've ever done?",
  "If you could teleport to any city in the world right now, where would you go?",
  "What's a weird food combination you secretly love?",
  "Show me the nearest object on your desk and tell the story behind it!",
  "What song have you had on repeat lately?",
  "If you could have dinner with anyone dead or alive, who?",
  "What is your all-time favorite movie or show?",
  "Are you a night owl or an early bird, and why?",
  "What's one skill you really want to learn in 2026?",
  "Coffee, tea, or energy drinks?",
  "If you could master any musical instrument overnight, which one?",
  "What's the best travel memory you have?",
  "Cats, dogs, or exotic pets?",
  "What's your unpopular opinion that you will defend forever?",
  "If you could design a video game, what genre would it be?",
  "Tell me two truths and one lie — let me guess the lie!",
  "What is the funniest rumor you ever heard about yourself?",
  "What superpower would be the most convenient for daily life?"
];

function broadcastStats() {
  let inCallsCount = 0;
  let inTextChatCount = 0;
  for (const r of activeRooms.values()) {
    if (r.chatMode === 'video') inCallsCount += 2;
    else inTextChatCount += 2;
  }

  const stats = {
    type: 'stats_update',
    totalOnline: Math.max(clients.size, 1),
    inCalls: inCallsCount,
    inTextChat: inTextChatCount,
    inQueue: waitingQueue.size,
    timestamp: Date.now()
  };

  const payload = JSON.stringify(stats);
  for (const client of clients.values()) {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(payload);
    }
  }
}

function findMatchFor(userId: string): string | null {
  const client = clients.get(userId);
  if (!client) return null;

  let bestCandidateId: string | null = null;
  let maxScore = -1;

  for (const candidateId of waitingQueue) {
    if (candidateId === userId) continue;
    const candidate = clients.get(candidateId);
    if (!candidate) continue;

    // Both must match requested chat mode (video vs text)
    if (candidate.chatMode !== client.chatMode) continue;

    // Avoid immediate rematch with the exact same person if others in queue
    if (client.lastMatchedWith === candidateId && waitingQueue.size > 2) {
      continue;
    }

    // Count shared interests
    const shared = client.interests.filter(tag => candidate.interests.includes(tag));
    let score = shared.length * 10;
    if (candidate.country === client.country && client.country !== 'Global') {
      score += 5;
    }

    if (score > maxScore) {
      maxScore = score;
      bestCandidateId = candidateId;
    }
  }

  // Fallback to any waiting client with the same chatMode
  if (!bestCandidateId) {
    for (const candidateId of waitingQueue) {
      if (candidateId !== userId) {
        const candidate = clients.get(candidateId);
        if (candidate && candidate.chatMode === client.chatMode) {
          bestCandidateId = candidateId;
          break;
        }
      }
    }
  }

  return bestCandidateId;
}

function pairUsers(user1Id: string, user2Id: string) {
  const user1 = clients.get(user1Id);
  const user2 = clients.get(user2Id);
  if (!user1 || !user2) return;

  waitingQueue.delete(user1Id);
  waitingQueue.delete(user2Id);

  const roomId = `room_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const chatMode = user1.chatMode;
  const room: Room = {
    id: roomId,
    user1Id,
    user2Id,
    chatMode,
    createdAt: Date.now()
  };
  activeRooms.set(roomId, room);

  user1.currentRoomId = roomId;
  user1.partnerId = user2Id;
  user1.lastMatchedWith = user2Id;

  user2.currentRoomId = roomId;
  user2.partnerId = user1Id;
  user2.lastMatchedWith = user1Id;

  const sharedInterests = user1.interests.filter(i => user2.interests.includes(i));

  // User 1 is designated caller (will initiate WebRTC offer if video mode)
  if (user1.ws.readyState === WebSocket.OPEN) {
    user1.ws.send(JSON.stringify({
      type: 'match_found',
      roomId,
      isCaller: true,
      partnerId: user2.id,
      partnerCountry: user2.country,
      sharedInterests,
      partnerInterests: user2.interests,
      chatMode
    }));
  }

  // User 2 is callee (will await WebRTC offer if video mode)
  if (user2.ws.readyState === WebSocket.OPEN) {
    user2.ws.send(JSON.stringify({
      type: 'match_found',
      roomId,
      isCaller: false,
      partnerId: user1.id,
      partnerCountry: user1.country,
      sharedInterests,
      partnerInterests: user1.interests,
      chatMode
    }));
  }

  broadcastStats();
}

function leaveRoom(userId: string, reason: 'skipped' | 'disconnected' | 'left' = 'left') {
  const client = clients.get(userId);
  if (!client || !client.currentRoomId) return;

  const roomId = client.currentRoomId;
  const partnerId = client.partnerId;
  activeRooms.delete(roomId);

  client.currentRoomId = null;
  client.partnerId = null;

  if (partnerId) {
    const partner = clients.get(partnerId);
    if (partner) {
      partner.currentRoomId = null;
      partner.partnerId = null;
      if (partner.ws.readyState === WebSocket.OPEN) {
        partner.ws.send(JSON.stringify({
          type: 'stranger_disconnected',
          reason
        }));
      }
    }
  }

  broadcastStats();
}

wss.on('connection', (ws) => {
  let clientId = `usr_${Math.random().toString(36).substring(2, 9)}`;

  const clientInfo: ClientInfo = {
    ws,
    id: clientId,
    username: 'Stranger',
    country: 'Global',
    interests: [],
    chatMode: 'video',
    currentRoomId: null,
    partnerId: null,
    lastMatchedWith: null,
    joinedAt: Date.now()
  };

  clients.set(clientId, clientInfo);

  // Send greeting and connection confirmation
  ws.send(JSON.stringify({
    type: 'connected',
    userId: clientId,
    totalOnline: clients.size,
    inQueue: waitingQueue.size
  }));

  broadcastStats();

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());

      switch (msg.type) {
        case 'set_profile': {
          clientInfo.country = msg.country || 'Global';
          clientInfo.interests = Array.isArray(msg.interests) ? msg.interests : [];
          if (msg.chatMode) clientInfo.chatMode = msg.chatMode;
          if (msg.username) clientInfo.username = msg.username;
          break;
        }

        case 'join_queue': {
          // If already in a room, leave it first
          if (clientInfo.currentRoomId) {
            leaveRoom(clientId, 'skipped');
          }

          clientInfo.country = msg.country || clientInfo.country;
          clientInfo.interests = Array.isArray(msg.interests) ? msg.interests : clientInfo.interests;
          if (msg.chatMode) clientInfo.chatMode = msg.chatMode;

          const matchPartnerId = findMatchFor(clientId);
          if (matchPartnerId) {
            pairUsers(clientId, matchPartnerId);
          } else {
            waitingQueue.add(clientId);
            ws.send(JSON.stringify({
              type: 'queue_status',
              status: 'waiting',
              queueLength: waitingQueue.size
            }));
            broadcastStats();
          }
          break;
        }

        case 'leave_queue': {
          waitingQueue.delete(clientId);
          ws.send(JSON.stringify({
            type: 'queue_status',
            status: 'idle'
          }));
          broadcastStats();
          break;
        }

        case 'next_stranger': {
          leaveRoom(clientId, 'skipped');
          // Re-enter matchmaking queue immediately
          const matchPartnerId = findMatchFor(clientId);
          if (matchPartnerId) {
            pairUsers(clientId, matchPartnerId);
          } else {
            waitingQueue.add(clientId);
            ws.send(JSON.stringify({
              type: 'queue_status',
              status: 'waiting',
              queueLength: waitingQueue.size
            }));
            broadcastStats();
          }
          break;
        }

        case 'stop_call': {
          leaveRoom(clientId, 'left');
          waitingQueue.delete(clientId);
          ws.send(JSON.stringify({
            type: 'call_stopped'
          }));
          broadcastStats();
          break;
        }

        case 'webrtc_offer': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'webrtc_offer',
                sdp: msg.sdp
              }));
            }
          }
          break;
        }

        case 'webrtc_answer': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'webrtc_answer',
                sdp: msg.sdp
              }));
            }
          }
          break;
        }

        case 'ice_candidate': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'ice_candidate',
                candidate: msg.candidate
              }));
            }
          }
          break;
        }

        case 'chat_message': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'chat_message',
                sender: 'stranger',
                text: msg.text,
                timestamp: Date.now()
              }));
            }
          }
          break;
        }

        case 'chat_typing': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'chat_typing',
                isTyping: !!msg.isTyping
              }));
            }
          }
          break;
        }

        case 'send_icebreaker': {
          const prompt = msg.prompt || CURATED_ICEBREAKERS[Math.floor(Math.random() * CURATED_ICEBREAKERS.length)];
          // Send to sender
          ws.send(JSON.stringify({
            type: 'icebreaker_prompt',
            prompt,
            initiatedByMe: true
          }));
          // Send to partner
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'icebreaker_prompt',
                prompt,
                initiatedByMe: false
              }));
            }
          }
          break;
        }

        case 'send_reaction': {
          if (clientInfo.partnerId) {
            const partner = clients.get(clientInfo.partnerId);
            if (partner && partner.ws.readyState === WebSocket.OPEN) {
              partner.ws.send(JSON.stringify({
                type: 'reaction_received',
                emoji: msg.emoji,
                id: Math.random().toString(36).substring(2, 8)
              }));
            }
          }
          break;
        }

        case 'report_stranger': {
          // Immediately disconnect pair and log report
          console.warn(`[REPORT] User ${clientId} reported stranger in room ${clientInfo.currentRoomId}. Reason: ${msg.reason}`);
          leaveRoom(clientId, 'left');
          ws.send(JSON.stringify({
            type: 'report_acknowledged',
            message: 'Thank you for keeping StrangerSync safe. The user has been disconnected.'
          }));
          break;
        }
      }
    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  ws.on('close', () => {
    waitingQueue.delete(clientId);
    leaveRoom(clientId, 'disconnected');
    clients.delete(clientId);
    broadcastStats();
  });
});

// REST API endpoints
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    online: clients.size,
    inQueue: waitingQueue.size,
    activeCalls: activeRooms.size
  });
});

app.get('/api/icebreakers', (_req, res) => {
  res.json({ icebreakers: CURATED_ICEBREAKERS });
});

// Mount Vite middleware in development, or serve dist in production
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, () => {
    console.log(`StrangerSync server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
