// Generates an interactive animated Practice Stranger MediaStream using Canvas captureStream
export class PracticeBotEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private animFrameId: number | null = null;
  private isSpeaking: boolean = false;
  private stream: MediaStream | null = null;

  constructor() {
    this.canvas = document.createElement('canvas');
    this.canvas.width = 640;
    this.canvas.height = 480;
    this.ctx = this.canvas.getContext('2d')!;
  }

  public getMediaStream(): MediaStream {
    if (!this.stream) {
      this.stream = (this.canvas as unknown as { captureStream: (fps: number) => MediaStream }).captureStream(30);
      this.startAnimation();
    }
    return this.stream;
  }

  public setSpeaking(speaking: boolean) {
    this.isSpeaking = speaking;
  }

  private startAnimation() {
    let t = 0;
    const render = () => {
      t += 0.05;
      const ctx = this.ctx;
      const w = this.canvas.width;
      const h = this.canvas.height;

      // Background: Cozy warm studio room
      const bgGradient = ctx.createLinearGradient(0, 0, w, h);
      bgGradient.addColorStop(0, '#1e1b4b');
      bgGradient.addColorStop(0.5, '#0f172a');
      bgGradient.addColorStop(1, '#020617');
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, w, h);

      // Ambient bokeh orbs in background
      ctx.fillStyle = 'rgba(99, 102, 241, 0.15)';
      ctx.beginPath();
      ctx.arc(120 + Math.sin(t * 0.5) * 15, 140, 70, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = 'rgba(236, 72, 153, 0.1)';
      ctx.beginPath();
      ctx.arc(520 + Math.cos(t * 0.4) * 20, 320, 90, 0, Math.PI * 2);
      ctx.fill();

      // Subtle breathing head-bob
      const headBobY = Math.sin(t * 1.5) * 4;
      const headCenterX = w / 2;
      const headCenterY = h / 2 - 20 + headBobY;

      // Shoulders / Torso
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.ellipse(headCenterX, headCenterY + 180, 140, 90, 0, 0, Math.PI * 2);
      ctx.fill();

      // Neck
      ctx.fillStyle = '#f87171';
      ctx.fillRect(headCenterX - 22, headCenterY + 70, 44, 40);

      // Head / Face
      ctx.fillStyle = '#fca5a5';
      ctx.beginPath();
      ctx.ellipse(headCenterX, headCenterY, 65, 80, 0, 0, Math.PI * 2);
      ctx.fill();

      // Hair
      ctx.fillStyle = '#312e81';
      ctx.beginPath();
      ctx.arc(headCenterX, headCenterY - 25, 70, Math.PI, 0);
      ctx.lineTo(headCenterX + 70, headCenterY + 20);
      ctx.lineTo(headCenterX - 70, headCenterY + 20);
      ctx.fill();

      // Eyes with occasional natural blinking
      const isBlinking = Math.sin(t * 0.8) > 0.96;
      ctx.fillStyle = '#1e293b';
      if (isBlinking) {
        ctx.lineWidth = 3;
        ctx.strokeStyle = '#1e293b';
        ctx.beginPath();
        ctx.moveTo(headCenterX - 30, headCenterY - 5);
        ctx.lineTo(headCenterX - 10, headCenterY - 5);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(headCenterX + 10, headCenterY - 5);
        ctx.lineTo(headCenterX + 30, headCenterY - 5);
        ctx.stroke();
      } else {
        // Eye whites & pupils
        ctx.beginPath();
        ctx.arc(headCenterX - 20, headCenterY - 5, 8, 0, Math.PI * 2);
        ctx.arc(headCenterX + 20, headCenterY - 5, 8, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(headCenterX - 18, headCenterY - 7, 3, 0, Math.PI * 2);
        ctx.arc(headCenterX + 22, headCenterY - 7, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // Mouth: moves when bot is speaking
      ctx.strokeStyle = '#991b1b';
      ctx.lineWidth = 3;
      ctx.fillStyle = '#991b1b';
      ctx.beginPath();
      if (this.isSpeaking) {
        const mouthOpenH = 6 + Math.abs(Math.sin(t * 12)) * 14;
        ctx.ellipse(headCenterX, headCenterY + 35, 16, mouthOpenH, 0, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.arc(headCenterX, headCenterY + 28, 14, 0.2, Math.PI - 0.2);
        ctx.stroke();
      }

      // Live "PRACTICE BOT" banner in canvas
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.fillRect(w - 180, 20, 160, 36);
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('SOLO PRACTICE', w - 100, 43);

      this.animFrameId = requestAnimationFrame(render);
    };

    this.animFrameId = requestAnimationFrame(render);
  }

  public speakText(text: string) {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    this.setSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.onend = () => {
      this.setSpeaking(false);
    };
    utterance.onerror = () => {
      this.setSpeaking(false);
    };
    window.speechSynthesis.speak(utterance);
  }

  public stop() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach((t) => t.stop());
      this.stream = null;
    }
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
  }
}
