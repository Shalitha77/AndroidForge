export type MatchState = 'idle' | 'waiting' | 'connecting' | 'connected' | 'disconnected';

export type ChatMode = 'video' | 'text';

export interface ChatMessage {
  id: string;
  sender: 'me' | 'stranger' | 'system';
  text: string;
  timestamp: number;
}

export type VideoFilter = 'none' | 'warm' | 'cyber' | 'noir' | 'vintage' | 'glow';

export interface FloatingReaction {
  id: string;
  emoji: string;
  x: number;
  y: number;
}

export interface StrangerProfile {
  partnerId: string;
  country: string;
  sharedInterests: string[];
  partnerInterests: string[];
  chatMode?: ChatMode;
}

export interface AppStats {
  totalOnline: number;
  inCalls: number;
  inQueue: number;
  inTextChat: number;
}

export interface AdMobConfig {
  appId: string;
  appOpenUnitId: string;
  publisherId: string;
  bannerUnitId: string;
  interstitialUnitId: string;
  rewardedUnitId: string;
  testMode: boolean;
  adsEnabled: boolean;
  vipAdFree: boolean;
  interstitialFrequency: number; // e.g. show every 4 skips
  showAppOpenOnLoad: boolean;
}

