import React, { useState, useEffect, useRef } from 'react';
import { Send, MessageSquare, Sparkles } from 'lucide-react';
import { ChatMessage, MatchState } from '../types';

interface ChatBoxProps {
  messages: ChatMessage[];
  matchState: MatchState;
  isStrangerTyping: boolean;
  onSendMessage: (text: string) => void;
  onSendReaction: (emoji: string) => void;
  onTypingChange: (isTyping: boolean) => void;
  onNextStranger: () => void;
}

const QUICK_REACTIONS = ['👋', '❤️', '😂', '🔥', '👏', '🎉'];

export const ChatBox: React.FC<ChatBoxProps> = ({
  messages,
  matchState,
  isStrangerTyping,
  onSendMessage,
  onSendReaction,
  onTypingChange,
  onNextStranger,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStrangerTyping]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);

    // Notify partner that user is typing
    onTypingChange(true);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      onTypingChange(false);
    }, 1500);
  };

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    onSendMessage(inputText.trim());
    setInputText('');
    onTypingChange(false);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
  };

  const isConnected = matchState === 'connected';

  return (
    <div className="flex flex-col h-full bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
      {/* CHAT HEADER */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-950/50">
        <div className="flex items-center gap-2">
          <MessageSquare size={16} className="text-indigo-400" />
          <h3 className="text-sm font-bold text-white tracking-wide">Live Conversation</h3>
        </div>
        <div className="text-xs text-slate-400">
          {isConnected ? (
            <span className="text-emerald-400 font-medium">Stranger Connected</span>
          ) : matchState === 'waiting' ? (
            <span>Matching...</span>
          ) : (
            <span>Disconnected</span>
          )}
        </div>
      </div>

      {/* MESSAGES CONTAINER */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[220px] max-h-[360px] lg:max-h-none text-sm">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 py-8">
            <Sparkles size={24} className="mb-2 text-slate-600" />
            <p className="text-xs">
              {isConnected
                ? 'Say hello to your match! Messages are direct and ephemeral.'
                : 'Connect with a stranger to start chatting.'}
            </p>
          </div>
        )}

        {messages.map((msg) => {
          if (msg.sender === 'system') {
            return (
              <div key={msg.id} className="flex justify-center my-2">
                <span className="text-[11px] text-slate-400 bg-slate-950/70 border border-slate-800 px-3 py-1 rounded-full text-center max-w-[90%]">
                  {msg.text}
                </span>
              </div>
            );
          }

          const isMe = msg.sender === 'me';
          return (
            <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-sm break-words shadow-sm ${
                  isMe
                    ? 'bg-indigo-600 text-white rounded-br-xs'
                    : 'bg-slate-800 text-slate-100 rounded-bl-xs border border-slate-700/50'
                }`}
              >
                {msg.text}
              </div>
              <span className="text-[10px] text-slate-500 mt-1 px-1">
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          );
        })}

        {/* TYPING INDICATOR */}
        {isStrangerTyping && isConnected && (
          <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-800/60 px-3 py-1.5 rounded-xl w-fit border border-slate-700/40">
            <span className="italic">Stranger is typing</span>
            <span className="flex gap-0.5">
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" />
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* QUICK EMOJI REACTIONS DOCK */}
      {isConnected && (
        <div className="flex items-center justify-around px-3 py-2 border-t border-slate-800/80 bg-slate-950/40">
          {QUICK_REACTIONS.map((emoji) => (
            <button
              key={emoji}
              onClick={() => onSendReaction(emoji)}
              className="text-lg hover:scale-125 active:scale-95 transition-transform p-1 cursor-pointer"
              title={`Send ${emoji} reaction`}
            >
              {emoji}
            </button>
          ))}
        </div>
      )}

      {/* CHAT INPUT FORM */}
      <form onSubmit={handleSend} className="p-3 border-t border-slate-800 bg-slate-950/60 flex items-center gap-2">
        <input
          type="text"
          value={inputText}
          onChange={handleInputChange}
          placeholder={isConnected ? 'Type a message to stranger...' : 'Waiting for connection...'}
          disabled={!isConnected}
          className="flex-1 bg-slate-900 border border-slate-700/80 focus:border-indigo-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 disabled:opacity-50 transition-colors"
        />
        <button
          type="submit"
          disabled={!isConnected || !inputText.trim()}
          className="p-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
        >
          <Send size={16} />
        </button>
      </form>
    </div>
  );
};
