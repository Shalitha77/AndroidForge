import React, { useState } from 'react';
import { X, Copy, Check, ExternalLink, Users } from 'lucide-react';

interface DualTabTestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DualTabTestModal: React.FC<DualTabTestModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  const handleCopy = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleOpenNewTab = () => {
    window.open(currentUrl, '_blank', 'width=1100,height=750');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2 mb-2 text-indigo-400">
          <Users size={22} />
          <h3 className="text-xl font-bold text-white">Test 2-Way Matchmaking</h3>
        </div>
        <p className="text-xs text-slate-400 mb-6 leading-relaxed">
          StrangerSync uses real-time WebSockets and WebRTC peer-to-peer signaling. You can test live matchmaking by opening a second tab or window on your computer.
        </p>

        <div className="space-y-4 mb-6">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <h4 className="text-xs font-semibold text-slate-200">Step-by-Step Test:</h4>
            <ol className="text-xs text-slate-400 space-y-2 list-decimal list-inside">
              <li>Click <strong className="text-white">"Open 2nd Window"</strong> below.</li>
              <li>In both windows, click <strong className="text-indigo-400">"Start Matching"</strong>.</li>
              <li>The server will pair both browser tabs together in under 1 second!</li>
              <li>Test live WebRTC video, mic audio, icebreakers, and real-time chat.</li>
            </ol>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={currentUrl}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 font-mono select-all focus:outline-none"
            />
            <button
              onClick={handleCopy}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={handleOpenNewTab}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all cursor-pointer"
          >
            <ExternalLink size={14} />
            <span>Open 2nd Window</span>
          </button>
        </div>
      </div>
    </div>
  );
};
