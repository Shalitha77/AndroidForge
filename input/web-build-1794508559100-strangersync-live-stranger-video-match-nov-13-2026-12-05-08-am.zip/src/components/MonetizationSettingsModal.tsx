import React, { useState, useEffect } from 'react';
import { X, DollarSign, Smartphone, Code, Check, Save } from 'lucide-react';
import { AdMobConfig } from '../types';

interface MonetizationSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AdMobConfig;
  onSaveConfig: (newConfig: AdMobConfig) => void;
}

const normalizeConfig = (cfg: Partial<AdMobConfig>): AdMobConfig => ({
  appId: cfg.appId ?? '',
  appOpenUnitId: cfg.appOpenUnitId ?? '',
  publisherId: cfg.publisherId ?? '',
  bannerUnitId: cfg.bannerUnitId ?? '',
  interstitialUnitId: cfg.interstitialUnitId ?? '',
  rewardedUnitId: cfg.rewardedUnitId ?? '',
  testMode: Boolean(cfg.testMode),
  adsEnabled: cfg.adsEnabled ?? true,
  vipAdFree: Boolean(cfg.vipAdFree),
  interstitialFrequency: cfg.interstitialFrequency ?? 4,
  showAppOpenOnLoad: cfg.showAppOpenOnLoad ?? true,
});

export const MonetizationSettingsModal: React.FC<MonetizationSettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
}) => {
  const [formData, setFormData] = useState<AdMobConfig>(() => normalizeConfig(config));
  const [activeTab, setActiveTab] = useState<'config' | 'mobile_guide'>('config');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setFormData(normalizeConfig(config));
    }
  }, [isOpen, config]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig(formData);
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2 mb-2 text-emerald-400">
          <DollarSign size={24} />
          <h3 className="text-xl font-bold text-white">Google AdSense & AdMob (Web + Mobile)</h3>
        </div>
        <p className="text-xs text-slate-400 mb-5 leading-relaxed">
          Monetize both the live web version and mobile Android APK using your Google AdSense Publisher tag and Google AdMob App Open & Banner units.
        </p>

        {/* TABS */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl mb-5 border border-slate-800 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('config')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'config'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            AdMob & AdSense Keys
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('mobile_guide')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'mobile_guide'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Play Store / APK Guide
          </button>
        </div>

        {activeTab === 'config' ? (
          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs">
            {/* ENABLE ADS TOGGLE */}
            <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <span className="font-semibold text-white block">Enable Monetization & Ads</span>
                <span className="text-[11px] text-slate-400">Serve banner and interstitial ads to users</span>
              </div>
              <input
                type="checkbox"
                checked={Boolean(formData.adsEnabled)}
                onChange={(e) => setFormData({ ...formData, adsEnabled: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700 focus:ring-indigo-500 cursor-pointer"
              />
            </div>

            {/* TEST MODE TOGGLE */}
            <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <span className="font-semibold text-white block">AdMob Test Mode</span>
                <span className="text-[11px] text-slate-400">Uses official Google sample ad units to test without violating policy</span>
              </div>
              <input
                type="checkbox"
                checked={Boolean(formData.testMode)}
                onChange={(e) => setFormData({ ...formData, testMode: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700 focus:ring-indigo-500 cursor-pointer"
              />
            </div>

            {/* ADMOB APP ID */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                AdMob Application ID
              </label>
              <input
                type="text"
                value={formData.appId ?? ''}
                onChange={(e) => setFormData({ ...formData, appId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                Required for Android APK AndroidManifest.xml (e.g. ca-app-pub-9670799162361917~4119297613)
              </span>
            </div>

            {/* APP OPEN AD UNIT ID */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                App Open Ad Unit ID
              </label>
              <input
                type="text"
                value={formData.appOpenUnitId ?? ''}
                onChange={(e) => setFormData({ ...formData, appOpenUnitId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                Displays on app startup / splash transition (e.g. ca-app-pub-9670799162361917/9179393460)
              </span>
            </div>

            {/* SHOW APP OPEN AD ON LOAD TOGGLE */}
            <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <span className="font-semibold text-white block">Show App Open Ad On App Launch</span>
                <span className="text-[11px] text-slate-400">Display full-screen App Open ad when users open the application</span>
              </div>
              <input
                type="checkbox"
                checked={Boolean(formData.showAppOpenOnLoad)}
                onChange={(e) => setFormData({ ...formData, showAppOpenOnLoad: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700 focus:ring-indigo-500 cursor-pointer"
              />
            </div>

            {/* PUBLISHER ID */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                AdMob / AdSense Publisher ID
              </label>
              <input
                type="text"
                value={formData.publisherId ?? ''}
                onChange={(e) => setFormData({ ...formData, publisherId: e.target.value })}
                placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                Found in your AdMob Console under Settings → Account Information
              </span>
            </div>

            {/* BANNER UNIT ID */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Banner Ad Unit ID
              </label>
              <input
                type="text"
                value={formData.bannerUnitId ?? ''}
                onChange={(e) => setFormData({ ...formData, bannerUnitId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* INTERSTITIAL UNIT ID */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Interstitial Video Ad Unit ID
              </label>
              <input
                type="text"
                value={formData.interstitialUnitId ?? ''}
                onChange={(e) => setFormData({ ...formData, interstitialUnitId: e.target.value })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* INTERSTITIAL FREQUENCY */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Interstitial Video Frequency
              </label>
              <select
                value={formData.interstitialFrequency ?? 4}
                onChange={(e) => setFormData({ ...formData, interstitialFrequency: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                <option value={3}>Every 3 stranger skips (High Revenue)</option>
                <option value={4}>Every 4 stranger skips (Recommended)</option>
                <option value={5}>Every 5 stranger skips (Balanced)</option>
                <option value={8}>Every 8 stranger skips (Casual)</option>
                <option value={0}>Disabled / Rewarded Only</option>
              </select>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
              >
                {saved ? <Check size={14} /> : <Save size={14} />}
                <span>{saved ? 'Saved!' : 'Save Monetization Settings'}</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs text-slate-300 pr-1 leading-relaxed">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-white font-semibold">
                <Smartphone size={16} className="text-indigo-400" />
                <span>Publishing to Google Play with Google AdMob</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Google AdMob is Google’s official mobile ads SDK for Android & iOS apps. To earn maximum eCPM through AdMob, you can wrap this responsive app into an Android package (APK / AAB) using Capacitor or Trusted Web Activities (TWA):
              </p>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-400 pl-1 text-[11px]">
                <li>Export build via <code className="text-indigo-300 font-mono">npm run build</code></li>
                <li>Add Capacitor: <code className="text-indigo-300 font-mono">npm i @capacitor/core @capacitor/android</code></li>
                <li>Install AdMob plugin: <code className="text-indigo-300 font-mono">npm i @capacitor-community/admob</code></li>
                <li>Add your Android AdMob App ID in <code className="text-indigo-300 font-mono">AndroidManifest.xml</code></li>
                <li>Build your APK in Android Studio and upload to Google Play Console!</li>
              </ol>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-white font-semibold">
                <Code size={16} className="text-indigo-400" />
                <span>Web Monetization (Google AdSense Tag)</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                For web traffic, your AdSense script tag can be placed in <code className="text-slate-200">index.html</code>:
              </p>
              <pre className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-[10px] font-mono text-emerald-400 overflow-x-auto">
{`<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${formData.publisherId || 'ca-pub-XXXXXXXXXXXXXXXX'}" crossorigin="anonymous"></script>`}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
