import React, { useState } from 'react';
import { X, Smartphone, Download, Check, Code, ShieldCheck, ExternalLink, Sparkles } from 'lucide-react';
import JSZip from 'jszip';
import { AdMobConfig } from '../types';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AdMobConfig;
}

export const ApkExportModal: React.FC<ApkExportModalProps> = ({
  isOpen,
  onClose,
  config,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'download' | 'instructions'>('download');

  if (!isOpen) return null;

  // Generate and download full Android Studio project ZIP
  const handleDownloadAndroidProject = async () => {
    setIsGenerating(true);
    try {
      const zip = new JSZip();

      // 1. AndroidManifest.xml
      const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.strangersync.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
    <uses-feature android:name="android.hardware.microphone" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="StrangerSync"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.StrangerSync"
        android:hardwareAccelerated="true">

        <!-- Google AdMob Application ID -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="${config.appId}" />

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:theme="@style/Theme.StrangerSync.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

      // 2. MainActivity.java with Google Mobile Ads SDK & App Open Ad
      const mainActivityJava = `package com.strangersync.app;

import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private AppOpenAd appOpenAd;
    private static final String APP_OPEN_AD_UNIT = "${config.appOpenUnitId}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Initialize Google Mobile Ads SDK
        MobileAds.initialize(this, initializationStatus -> {
            loadAppOpenAd();
        });

        // 2. Setup WebView with WebRTC & Camera permissions
        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
        });

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://ais-dev-a7ozikrbtumsd7bsp3ecei-863895830917.asia-northeast1.run.app");
    }

    private void loadAppOpenAd() {
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(this, APP_OPEN_AD_UNIT, request, new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(AppOpenAd ad) {
                appOpenAd = ad;
                appOpenAd.show(MainActivity.this);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}`;

      // 3. app/build.gradle
      const buildGradle = `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.strangersync.app'
    compileSdk 34

    defaultConfig {
        applicationId "com.strangersync.app"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    // Google AdMob SDK
    implementation 'com.google.android.gms:play-services-ads:23.6.0'
}`;

      // 4. README with 1-click APK build instructions
      const readmeMd = `# StrangerSync Android APK Project
Configured with Google AdMob:
- App ID: ${config.appId}
- App Open Ad Unit ID: ${config.appOpenUnitId}

## How to Build the APK in 2 Minutes:
1. Extract this ZIP file.
2. Open **Android Studio** and click **Open**, select this extracted folder.
3. Android Studio will automatically sync Gradle and download dependencies.
4. Go to **Build** menu -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
5. Once built, click "Locate" to find your installable **app-debug.apk** or sign it for Google Play!
`;

      // 5. Layout XML
      const activityMainXml = `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>`;

      // Add files to ZIP
      zip.file('README.md', readmeMd);
      zip.file('app/build.gradle', buildGradle);
      zip.file('app/src/main/AndroidManifest.xml', manifestXml);
      zip.file('app/src/main/java/com/strangersync/app/MainActivity.java', mainActivityJava);
      zip.file('app/src/main/res/layout/activity_main.xml', activityMainXml);

      // Generate zip blob
      const content = await zip.generateAsync({ type: 'blob' });
      const downloadUrl = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `strangersync-android-admob-apk-project.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Error generating APK bundle:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2 mb-2 text-indigo-400">
          <Smartphone size={24} />
          <h3 className="text-xl font-bold text-white">Android APK & AdMob Integration</h3>
        </div>
        <p className="text-xs text-slate-400 mb-5 leading-relaxed">
          Your AdMob App ID and App Open Ad units are configured. Download the ready-to-build Android Studio project or install as an Android WebAPK.
        </p>

        {/* TABS */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl mb-4 border border-slate-800 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('download')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'download'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            1-Click APK Project Download
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('instructions')}
            className={`flex-1 py-1.5 px-3 rounded-lg transition-colors cursor-pointer text-center ${
              activeTab === 'instructions'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            AdMob IDs & Verification
          </button>
        </div>

        {activeTab === 'download' ? (
          <div className="space-y-4 text-xs text-slate-300">
            {/* CURRENT ADMOB STATUS BOX */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-white">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <ShieldCheck size={16} />
                  <span>Configured AdMob Units</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Ready for Release</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono mt-2">
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">App ID:</span>
                  <span className="text-slate-200 select-all">{config.appId}</span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">App Open Ad Unit:</span>
                  <span className="text-indigo-300 select-all">{config.appOpenUnitId}</span>
                </div>
              </div>
            </div>

            {/* DOWNLOAD ACTION CARD */}
            <div className="p-4 bg-gradient-to-br from-indigo-950/60 to-slate-950 rounded-xl border border-indigo-900/40 space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Sparkles size={16} className="text-indigo-400" />
                <span>Complete Android Studio Project Bundle (.ZIP)</span>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Includes <code className="text-indigo-300">AndroidManifest.xml</code>, <code className="text-indigo-300">MainActivity.java</code> with Google Mobile Ads SDK, WebRTC camera/mic permission handlers, and gradle files pre-configured with your exact App ID and App Open Ad unit.
              </p>

              <button
                onClick={handleDownloadAndroidProject}
                disabled={isGenerating}
                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer text-xs"
              >
                {downloadSuccess ? (
                  <>
                    <Check size={16} className="text-emerald-300" />
                    <span>Android Project ZIP Downloaded!</span>
                  </>
                ) : isGenerating ? (
                  <span>Generating Android Project...</span>
                ) : (
                  <>
                    <Download size={16} />
                    <span>Download Android Studio APK Project (.ZIP)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 text-xs text-slate-300 overflow-y-auto max-h-[50vh] pr-1">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <span className="text-slate-400 text-[10px] block font-sans">AndroidManifest.xml snippet:</span>
              <pre className="text-emerald-400 overflow-x-auto p-2 bg-slate-900 rounded">
{`<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="${config.appId}"/>`}
              </pre>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <span className="text-slate-400 text-[10px] block font-sans">MainActivity.java App Open Ad Loader:</span>
              <pre className="text-indigo-300 overflow-x-auto p-2 bg-slate-900 rounded">
{`AppOpenAd.load(this, "${config.appOpenUnitId}", request, callback);`}
              </pre>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-[11px]">
              <h4 className="font-bold text-white">How to compile APK:</h4>
              <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1">
                <li>Download the ZIP using the button on the first tab.</li>
                <li>Open Android Studio and click <strong>Open Project</strong>.</li>
                <li>Click <strong>Build &gt; Build APK(s)</strong>.</li>
                <li>Transfer the generated <code className="text-indigo-300">.apk</code> to your phone to install!</li>
              </ol>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-3 mt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
