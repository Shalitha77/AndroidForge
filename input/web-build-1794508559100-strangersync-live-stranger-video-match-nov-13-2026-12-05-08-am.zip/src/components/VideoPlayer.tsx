import React, { useRef, useEffect } from 'react';
import { Camera, CameraOff, Mic, MicOff, RefreshCw, Sparkles, User, Camera as SnapshotIcon, ShieldAlert, MessageSquare } from 'lucide-react';
import { MatchState, VideoFilter, FloatingReaction, StrangerProfile, ChatMode } from '../types';

interface VideoPlayerProps {
  matchState: MatchState;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isMicMuted: boolean;
  isCameraOff: boolean;
  videoFilter: VideoFilter;
  stranger: StrangerProfile | null;
  reactions: FloatingReaction[];
  chatMode: ChatMode;
  onChangeChatMode: (mode: ChatMode) => void;
  onStartMatching: () => void;
  onNextStranger: () => void;
  onReportStranger: () => void;
  isLocalSpeaking: boolean;
  isRemoteSpeaking: boolean;
  isPracticeMode?: boolean;
}

const FILTER_CLASSES: Record<VideoFilter, string> = {
  none: '',
  warm: 'contrast-105 saturate-125 sepia-15 hue-rotate-[-5deg]',
  cyber: 'contrast-125 saturate-150 hue-rotate-15 brightness-105',
  noir: 'grayscale contrast-130 brightness-95',
  vintage: 'sepia-40 contrast-110 brightness-95 saturate-85',
  glow: 'brightness-110 contrast-105 saturate-110'
};

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  matchState,
  localStream,
  remoteStream,
  isMicMuted,
  isCameraOff,
  videoFilter,
  stranger,
  reactions,
  chatMode,
  onChangeChatMode,
  onStartMatching,
  onNextStranger,
  onReportStranger,
  isLocalSpeaking,
  isRemoteSpeaking,
  isPracticeMode,
}) => {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Attach local stream to video element
  useEffect(() => {
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Attach remote stream to video element
  useEffect(() => {
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  // Take fun photobooth snapshot
  const takeSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 1280;
    canvas.height = 720;

    // Fill dark background
    ctx.fillStyle = '#0b0f17';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw remote video if available
    if (remoteVideoRef.current && remoteStream) {
      ctx.drawImage(remoteVideoRef.current, 0, 0, 850, 720);
    } else {
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, 850, 720);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '28px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(stranger ? `Stranger from ${stranger.country}` : 'Stranger Call', 425, 360);
    }

    // Draw local preview in corner
    if (localVideoRef.current && localStream && !isCameraOff) {
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 4;
      ctx.strokeRect(870, 420, 390, 270);
      ctx.drawImage(localVideoRef.current, 870, 420, 390, 270);
    }

    // Draw caption watermark
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(20, 20, 400, 60);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('StrangerSync Live Call', 40, 56);

    const dataUrl = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `strangersync-call-${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
  };

  return (
    <div className="relative w-full h-full min-h-[460px] lg:min-h-[580px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col justify-center items-center">
      {/* Hidden canvas for taking photobooth snapshots */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Floating Reactions Layer */}
      <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden">
        {reactions.map((r) => (
          <div
            key={r.id}
            className="absolute text-5xl animate-bounce transition-all duration-1000 transform -translate-y-24 opacity-90"
            style={{ left: `${r.x}%`, top: `${r.y}%` }}
          >
            {r.emoji}
          </div>
        ))}
      </div>

      {/* MAIN VIDEO / CHAT STAGE */}
      <div className="relative w-full h-full flex items-center justify-center bg-slate-900 overflow-hidden">
        {/* CONNECTED: TEXT ONLY CHAT STAGE */}
        {matchState === 'connected' && chatMode === 'text' && (
          <div className="flex flex-col items-center justify-center p-8 text-center z-10 max-w-md">
            <div className="w-24 h-24 rounded-full bg-indigo-950/80 border-2 border-indigo-500/40 flex items-center justify-center text-indigo-400 mb-4 shadow-xl shadow-indigo-950/50">
              <MessageSquare size={44} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-1">
              {isPracticeMode ? 'Solo Practice Partner (Text)' : `Stranger (${stranger?.country || 'Worldwide'})`}
            </h3>
            <p className="text-slate-400 text-xs mb-4">
              Anonymous real-time text chat active. Your camera and microphone remain private.
            </p>
            {stranger?.sharedInterests && stranger.sharedInterests.length > 0 && (
              <div className="flex flex-wrap gap-1.5 justify-center mb-6">
                {stranger.sharedInterests.map((tag) => (
                  <span key={tag} className="text-xs bg-indigo-950 text-indigo-300 border border-indigo-800/80 px-2.5 py-1 rounded-lg">
                    #{tag}
                  </span>
                ))}
              </div>
            )}
            <button
              onClick={onNextStranger}
              className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-all cursor-pointer"
            >
              Skip to Next Stranger [Space]
            </button>
          </div>
        )}

        {/* CONNECTED: VIDEO STREAM */}
        {matchState === 'connected' && chatMode === 'video' && (
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className={`w-full h-full object-cover transition-all ${
              isRemoteSpeaking ? 'ring-4 ring-emerald-500/50' : ''
            }`}
          />
        )}

        {/* Remote fallback placeholder if video has no track or connecting */}
        {matchState === 'connected' && chatMode === 'video' && !remoteStream && (
          <div className="flex flex-col items-center justify-center p-8 text-center text-slate-300">
            <div className="w-24 h-24 rounded-full bg-slate-800 flex items-center justify-center mb-4 text-slate-500 border border-slate-700">
              <User size={48} />
            </div>
            <p className="text-lg font-semibold text-white">Stranger's Camera is Loading...</p>
            <p className="text-sm text-slate-400 mt-1">Audio & video peer connection is synchronizing</p>
          </div>
        )}

        {/* CONNECTING STATE */}
        {matchState === 'connecting' && (
          <div className="flex flex-col items-center justify-center p-8 text-center">
            <div className="w-20 h-20 rounded-full border-4 border-indigo-500/30 border-t-indigo-500 animate-spin mb-6 flex items-center justify-center">
              <Sparkles className="text-indigo-400 animate-pulse" size={28} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Connecting with Stranger...</h3>
            <p className="text-slate-400 text-sm max-w-md">
              Found a match! Establishing {chatMode === 'video' ? 'peer-to-peer WebRTC video' : 'real-time text'} connection...
            </p>
          </div>
        )}

        {/* WAITING IN QUEUE STATE */}
        {matchState === 'waiting' && (
          <div className="flex flex-col items-center justify-center p-8 text-center z-10">
            <div className="relative flex items-center justify-center mb-6">
              <div className="w-28 h-28 rounded-full bg-indigo-600/10 border border-indigo-500/30 flex items-center justify-center animate-ping absolute" />
              <div className="w-20 h-20 rounded-full bg-indigo-600/20 border border-indigo-500/50 flex items-center justify-center">
                <RefreshCw className="text-indigo-400 animate-spin" size={32} />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">
              Searching for a {chatMode === 'video' ? 'Video' : 'Text'} Stranger...
            </h3>
            <p className="text-slate-300 text-sm max-w-md mb-4">
              Scanning active queue for someone with compatible interests.
            </p>
            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-900/80 px-4 py-2 rounded-lg border border-slate-800">
              <span>Pro Tip: Open a 2nd browser tab to test live 2-way call instantly</span>
            </div>
          </div>
        )}

        {/* IDLE / START SCREEN */}
        {matchState === 'idle' && (
          <div className="relative w-full h-full flex flex-col items-center justify-center text-center p-6 overflow-hidden">
            <img
              src="/src/assets/images/stranger_video_hero_1794504335011.jpg"
              alt="Live video chat background"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover opacity-20 filter blur-xs"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-950/60" />

            <div className="relative z-10 max-w-lg flex flex-col items-center">
              <div className="w-16 h-16 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4 shadow-lg shadow-indigo-600/20">
                <Camera size={32} />
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-2">
                Meet Random Strangers Live
              </h2>
              <p className="text-slate-300 text-sm sm:text-base mb-6 leading-relaxed">
                Connect face-to-face or via anonymous text chat with people from around the world.
              </p>

              {/* CHAT MODE SELECTOR TABS */}
              <div className="flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded-xl mb-5">
                <button
                  type="button"
                  onClick={() => onChangeChatMode('video')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    chatMode === 'video'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Camera size={14} />
                  <span>Video Call</span>
                </button>
                <button
                  type="button"
                  onClick={() => onChangeChatMode('text')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    chatMode === 'text'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <MessageSquare size={14} />
                  <span>Text Only</span>
                </button>
              </div>

              <button
                onClick={onStartMatching}
                className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-400 hover:to-violet-500 text-white font-bold text-base rounded-xl shadow-xl shadow-indigo-500/25 transition-all transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
              >
                {chatMode === 'video' ? 'Start Video Chat Now' : 'Start Text Chat Now'}
              </button>
            </div>
          </div>
        )}

        {/* DISCONNECTED OR STRANGER SKIPPED */}
        {matchState === 'disconnected' && (
          <div className="flex flex-col items-center justify-center p-8 text-center z-10">
            <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 mb-4 border border-slate-700">
              <User size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Stranger Left the Call</h3>
            <p className="text-slate-400 text-sm max-w-sm mb-6">
              The other person skipped or disconnected. Ready to meet the next stranger?
            </p>
            <button
              onClick={onNextStranger}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
            >
              Find Next Stranger
            </button>
          </div>
        )}

        {/* STRANGER INFO OVERLAY (WHEN CONNECTED) */}
        {matchState === 'connected' && (
          <div className="absolute top-4 left-4 z-10 flex items-center gap-2 bg-slate-950/80 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-800/80 text-xs text-white shadow-lg">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-emerald-400/20" />
            <span className="font-semibold">
              {isPracticeMode ? 'Practice Stranger (AI Bot)' : `Stranger (${stranger?.country || 'Worldwide'})`}
            </span>
            {stranger?.sharedInterests && stranger.sharedInterests.length > 0 && (
              <span className="text-indigo-400 text-xs hidden sm:inline">
                · {stranger.sharedInterests.join(', ')}
              </span>
            )}
          </div>
        )}

        {/* REPORT & SNAPSHOT CONTROLS (WHEN CONNECTED) */}
        {matchState === 'connected' && (
          <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
            <button
              onClick={takeSnapshot}
              title="Take Photobooth Snapshot"
              className="p-2.5 bg-slate-900/80 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl border border-slate-700/60 backdrop-blur-md transition-all cursor-pointer"
            >
              <SnapshotIcon size={16} />
            </button>
            <button
              onClick={onReportStranger}
              title="Report Inappropriate Behavior"
              className="p-2.5 bg-slate-900/80 hover:bg-rose-950/80 text-slate-400 hover:text-rose-400 rounded-xl border border-slate-700/60 backdrop-blur-md transition-all cursor-pointer"
            >
              <ShieldAlert size={16} />
            </button>
          </div>
        )}
      </div>

      {/* PICTURE-IN-PICTURE: LOCAL USER PREVIEW (VIDEO MODE ONLY) */}
      {chatMode === 'video' && (
        <div className="absolute bottom-4 right-4 z-20 w-36 h-28 sm:w-48 sm:h-36 rounded-xl overflow-hidden shadow-2xl border-2 border-slate-700 bg-slate-950 transition-all duration-200 group">
          {isCameraOff ? (
            <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900 text-slate-500">
              <CameraOff size={24} className="mb-1" />
              <span className="text-[10px] uppercase font-semibold tracking-wider">Camera Off</span>
            </div>
          ) : (
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover transform -scale-x-100 ${FILTER_CLASSES[videoFilter]} ${
                isLocalSpeaking ? 'ring-2 ring-indigo-400' : ''
              }`}
            />
          )}

          {/* Local Stream Status Overlays */}
          <div className="absolute top-2 left-2 flex items-center gap-1.5">
            {isMicMuted && (
              <div className="p-1 bg-rose-600/90 text-white rounded-md shadow-sm">
                <MicOff size={12} />
              </div>
            )}
            {!isMicMuted && isLocalSpeaking && (
              <div className="p-1 bg-emerald-500 text-white rounded-md shadow-sm animate-pulse">
                <Mic size={12} />
              </div>
            )}
          </div>

          <div className="absolute bottom-1.5 left-2 text-[10px] font-medium text-white/90 bg-slate-950/70 px-1.5 py-0.5 rounded">
            You
          </div>
        </div>
      )}
    </div>
  );
};
