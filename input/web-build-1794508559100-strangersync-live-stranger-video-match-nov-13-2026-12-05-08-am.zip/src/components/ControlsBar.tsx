import React, { useState } from 'react';
import {
  SkipForward,
  Square,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Wand2,
  Volume2,
  VolumeX,
  Share2,
  Dices,
  Play,
  MessageSquare,
  Copy,
  Check
} from 'lucide-react';
import { MatchState, VideoFilter, ChatMode } from '../types';

interface ControlsBarProps {
  matchState: MatchState;
  isMicMuted: boolean;
  isCameraOff: boolean;
  videoFilter: VideoFilter;
  soundEnabled: boolean;
  chatMode?: ChatMode;
  onNext: () => void;
  onStop: () => void;
  onStart: () => void;
  onToggleMic: () => void;
  onToggleCamera: () => void;
  onSelectFilter: (filter: VideoFilter) => void;
  onToggleSound: () => void;
  onShareScreen: () => void;
  onSendIcebreaker: () => void;
}

const FILTERS: { id: VideoFilter; label: string }[] = [
  { id: 'none', label: 'Original' },
  { id: 'warm', label: 'Warm Glow' },
  { id: 'cyber', label: 'Cyber Neon' },
  { id: 'noir', label: 'B&W Noir' },
  { id: 'vintage', label: 'Vintage Film' },
  { id: 'glow', label: 'Soft Glow' }
];

export const ControlsBar: React.FC<ControlsBarProps> = ({
  matchState,
  isMicMuted,
  isCameraOff,
  videoFilter,
  soundEnabled,
  chatMode = 'video',
  onNext,
  onStop,
  onStart,
  onToggleMic,
  onToggleCamera,
  onSelectFilter,
  onToggleSound,
  onShareScreen,
  onSendIcebreaker,
}) => {
  const [showFilters, setShowFilters] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const isConnected = matchState === 'connected';
  const isWaiting = matchState === 'waiting' || matchState === 'connecting';
  const isIdle = matchState === 'idle';

  return (
    <div className="relative flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 shadow-xl">
      {/* LEFT: MAIN MATCHMAKING ACTIONS (NEXT / STOP / START) */}
      <div className="flex items-center gap-2">
        {isIdle ? (
          <button
            onClick={onStart}
            className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer text-sm whitespace-nowrap"
          >
            <Play size={16} fill="currentColor" />
            <span>Start Matching</span>
          </button>
        ) : (
          <>
            <button
              onClick={onNext}
              disabled={isWaiting}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-400 hover:to-violet-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/25 transition-all disabled:opacity-50 cursor-pointer text-sm whitespace-nowrap"
              title="Skip to next stranger [Spacebar]"
            >
              <SkipForward size={16} />
              <span>Next Stranger</span>
              <kbd className="hidden sm:inline text-[10px] bg-white/20 px-1.5 py-0.5 rounded font-mono">
                Space
              </kbd>
            </button>

            <button
              onClick={onStop}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-800 hover:bg-rose-950/60 hover:text-rose-400 text-slate-300 font-medium rounded-xl border border-slate-700/60 transition-all cursor-pointer text-sm whitespace-nowrap"
              title="Stop video search [Esc]"
            >
              <Square size={14} />
              <span>Stop</span>
              <kbd className="hidden sm:inline text-[10px] bg-slate-700 px-1.5 py-0.5 rounded font-mono">
                Esc
              </kbd>
            </button>
          </>
        )}

        {/* ICEBREAKER GENERATOR BUTTON */}
        {isConnected && (
          <button
            onClick={onSendIcebreaker}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 rounded-xl border border-indigo-800/50 transition-all cursor-pointer text-xs font-semibold whitespace-nowrap"
            title="Send random icebreaker question to both"
          >
            <Dices size={15} />
            <span>Icebreaker</span>
          </button>
        )}
      </div>

      {/* RIGHT: HARDWARE & MEDIA CONTROLS */}
      <div className="flex items-center gap-2">
        {chatMode === 'text' ? (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/60 border border-slate-700/50 rounded-xl text-xs text-slate-400">
            <MessageSquare size={14} className="text-indigo-400" />
            <span>Text Chat (No Camera)</span>
          </div>
        ) : (
          <>
            {/* MIC TOGGLE */}
            <button
              onClick={onToggleMic}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                isMicMuted
                  ? 'bg-rose-950/70 text-rose-400 border-rose-800/60 hover:bg-rose-900/70'
                  : 'bg-slate-800/80 text-slate-200 border-slate-700/60 hover:bg-slate-700/80'
              }`}
              title={isMicMuted ? 'Unmute Microphone' : 'Mute Microphone'}
            >
              {isMicMuted ? <MicOff size={18} /> : <Mic size={18} />}
            </button>

            {/* CAMERA TOGGLE */}
            <button
              onClick={onToggleCamera}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                isCameraOff
                  ? 'bg-rose-950/70 text-rose-400 border-rose-800/60 hover:bg-rose-900/70'
                  : 'bg-slate-800/80 text-slate-200 border-slate-700/60 hover:bg-slate-700/80'
              }`}
              title={isCameraOff ? 'Turn Camera On' : 'Turn Camera Off'}
            >
              {isCameraOff ? <VideoOff size={18} /> : <Video size={18} />}
            </button>

            {/* SCREEN SHARE */}
            <button
              onClick={onShareScreen}
              className="p-2.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 rounded-xl border border-slate-700/60 transition-all cursor-pointer"
              title="Share Screen"
            >
              <Share2 size={18} />
            </button>

            {/* VIDEO FILTERS MENU */}
            <div className="relative">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                  videoFilter !== 'none'
                    ? 'bg-indigo-600/30 text-indigo-400 border-indigo-500/50'
                    : 'bg-slate-800/80 text-slate-200 border-slate-700/60 hover:bg-slate-700/80'
                }`}
                title="Video Visual Filters"
              >
                <Wand2 size={18} />
              </button>

              {showFilters && (
                <div className="absolute bottom-full right-0 mb-2 w-44 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-1.5 z-30 flex flex-col gap-1">
                  <span className="text-[11px] font-semibold text-slate-400 px-2 py-1">Video Effects</span>
                  {FILTERS.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => {
                        onSelectFilter(f.id);
                        setShowFilters(false);
                      }}
                      className={`text-left text-xs px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                        videoFilter === f.id
                          ? 'bg-indigo-600 text-white font-medium'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {/* SOUND EFFECTS TOGGLE */}
        <button
          onClick={onToggleSound}
          className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
            !soundEnabled
              ? 'bg-slate-800/50 text-slate-500 border-slate-700/40'
              : 'bg-slate-800/80 text-slate-200 border-slate-700/60 hover:bg-slate-700/80'
          }`}
          title={soundEnabled ? 'Mute Sound Effects' : 'Enable Sound Effects'}
        >
          {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
        </button>

        {/* SHARE / COPY WEB APP LINK */}
        <button
          onClick={handleCopyLink}
          className="p-2.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 rounded-xl border border-slate-700/60 transition-all cursor-pointer"
          title={copiedLink ? 'Web Link Copied to Clipboard!' : 'Copy Web Link'}
        >
          {copiedLink ? <Check size={18} className="text-emerald-400" /> : <Copy size={18} />}
        </button>
      </div>
    </div>
  );
};
