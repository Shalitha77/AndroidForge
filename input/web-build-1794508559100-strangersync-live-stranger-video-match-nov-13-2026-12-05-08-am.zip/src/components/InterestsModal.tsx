import React from 'react';
import { X, Sparkles, Globe } from 'lucide-react';

interface InterestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedInterests: string[];
  onChangeInterests: (interests: string[]) => void;
  selectedCountry: string;
  onChangeCountry: (country: string) => void;
}

const AVAILABLE_INTERESTS = [
  'Gaming',
  'Music',
  'Tech & AI',
  'Coding',
  'Anime',
  'Movies & TV',
  'Travel',
  'Fitness',
  'Art & Design',
  'Books & Writing',
  'Cooking',
  'Language Exchange',
  'Philosophy',
  'Chill & Chat'
];

const COUNTRIES = [
  { code: 'Global', label: 'Worldwide (Any Country)' },
  { code: 'US', label: 'United States' },
  { code: 'GB', label: 'United Kingdom' },
  { code: 'CA', label: 'Canada' },
  { code: 'DE', label: 'Germany' },
  { code: 'FR', label: 'France' },
  { code: 'JP', label: 'Japan' },
  { code: 'KR', label: 'South Korea' },
  { code: 'BR', label: 'Brazil' },
  { code: 'IN', label: 'India' },
  { code: 'AU', label: 'Australia' }
];

export const InterestsModal: React.FC<InterestsModalProps> = ({
  isOpen,
  onClose,
  selectedInterests,
  onChangeInterests,
  selectedCountry,
  onChangeCountry,
}) => {
  if (!isOpen) return null;

  const toggleInterest = (interest: string) => {
    if (selectedInterests.includes(interest)) {
      onChangeInterests(selectedInterests.filter((i) => i !== interest));
    } else {
      if (selectedInterests.length < 5) {
        onChangeInterests([...selectedInterests, interest]);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2 mb-2 text-indigo-400">
          <Sparkles size={20} />
          <h3 className="text-xl font-bold text-white">Matchmaking Preferences</h3>
        </div>
        <p className="text-xs text-slate-400 mb-6">
          StrangerSync will prioritize matching you with strangers who share your selected interests and region.
        </p>

        {/* COUNTRY SELECT */}
        <div className="mb-6">
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 mb-2">
            <Globe size={14} className="text-indigo-400" />
            Your Location / Region
          </label>
          <select
            value={selectedCountry}
            onChange={(e) => onChangeCountry(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label}
              </option>
            ))}
          </select>
        </div>

        {/* INTEREST TAGS */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-300">
              Select Interests (Up to 5)
            </label>
            <span className="text-[11px] text-slate-500">
              {selectedInterests.length} / 5 selected
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {AVAILABLE_INTERESTS.map((tag) => {
              const isSelected = selectedInterests.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleInterest(tag)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-600/30'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-2 border-t border-slate-800">
          <button
            onClick={() => onChangeInterests([])}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            Clear Tags
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
          >
            Apply & Save
          </button>
        </div>
      </div>
    </div>
  );
};
