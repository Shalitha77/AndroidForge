import React, { useState, useEffect } from 'react';
import { X, Sparkles, ExternalLink, ShieldCheck, ArrowRight } from 'lucide-react';
import { AdMobConfig } from '../types';

interface AppOpenAdModalProps {
  isOpen: boolean;
  config: AdMobConfig;
  onClose: () => void;
}

export const AppOpenAdModal: React.FC<AppOpenAdModalProps> = ({
  isOpen,
  config,
  onClose,
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState(4);
  const [canDismiss, setCanDismiss] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    setSecondsRemaining(4);
    setCanDismiss(false);

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanDismiss(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen || !config.adsEnabled || config.vipAdFree) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/98 backdrop-blur-lg animate-in fade-in duration-300">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden relative flex flex-col">
        {/* ADMOB APP OPEN HEADER BAR */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">
              AdMob App Open Ad
            </span>
            <span className="text-[10px] font-mono text-slate-400 hidden sm:inline">
              Unit: {config.appOpenUnitId}
            </span>
          </div>

          <div>
            {canDismiss ? (
              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-indigo-600/30 cursor-pointer"
              >
                <span>Continue to App</span>
                <ArrowRight size={14} />
              </button>
            ) : (
              <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 text-slate-300 rounded-lg text-xs font-mono">
                <span>Skip in {secondsRemaining}s</span>
              </div>
            )}
          </div>
        </div>

        {/* FULL APPOPEN AD CREATIVE */}
        <div className="p-6 sm:p-8 flex flex-col items-center text-center bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950/40">
          {/* App Branding Top Strip */}
          <div className="flex items-center gap-2 mb-6 text-slate-400 text-xs">
            <span className="font-bold text-white text-sm">StrangerSync</span>
            <span aria-hidden="true">·</span>
            <span>App ID: {config.appId}</span>
          </div>

          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-indigo-500 to-violet-600 flex items-center justify-center text-white mb-5 shadow-2xl shadow-indigo-500/30">
            <Sparkles size={40} />
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight mb-2">
            Next-Gen Global Chat Experience
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 max-w-sm mb-6 leading-relaxed">
            Ultra-fast peer-to-peer matchmaking, crystal-clear WebRTC video, and interest filters with strangers worldwide.
          </p>

          <a
            href="https://play.google.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/25 transition-all transform hover:scale-[1.02] cursor-pointer"
          >
            <span>Install on Google Play</span>
            <ExternalLink size={14} />
          </a>
        </div>

        {/* FOOTER DISCLOSURE */}
        <div className="px-4 py-2.5 bg-slate-950 flex items-center justify-between border-t border-slate-800 text-[10px] text-slate-500 font-mono">
          <div className="flex items-center gap-1.5">
            <ShieldCheck size={12} className="text-emerald-400" />
            <span>Google Mobile Ads SDK · App Open 2026</span>
          </div>
          <span>App ID: {config.appId.split('~')[0]}~...</span>
        </div>
      </div>
    </div>
  );
};
