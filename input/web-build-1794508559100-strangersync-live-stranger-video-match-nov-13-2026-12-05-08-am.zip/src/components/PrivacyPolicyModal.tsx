import React from 'react';
import { X, Shield, Lock, Eye, AlertCircle, Database, Mail } from 'lucide-react';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 relative max-h-[88vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2.5 mb-2 text-indigo-400">
          <Shield size={24} />
          <h3 className="text-xl sm:text-2xl font-bold text-white">Privacy Policy</h3>
        </div>
        <p className="text-xs text-slate-400 mb-6">
          Last Updated: November 2026 · Effective for StrangerSync Web & Mobile Applications
        </p>

        {/* SCROLLABLE POLICY CONTENT */}
        <div className="flex-1 overflow-y-auto space-y-5 text-xs text-slate-300 pr-2 leading-relaxed">
          <section className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Lock size={15} className="text-indigo-400" />
              1. Peer-to-Peer WebRTC Architecture (No Recordings)
            </h4>
            <p className="text-slate-400">
              StrangerSync operates on peer-to-peer (P2P) WebRTC technology. Your live camera video frames and audio streams are transmitted directly between your device and the stranger’s device via encrypted RTP/SRTP connections.
            </p>
            <p className="text-slate-400">
              <strong>We do NOT record, intercept, view, or store your live audio or video streams on our servers.</strong> Once a call ends or you skip to the next stranger, the connection is instantly severed.
            </p>
          </section>

          <section className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Database size={15} className="text-indigo-400" />
              2. Ephemeral Chat Messages
            </h4>
            <p className="text-slate-400">
              Messages and emoji reactions exchanged during a live call are strictly ephemeral. They reside solely in active browser session memory and are permanently wiped immediately upon skipping or closing the application. No chat logs are permanently archived.
            </p>
          </section>

          <section className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Eye size={15} className="text-indigo-400" />
              3. Advertising & Monetization (Google AdMob / AdSense)
            </h4>
            <p className="text-slate-400">
              StrangerSync is free to use and supported by third-party advertising partners, including <strong>Google AdMob</strong> and <strong>Google AdSense</strong>.
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-400 pl-2">
              <li>Third-party vendors, including Google, use cookies, device identifiers, or web storage to serve ads based on prior visits to our site or other websites.</li>
              <li>Google’s use of advertising cookies enables it and its partners to serve ads based on your visit to our sites and/or other sites on the Internet.</li>
              <li>You may opt out of personalized advertising by visiting <a href="https://adssettings.google.com" target="_blank" rel="noreferrer" className="text-indigo-400 underline">Google Ads Settings</a> or <a href="https://www.aboutads.info/choices" target="_blank" rel="noreferrer" className="text-indigo-400 underline">aboutads.info</a>.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <AlertCircle size={15} className="text-amber-400" />
              4. Age Restriction (18+ Mandatory)
            </h4>
            <p className="text-slate-400">
              StrangerSync is strictly restricted to individuals who are 18 years of age or older. We do not knowingly collect personal data from or permit access to minors. Any accounts or participants found violating this policy are banned immediately.
            </p>
          </section>

          <section className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Shield size={15} className="text-emerald-400" />
              5. User Rights (GDPR & CCPA)
            </h4>
            <p className="text-slate-400">
              Depending on your location, you may have rights under the General Data Protection Regulation (GDPR) or California Consumer Privacy Act (CCPA), including the right to request access, rectification, or deletion of any stored preferences or telemetry.
            </p>
          </section>

          <section className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Mail size={15} className="text-indigo-400" />
              6. Contact & Data Protection Officer
            </h4>
            <p className="text-slate-400">
              If you have questions about this Privacy Policy, your advertising preferences, or moderation issues, please contact us at: <strong className="text-white">shalithamuthu777@gmail.com</strong>.
            </p>
          </section>
        </div>

        <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-800">
          <span className="text-[11px] text-slate-500">
            Compliant with Google AdMob & WebRTC Security Guidelines
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
