import React from 'react';
import { X, ShieldCheck, AlertTriangle, EyeOff, Flag } from 'lucide-react';

interface SafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-2 mb-2 text-emerald-400">
          <ShieldCheck size={22} />
          <h3 className="text-xl font-bold text-white">Community & Safety Standards</h3>
        </div>
        <p className="text-xs text-slate-400 mb-6">
          StrangerSync is dedicated to providing a safe, respectful, and friendly video chat environment.
        </p>

        <div className="space-y-4 mb-6 text-xs text-slate-300">
          <div className="flex items-start gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800">
            <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-white mb-0.5">18+ Only Community</h4>
              <p className="text-slate-400 leading-relaxed">
                You must be 18 years or older to use this service. Minors are strictly prohibited from participating.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800">
            <EyeOff size={18} className="text-rose-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-white mb-0.5">Zero Tolerance Policy</h4>
              <p className="text-slate-400 leading-relaxed">
                Nudity, hate speech, vulgar conduct, and harassment result in immediate and permanent connection bans.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800">
            <Flag size={18} className="text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-white mb-0.5">Instant Reporting & Moderation</h4>
              <p className="text-slate-400 leading-relaxed">
                Use the Shield icon in the top right of the video feed to immediately disconnect and flag any abusive user.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
          >
            I Understand & Agree
          </button>
        </div>
      </div>
    </div>
  );
};
