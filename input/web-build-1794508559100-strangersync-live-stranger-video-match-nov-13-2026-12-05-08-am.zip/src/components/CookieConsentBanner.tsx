import React, { useState, useEffect } from 'react';
import { Cookie } from 'lucide-react';

interface CookieConsentBannerProps {
  onOpenPrivacy: () => void;
}

export const CookieConsentBanner: React.FC<CookieConsentBannerProps> = ({ onOpenPrivacy }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('strangersync_cookie_consent');
    if (!consent) {
      // Delay slightly for smooth page entrance
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('strangersync_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('strangersync_cookie_consent', 'declined_non_essential');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-md z-40 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-2xl p-4 text-xs text-slate-300 animate-in slide-in-from-bottom-5 duration-300">
      <div className="flex items-start gap-3 mb-3">
        <Cookie size={20} className="text-amber-400 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-white text-sm mb-1">AdMob & Cookie Preferences</h4>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            We and our advertising partners (Google AdMob & AdSense) use cookies and anonymous device IDs to deliver relevant ads and support this free service.
          </p>
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800">
        <button
          onClick={onOpenPrivacy}
          className="text-[11px] text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
        >
          Privacy Policy
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDecline}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition-colors cursor-pointer"
          >
            Essential Only
          </button>
          <button
            onClick={handleAccept}
            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-indigo-600/30 cursor-pointer"
          >
            Accept All
          </button>
        </div>
      </div>
    </div>
  );
};
