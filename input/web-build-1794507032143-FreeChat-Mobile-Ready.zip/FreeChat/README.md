# Free Chat — Android Studio starter

This is Android Studio source, NOT an APK or AAB. No Android build or real-device test has been run here. It wraps https://chance-meet-chat.lovable.app in Android WebView; the hosted website must remain online. It is not a standalone native rewrite and is not ready for Play Store submission.

## Open and build
1. Install current Android Studio on your computer.
2. Extract this ZIP and open the **FreeChat** folder (the one containing settings.gradle).
3. Allow Gradle sync to download dependencies. Use JDK 17 and install Android SDK 35 if prompted.
4. Connect an Android phone or start an emulator with camera/microphone support, then click Run.
5. Test with two separate signed-in devices, including camera/microphone rejection, Next, Stop, reporting and leaving the app. Firebase Anonymous sign-in must be enabled; its hosted settings have not been verified.

Package/application ID: **free.chat.com**. App name: **Free Chat**.

## Create your signed APK or AAB
In Android Studio choose **Build → Generate Signed App Bundle or APK**. Choose Android App Bundle for Play Store or APK for installation. Select your existing private keystore on YOUR computer and enter its alias/passwords only in Android Studio. Choose release. Do not upload the keystore or passwords to chat. Follow Android Studio's output link to find your generated file.

## AdMob
A consent-gated TEST banner is wired. Production identifiers for all five formats are saved in AdUnits.java. No production ads are requested by default, and no revenue is guaranteed.

Before enabling production: configure your AdMob consent message and privacy policy, verify suitability/age restrictions for random video chat, use registered test devices, and test consent in each relevant region. Change the app ID in app/build.gradle to `ca-app-pub-9670799162361917~3884525139` and change the banner unit from AdUnits.TEST_BANNER to AdUnits.BANNER only after testing. Do not click live ads yourself.

Interstitial, rewarded, app-open and native IDs are retained but those formats are NOT implemented. Rewarded ads need a defined reward; fullscreen ads must not interrupt calls. Configure a consent message for the test app as well or the banner may stay hidden. This is safe behavior when consent cannot be established.

## Important limitations before release
- Google popup sign-in is not supported by this starter; use guest sign-in. Native Google sign-in needs a separate implementation and Firebase configuration.
- Push/FCM, background calling and production TURN credentials are not included.
- Leaving the foreground stops visible video tracks and reloads the page; verify call cleanup and Firebase presence on real devices.
- The website's Firebase security rules, moderation, age safeguards, blocking, privacy policy, account deletion and Play Store/Data Safety compliance must be audited before public release. An existing report button alone is not a moderation system.
- This source has been inspected for packaging only; successful Android compilation, video calls, consent and ad serving remain unverified.
