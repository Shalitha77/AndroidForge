package free.chat.com;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String HOST = "chance-meet-chat.lovable.app";
    private WebView web;
    private LinearLayout layout;
    private AdView banner;
    private PermissionRequest pending;
    private ConsentInformation consent;
    private Button privacy;
    private boolean adsStarted;

    private boolean trusted(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getHost())
            && (uri.getPort() == -1 || uri.getPort() == 443);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        // Keep content clear of system bars when targeting Android 15.
        layout.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(layout);
        web = new WebView(this);
        layout.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (trusted(request.getUrl())) return false;
                Toast.makeText(MainActivity.this, "Use guest sign-in in this Android starter.", Toast.LENGTH_LONG).show();
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (!trusted(request.getOrigin())) { request.deny(); return; }
                    if (pending != null) pending.deny();
                    pending = request;
                    List<String> permissions = new ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                            && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                            permissions.add(Manifest.permission.CAMERA);
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                            && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                            permissions.add(Manifest.permission.RECORD_AUDIO);
                    }
                    if (permissions.isEmpty()) completePermission();
                    else requestPermissions(permissions.toArray(new String[0]), 20);
                });
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pending == request) pending = null;
            }
        });
        privacy = new Button(this);
        privacy.setText("Privacy choices");
        privacy.setVisibility(View.GONE);
        privacy.setOnClickListener(v -> UserMessagingPlatform.showPrivacyOptionsForm(this, error -> {}));
        layout.addView(privacy);
        web.loadUrl("https://" + HOST + "/");
        consent = UserMessagingPlatform.getConsentInformation(this);
        consent.requestConsentInfoUpdate(this, new ConsentRequestParameters.Builder().build(), () -> {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(this, error -> {
                updatePrivacy(); startAdsIfAllowed();
            });
        }, error -> { updatePrivacy(); startAdsIfAllowed(); });
    }

    private void updatePrivacy() {
        privacy.setVisibility(consent.getPrivacyOptionsRequirementStatus()
            == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED ? View.VISIBLE : View.GONE);
    }

    private void startAdsIfAllowed() {
        if (adsStarted || !consent.canRequestAds() || isFinishing() || isDestroyed()) return;
        adsStarted = true;
        MobileAds.initialize(this, status -> runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            banner = new AdView(this);
            banner.setAdSize(AdSize.BANNER);
            banner.setAdUnitId(AdUnits.TEST_BANNER);
            layout.addView(banner, new LinearLayout.LayoutParams(-1, -2));
            banner.loadAd(new AdRequest.Builder().build());
        }));
    }

    private void completePermission() {
        if (pending == null) return;
        List<String> allowed = new ArrayList<>();
        for (String resource : pending.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) allowed.add(resource);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) allowed.add(resource);
        }
        if (allowed.isEmpty()) pending.deny();
        else pending.grant(allowed.toArray(new String[0]));
        pending = null;
    }

    @Override public void onRequestPermissionsResult(int code, String[] names, int[] results) {
        super.onRequestPermissionsResult(code, names, results);
        if (code == 20) completePermission();
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setMessage("Leave Free Chat?")
            .setNegativeButton("Stay", null).setPositiveButton("Leave", (dialog, which) -> finish()).show();
    }

    @Override protected void onPause() {
        web.evaluateJavascript("document.querySelectorAll('video').forEach(v => { if(v.srcObject) v.srcObject.getTracks().forEach(t => t.stop()); }); location.reload();", null);
        web.onPause();
        if (banner != null) banner.pause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        if (banner != null) banner.resume();
    }
    @Override protected void onDestroy() {
        if (pending != null) { pending.deny(); pending = null; }
        if (banner != null) banner.destroy();
        web.destroy();
        super.onDestroy();
    }
}
