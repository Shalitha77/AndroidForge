package free.chat.com;

final class AdUnits {
    // User supplied production IDs; only banner is wired in this starter.
    static final String APP = "ca-app-pub-9670799162361917~3884525139";
    static final String BANNER = "ca-app-pub-9670799162361917/1967799073";
    static final String INTERSTITIAL = "ca-app-pub-9670799162361917/4645933303";
    static final String REWARDED = "ca-app-pub-9670799162361917/1495211698";
    static final String APP_OPEN = "ca-app-pub-9670799162361917/4454361610";
    static final String NATIVE = "ca-app-pub-9670799162361917/8394615787";
    static final String TEST_BANNER = "ca-app-pub-3940256099942544/6300978111";
    private AdUnits() {}
}
