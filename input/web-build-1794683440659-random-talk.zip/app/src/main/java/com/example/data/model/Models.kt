package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class ThemeMode(val wireValue: String, val label: String) {
    SYSTEM("system", "System Default"),
    DARK("dark", "Midnight Dark"),
    LIGHT("light", "Daylight");

    companion object {
        fun fromWire(value: String?): ThemeMode =
            entries.firstOrNull { it.wireValue == value } ?: DARK
    }
}

enum class GenderIdentity(val wireValue: String, val label: String) {
    UNSPECIFIED("unspecified", "Prefer not to say"),
    MALE("male", "Male"),
    FEMALE("female", "Female"),
    NON_BINARY("non_binary", "Non-binary");

    companion object {
        fun fromWire(value: String?): GenderIdentity =
            entries.firstOrNull { it.wireValue == value } ?: UNSPECIFIED
    }
}

enum class GenderPreference(val wireValue: String, val label: String) {
    ANY("any", "Everyone"),
    MALE("male", "Men"),
    FEMALE("female", "Women"),
    NON_BINARY("non_binary", "Non-binary");

    companion object {
        fun fromWire(value: String?): GenderPreference =
            entries.firstOrNull { it.wireValue == value } ?: ANY
    }
}

data class CountryOption(
    val code: String,
    val name: String,
    val flagEmoji: String,
    val genderFilterSupported: Boolean = true
)

object SupportedCountries {
    val all: List<CountryOption> = listOf(
        CountryOption("GLOBAL", "Worldwide", "🌍", true),
        CountryOption("US", "United States", "🇺🇸", true),
        CountryOption("GB", "United Kingdom", "🇬🇧", true),
        CountryOption("CA", "Canada", "🇨🇦", true),
        CountryOption("DE", "Germany", "🇩🇪", false),
        CountryOption("FR", "France", "🇫🇷", false),
        CountryOption("JP", "Japan", "🇯🇵", true),
        CountryOption("KR", "South Korea", "🇰🇷", true),
        CountryOption("BR", "Brazil", "🇧🇷", true),
        CountryOption("IN", "India", "🇮🇳", true),
        CountryOption("AU", "Australia", "🇦🇺", true),
        CountryOption("ES", "Spain", "🇪🇸", true),
        CountryOption("IT", "Italy", "🇮🇹", true),
        CountryOption("TR", "Turkey", "🇹🇷", true),
        CountryOption("MX", "Mexico", "🇲🇽", true),
        CountryOption("ID", "Indonesia", "🇮🇩", true),
        CountryOption("PH", "Philippines", "🇵🇭", true)
    )

    fun byCode(code: String?): CountryOption =
        all.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: all.first()
}

enum class ReportReason(val wireValue: String, val title: String, val subtitle: String) {
    INAPPROPRIATE_CONTENT("inappropriate_content", "Inappropriate Content", "Explicit, offensive, or unsafe visuals or behavior"),
    HARASSMENT("harassment", "Harassment or Bullying", "Verbal abuse, threats, or hate speech"),
    NUDITY("nudity", "Nudity / Sexual Content", "Violates community safety guidelines"),
    UNDERAGE("underage", "Underage User (<18)", "User appears to be under 18 years old"),
    SPAM("spam", "Spam or Scam", "Promotional bots, links, or deceptive conduct"),
    OTHER("other", "Other Safety Concern", "Any other violation of Terms & Guidelines")
}

enum class CallConnectionState {
    IDLE,
    REQUESTING_PERMISSIONS,
    SEARCHING,
    MATCHED_CONNECTING,
    CONNECTED,
    RECONNECTING,
    PEER_ENDED,
    ERROR
}

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val alias: String = "",
    val country: String = "US",
    val gender: String = GenderIdentity.UNSPECIFIED.wireValue,
    val preferredCountry: String = "GLOBAL",
    val preferredGender: String = GenderPreference.ANY.wireValue,
    val ageConfirmed18Plus: Boolean = false,
    val guidelinesAccepted: Boolean = false,
    val themeMode: String = ThemeMode.DARK.wireValue,
    val lowBandwidthMode: Boolean = false,
    val reportCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class BlockedUser(
    @DocumentId val id: String = "",
    val userId: String = "",
    val blockedUserId: String = "",
    val reason: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class OnlinePresence(
    @DocumentId val id: String = "",
    val userId: String = "",
    val country: String = "GLOBAL",
    val isOnline: Boolean = true,
    @ServerTimestamp val heartbeatAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class MatchQueueEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val alias: String = "",
    val country: String = "GLOBAL",
    val gender: String = GenderIdentity.UNSPECIFIED.wireValue,
    val preferredCountry: String = "GLOBAL",
    val preferredGender: String = GenderPreference.ANY.wireValue,
    val status: String = "waiting",
    val ageConfirmed18Plus: Boolean = true,
    val roomId: String? = null,
    val matchedBy: String? = null,
    @ServerTimestamp val heartbeatAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CallRoom(
    @DocumentId val id: String = "",
    val callerId: String = "",
    val calleeId: String = "",
    val participants: List<String> = emptyList(),
    val callerAlias: String = "",
    val calleeAlias: String = "",
    val callerCountry: String = "GLOBAL",
    val calleeCountry: String = "GLOBAL",
    val status: String = "offering",
    val offerSdp: String? = null,
    val offerType: String? = null,
    val answerSdp: String? = null,
    val answerType: String? = null,
    val endedBy: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class IceCandidateSignal(
    @DocumentId val id: String = "",
    val senderId: String = "",
    val participants: List<String> = emptyList(),
    val sdpMid: String = "",
    val sdpMLineIndex: Long = 0L,
    val candidate: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
