package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ads.AdConsentHelper
import com.example.data.firebase.AuthManager
import com.example.data.model.BlockedUser
import com.example.data.model.SupportedCountries
import com.example.data.model.ThemeMode
import com.example.data.model.UserProfile
import com.example.ui.components.CountryPickerSheet
import com.example.ui.components.LegalDocuments
import com.example.ui.components.RandomTalkBackground
import com.example.ui.theme.DangerRed

@Composable
fun SettingsScreen(
    profile: UserProfile?,
    themeMode: ThemeMode,
    blockedUsers: List<BlockedUser>,
    onBack: () -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    onLowBandwidthChange: (Boolean) -> Unit,
    onAliasChange: (String) -> Unit,
    onMyCountryChange: (String) -> Unit,
    onUnblockUser: (String) -> Unit,
    onDeleteAccount: (onComplete: () -> Unit, onError: (String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var activeLegalTitle by remember { mutableStateOf<String?>(null) }
    var activeLegalText by remember { mutableStateOf("") }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showAliasDialog by remember { mutableStateOf(false) }
    var showMyCountrySheet by remember { mutableStateOf(false) }
    var showBlockedDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }

    BackHandler { onBack() }

    RandomTalkBackground {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back to Home",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.settings_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (feedbackMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Text(
                            text = feedbackMessage!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // Appearance Section
                SettingsSectionHeader("Appearance")
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Theme Mode", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ThemeMode.entries.forEach { mode ->
                                val selected = mode == themeMode
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .minimumInteractiveComponentSize()
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { onThemeModeChange(mode) }
                                        .testTag("theme_mode_${mode.wireValue}"),
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (selected) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    },
                                    border = if (selected) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = when (mode) {
                                                ThemeMode.SYSTEM -> "System"
                                                ThemeMode.DARK -> "Dark"
                                                ThemeMode.LIGHT -> "Light"
                                            },
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Profile & Video Quality
                SettingsSectionHeader("Profile & Video")
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsActionRow(
                            icon = Icons.Rounded.Edit,
                            title = "Anonymous Display Alias",
                            subtitle = profile?.alias ?: "Traveler",
                            onClick = { showAliasDialog = true },
                            testTag = "edit_alias_row"
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.Public,
                            title = "My Region",
                            subtitle = SupportedCountries.byCode(profile?.country).let { "${it.flagEmoji} ${it.name}" },
                            onClick = { showMyCountrySheet = true },
                            testTag = "my_country_row"
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Low-Bandwidth Optimization", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Reduces video bitrate & FPS on slower cellular connections",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = profile?.lowBandwidthMode ?: false,
                                onCheckedChange = onLowBandwidthChange,
                                modifier = Modifier.testTag("low_bandwidth_switch")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Safety & Legal
                SettingsSectionHeader("Safety & Policies")
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsActionRow(
                            icon = Icons.Rounded.Block,
                            title = "Blocked Users",
                            subtitle = "${blockedUsers.size} blocked peer(s)",
                            onClick = { showBlockedDialog = true },
                            testTag = "blocked_users_row"
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.Shield,
                            title = "Community Guidelines (18+)",
                            subtitle = "Safety rules and moderation enforcement",
                            onClick = {
                                activeLegalTitle = "Community Guidelines"
                                activeLegalText = LegalDocuments.communityGuidelines
                            },
                            testTag = "guidelines_row"
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.Policy,
                            title = "Privacy Policy",
                            subtitle = "How data, WebRTC, and Ad consent are handled",
                            onClick = {
                                activeLegalTitle = "Privacy Policy"
                                activeLegalText = LegalDocuments.privacyPolicy
                            },
                            testTag = "privacy_policy_row"
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.Description,
                            title = "Terms & Conditions",
                            subtitle = "Service terms and 18+ eligibility",
                            onClick = {
                                activeLegalTitle = "Terms & Conditions"
                                activeLegalText = LegalDocuments.termsAndConditions
                            },
                            testTag = "terms_row"
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.Policy,
                            title = "Ad Privacy & Consent Options",
                            subtitle = "Review Google AdMob UMP consent settings",
                            onClick = {
                                val act = context as? Activity
                                if (act != null) {
                                    AdConsentHelper.showPrivacyOptions(act) {
                                        feedbackMessage = "Ad privacy preferences updated."
                                    }
                                }
                            },
                            testTag = "ad_consent_row"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Support & Account
                SettingsSectionHeader("Support & Account")
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsActionRow(
                            icon = Icons.Rounded.Info,
                            title = "About Random Talk",
                            subtitle = "Version 1.0 • com.randomtalk.videochat",
                            onClick = { showAboutDialog = true },
                            testTag = "about_row"
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.Email,
                            title = "Contact Support",
                            subtitle = "support@randomtalk.app",
                            onClick = {
                                val intent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("mailto:support@randomtalk.app")
                                    putExtra(Intent.EXTRA_SUBJECT, "Random Talk Support Request")
                                }
                                runCatching { context.startActivity(intent) }
                                    .onFailure {
                                        feedbackMessage = "Email support@randomtalk.app for assistance."
                                    }
                            },
                            testTag = "contact_support_row"
                        )
                        SettingsActionRow(
                            icon = Icons.AutoMirrored.Rounded.Logout,
                            title = "Sign Out",
                            subtitle = "Switch Google account",
                            onClick = {
                                AuthManager.signOut(credentialManager, coroutineScope)
                            },
                            testTag = "sign_out_row"
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.DeleteForever,
                            title = "Delete Account",
                            subtitle = "Permanently remove profile, blocklist, and Auth account",
                            iconTint = DangerRed,
                            titleColor = DangerRed,
                            onClick = { showDeleteDialog = true },
                            testTag = "delete_account_row"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (activeLegalTitle != null) {
        AlertDialog(
            onDismissRequest = { activeLegalTitle = null },
            title = { Text(activeLegalTitle!!) },
            text = {
                Box(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(activeLegalText, style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = {
                TextButton(onClick = { activeLegalTitle = null }) { Text("Close") }
            }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("About Random Talk") },
            text = {
                Text(
                    "Random Talk connects adults (18+) around the world through encrypted peer-to-peer WebRTC video and audio conversations, backed by Firebase Authentication, Cloud Firestore matchmaking, Firebase App Check, and Google AdMob.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) { Text("OK") }
            }
        )
    }

    if (showAliasDialog) {
        var aliasInput by remember { mutableStateOf(profile?.alias ?: "") }
        AlertDialog(
            onDismissRequest = { showAliasDialog = false },
            title = { Text("Update Display Alias") },
            text = {
                Column {
                    Text(
                        "Choose a non-personal nickname shown to chat partners.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = aliasInput,
                        onValueChange = { if (it.length <= 32) aliasInput = it },
                        singleLine = true,
                        label = { Text("Alias (2–32 chars)") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAliasChange(aliasInput)
                        showAliasDialog = false
                    },
                    enabled = aliasInput.trim().length in 2..32
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAliasDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showMyCountrySheet) {
        CountryPickerSheet(
            title = "Select Your Region",
            selectedCode = profile?.country ?: "US",
            includeGlobal = false,
            onSelect = { onMyCountryChange(it.code) },
            onDismiss = { showMyCountrySheet = false }
        )
    }

    if (showBlockedDialog) {
        AlertDialog(
            onDismissRequest = { showBlockedDialog = false },
            title = { Text("Blocked Users (${blockedUsers.size})") },
            text = {
                if (blockedUsers.isEmpty()) {
                    Text("You haven't blocked anyone.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        blockedUsers.forEach { blocked ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Peer #${blocked.blockedUserId.take(6)}",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                    Text(
                                        text = blocked.reason.ifBlank { "Blocked" },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TextButton(onClick = { onUnblockUser(blocked.blockedUserId) }) {
                                    Text("Unblock")
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBlockedDialog = false }) { Text("Done") }
            }
        )
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Account Permanently?") },
            text = {
                Text(
                    "This deletes your Random Talk profile, preferences, blocklist, and Firebase account immediately. This action cannot be undone.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteDialog = false
                        onDeleteAccount(
                            { AuthManager.signOut(credentialManager, coroutineScope) },
                            { err -> feedbackMessage = err }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                ) {
                    Text("Delete Forever")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
    )
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String,
    iconTint: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.primary,
    titleColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = iconTint)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = titleColor)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
