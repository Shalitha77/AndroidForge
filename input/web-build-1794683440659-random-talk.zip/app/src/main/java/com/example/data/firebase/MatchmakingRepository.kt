package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.model.BlockedUser
import com.example.data.model.CallRoom
import com.example.data.model.GenderIdentity
import com.example.data.model.GenderPreference
import com.example.data.model.IceCandidateSignal
import com.example.data.model.MatchQueueEntry
import com.example.data.model.OnlinePresence
import com.example.data.model.ReportReason
import com.example.data.model.ThemeMode
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.Locale
import java.util.UUID
import kotlin.random.Random

sealed interface MatchAttemptResult {
    data class Matched(val roomId: String, val isCaller: Boolean, val peerAlias: String, val peerCountry: String, val peerId: String) : MatchAttemptResult
    data object WaitingInQueue : MatchAttemptResult
}

class MatchmakingRepository(
    private val db: FirebaseFirestore,
    private val auth: com.google.firebase.auth.FirebaseAuth = Firebase.auth
) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    suspend fun ensureProfile(userId: String): UserProfile {
        val docRef = db.collection("users").document(userId)
        try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                val parsed = existing.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                if (parsed != null) return parsed
            }
            val detectedCountry = Locale.getDefault().country.takeIf { it.length == 2 } ?: "US"
            val randomAlias = "Traveler_${Random.nextInt(1000, 9999)}"
            val payload = mapOf(
                "userId" to userId,
                "alias" to randomAlias,
                "country" to detectedCountry,
                "gender" to GenderIdentity.UNSPECIFIED.wireValue,
                "preferredCountry" to "GLOBAL",
                "preferredGender" to GenderPreference.ANY.wireValue,
                "ageConfirmed18Plus" to false,
                "guidelinesAccepted" to false,
                "themeMode" to ThemeMode.DARK.wireValue,
                "lowBandwidthMode" to false,
                "reportCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            val created = docRef.get().await()
            return created.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: UserProfile(
                    id = userId,
                    userId = userId,
                    alias = randomAlias,
                    country = detectedCountry
                )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    fun observeProfile(userId: String): Flow<UserProfile?> = flow {
        val docRef = db.collection("users").document(userId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    suspend fun updateProfilePreferences(
        userId: String,
        alias: String? = null,
        country: String? = null,
        gender: String? = null,
        preferredCountry: String? = null,
        preferredGender: String? = null,
        ageConfirmed18Plus: Boolean? = null,
        guidelinesAccepted: Boolean? = null,
        themeMode: String? = null,
        lowBandwidthMode: Boolean? = null
    ) {
        val uid = requireUserId()
        require(uid == userId) { "Authenticated user mismatch" }
        val docRef = db.collection("users").document(uid)
        val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
        alias?.takeIf { it.length in 2..32 }?.let { updates["alias"] = it }
        country?.takeIf { it.length in 2..16 }?.let { updates["country"] = it }
        gender?.let { updates["gender"] = it }
        preferredCountry?.takeIf { it.length in 2..16 }?.let { updates["preferredCountry"] = it }
        preferredGender?.let { updates["preferredGender"] = it }
        ageConfirmed18Plus?.let { updates["ageConfirmed18Plus"] = it }
        guidelinesAccepted?.let { updates["guidelinesAccepted"] = it }
        themeMode?.let { updates["themeMode"] = it }
        lowBandwidthMode?.let { updates["lowBandwidthMode"] = it }

        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    fun observeOnlineCount(): Flow<Int> = flow {
        val query = db.collection("online_presence").whereEqualTo("isOnline", true)
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    val cutoffSeconds = Timestamp.now().seconds - 180L
                    snapshot.documents.count { doc ->
                        val hb = doc.getTimestamp("heartbeatAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        hb == null || hb.seconds >= cutoffSeconds
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, "online_presence")
                    }
                    emit(0)
                }
        )
    }

    suspend fun updatePresenceHeartbeat(userId: String, country: String, isOnline: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        if (uid != userId) return
        val docRef = db.collection("online_presence").document(uid)
        val payload = mapOf(
            "userId" to uid,
            "country" to country.ifBlank { "GLOBAL" },
            "isOnline" to isOnline,
            "heartbeatAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
        }
    }

    fun observeBlockedUsers(userId: String): Flow<List<BlockedUser>> = flow {
        val colRef = db.collection("users").document(userId).collection("blocked")
        emitAll(
            colRef.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(BlockedUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, colRef.path)
                    }
                    throw error
                }
        )
    }

    suspend fun blockUser(blockedUserId: String, reason: String = "User blocked") {
        val uid = requireUserId()
        if (blockedUserId == uid || blockedUserId.isBlank()) return
        val docRef = db.collection("users").document(uid).collection("blocked").document(blockedUserId)
        val payload = mapOf(
            "userId" to uid,
            "blockedUserId" to blockedUserId,
            "reason" to reason.take(120),
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun unblockUser(blockedUserId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("blocked").document(blockedUserId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun submitReport(
        reportedUserId: String,
        roomId: String,
        reason: ReportReason,
        details: String
    ) {
        val uid = requireUserId()
        if (reportedUserId == uid || reportedUserId.isBlank()) return
        val reportId = "rep_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val docRef = db.collection("reports").document(reportId)
        val payload = mapOf(
            "reporterId" to uid,
            "reportedUserId" to reportedUserId,
            "roomId" to roomId.take(128),
            "reason" to reason.wireValue,
            "details" to details.trim().take(500),
            "status" to "pending",
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            blockUser(reportedUserId, "Reported: ${reason.title}")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun enterQueueAndFindMatch(
        profile: UserProfile,
        blockedIds: Set<String>,
        recentPeerIds: Set<String>
    ): MatchAttemptResult {
        val uid = requireUserId()
        require(profile.ageConfirmed18Plus) { "18+ age confirmation is required." }

        val myQueueRef = db.collection("match_queue").document(uid)
        val myEntryPayload = mapOf(
            "userId" to uid,
            "alias" to profile.alias.ifBlank { "Traveler" }.take(32),
            "country" to profile.country.ifBlank { "GLOBAL" },
            "gender" to profile.gender,
            "preferredCountry" to profile.preferredCountry.ifBlank { "GLOBAL" },
            "preferredGender" to profile.preferredGender,
            "status" to "waiting",
            "ageConfirmed18Plus" to true,
            "heartbeatAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        try {
            myQueueRef.set(myEntryPayload).await()

            val candidatesSnap = db.collection("match_queue")
                .whereEqualTo("status", "waiting")
                .whereEqualTo("ageConfirmed18Plus", true)
                .limit(25)
                .get()
                .await()

            val cutoffSeconds = Timestamp.now().seconds - 75L
            val candidates = candidatesSnap.documents
                .mapNotNull { it.toObject(MatchQueueEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .filter { candidate ->
                    candidate.userId.isNotBlank() &&
                        candidate.userId != uid &&
                        candidate.status == "waiting" &&
                        !blockedIds.contains(candidate.userId) &&
                        !recentPeerIds.contains(candidate.userId) &&
                        (candidate.heartbeatAt == null || candidate.heartbeatAt.seconds >= cutoffSeconds) &&
                        matchesPreferences(profile, candidate)
                }

            for (candidate in candidates.shuffled()) {
                val roomId = "room_${UUID.randomUUID().toString().replace("-", "").take(20)}"
                val peerQueueRef = db.collection("match_queue").document(candidate.userId)
                val roomRef = db.collection("call_rooms").document(roomId)

                val claimed = try {
                    db.runTransaction { tx ->
                        val peerDoc = tx.get(peerQueueRef)
                        val myDoc = tx.get(myQueueRef)
                        if (!peerDoc.exists() || peerDoc.getString("status") != "waiting") {
                            return@runTransaction false
                        }
                        if (!myDoc.exists() || myDoc.getString("status") != "waiting") {
                            return@runTransaction false
                        }

                        tx.update(
                            peerQueueRef,
                            mapOf(
                                "status" to "matched",
                                "roomId" to roomId,
                                "matchedBy" to uid,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        tx.update(
                            myQueueRef,
                            mapOf(
                                "status" to "matched",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        tx.set(
                            roomRef,
                            mapOf(
                                "callerId" to uid,
                                "calleeId" to candidate.userId,
                                "participants" to listOf(uid, candidate.userId),
                                "callerAlias" to profile.alias.ifBlank { "Traveler" }.take(32),
                                "calleeAlias" to candidate.alias.ifBlank { "Stranger" }.take(32),
                                "callerCountry" to profile.country.ifBlank { "GLOBAL" },
                                "calleeCountry" to candidate.country.ifBlank { "GLOBAL" },
                                "status" to "offering",
                                "createdAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        true
                    }.await()
                } catch (_: Exception) {
                    false
                }

                if (claimed) {
                    return MatchAttemptResult.Matched(
                        roomId = roomId,
                        isCaller = true,
                        peerAlias = candidate.alias.ifBlank { "Stranger" },
                        peerCountry = candidate.country.ifBlank { "GLOBAL" },
                        peerId = candidate.userId
                    )
                }
            }

            return MatchAttemptResult.WaitingInQueue
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "match_queue")
            throw e
        }
    }

    private fun matchesPreferences(me: UserProfile, peer: MatchQueueEntry): Boolean {
        val myCountryPrefOk = me.preferredCountry == "GLOBAL" || me.preferredCountry == peer.country
        val peerCountryPrefOk = peer.preferredCountry == "GLOBAL" || peer.preferredCountry == me.country
        val myGenderPrefOk = me.preferredGender == GenderPreference.ANY.wireValue || me.preferredGender == peer.gender
        val peerGenderPrefOk = peer.preferredGender == GenderPreference.ANY.wireValue || peer.preferredGender == me.gender
        return myCountryPrefOk && peerCountryPrefOk && myGenderPrefOk && peerGenderPrefOk
    }

    suspend fun refreshQueueHeartbeat(userId: String) {
        val uid = auth.currentUser?.uid ?: return
        if (uid != userId) return
        val docRef = db.collection("match_queue").document(uid)
        try {
            docRef.update(
                mapOf(
                    "heartbeatAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (_: Exception) {
            // Queue entry may already have been claimed or deleted
        }
    }

    fun observeMyQueueEntry(userId: String): Flow<MatchQueueEntry?> = flow {
        val docRef = db.collection("match_queue").document(userId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    snapshot.toObject(MatchQueueEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    suspend fun leaveQueue(userId: String) {
        val uid = auth.currentUser?.uid ?: return
        if (uid != userId) return
        val docRef = db.collection("match_queue").document(uid)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
        }
    }

    suspend fun getCallRoom(roomId: String): CallRoom? {
        val docRef = db.collection("call_rooms").document(roomId)
        return try {
            docRef.get().await().toObject(CallRoom::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            null
        }
    }

    fun observeCallRoom(roomId: String): Flow<CallRoom?> = flow {
        val docRef = db.collection("call_rooms").document(roomId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    snapshot.toObject(CallRoom::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser != null) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    suspend fun writeOffer(roomId: String, sdp: String) {
        requireUserId()
        val docRef = db.collection("call_rooms").document(roomId)
        try {
            docRef.update(
                mapOf(
                    "offerSdp" to sdp,
                    "offerType" to "offer",
                    "status" to "offering",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun writeAnswer(roomId: String, sdp: String) {
        requireUserId()
        val docRef = db.collection("call_rooms").document(roomId)
        try {
            docRef.update(
                mapOf(
                    "answerSdp" to sdp,
                    "answerType" to "answer",
                    "status" to "connected",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun endCallRoom(roomId: String) {
        val uid = auth.currentUser?.uid ?: return
        val docRef = db.collection("call_rooms").document(roomId)
        try {
            docRef.update(
                mapOf(
                    "status" to "ended",
                    "endedBy" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun sendIceCandidate(
        roomId: String,
        participants: List<String>,
        sdpMid: String,
        sdpMLineIndex: Int,
        candidate: String
    ) {
        val uid = auth.currentUser?.uid ?: return
        if (participants.size != 2 || candidate.isBlank()) return
        val candidateId = "ice_${UUID.randomUUID().toString().replace("-", "").take(18)}"
        val docRef = db.collection("call_rooms").document(roomId)
            .collection("ice_candidates").document(candidateId)
        try {
            docRef.set(
                mapOf(
                    "senderId" to uid,
                    "participants" to participants,
                    "sdpMid" to sdpMid.take(128),
                    "sdpMLineIndex" to sdpMLineIndex.coerceIn(0, 64),
                    "candidate" to candidate.take(2048),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
        }
    }

    fun observeIceCandidates(roomId: String, currentUserId: String): Flow<List<IceCandidateSignal>> = flow {
        val colRef = db.collection("call_rooms").document(roomId).collection("ice_candidates")
        val query = colRef.whereArrayContains("participants", currentUserId)
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(IceCandidateSignal::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { it.senderId != currentUserId }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == currentUserId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, colRef.path)
                    }
                    throw error
                }
        )
    }

    suspend fun deleteUserAccountData(userId: String) {
        val uid = requireUserId()
        require(uid == userId)
        try {
            db.collection("match_queue").document(uid).delete().await()
        } catch (_: Exception) { }
        try {
            db.collection("online_presence").document(uid).delete().await()
        } catch (_: Exception) { }
        try {
            val blocked = db.collection("users").document(uid).collection("blocked").get().await()
            for (doc in blocked.documents) {
                doc.reference.delete().await()
            }
        } catch (_: Exception) { }
        try {
            db.collection("users").document(uid).delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$uid")
            throw e
        }
    }
}
