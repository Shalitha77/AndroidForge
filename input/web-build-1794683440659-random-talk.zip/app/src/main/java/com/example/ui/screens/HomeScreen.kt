package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ads.HomeBannerAdSlot
import com.example.ads.HomeNativeAdCard
import com.example.data.model.GenderIdentity
import com.example.data.model.GenderPreference
import com.example.data.model.SupportedCountries
import com.example.data.model.UserProfile
import com.example.ui.components.CountryPickerSheet
import com.example.ui.components.GenderPickerSheet
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.OnlineCounterPill
import com.example.ui.components.RandomTalkBackground
import com.example.ui.theme.CoralPulse
import com.example.ui.theme.ElectricCyan
import com.example.ui.viewmodel.ProfileUiState

@Composable
fun HomeScreen(
    profileState: ProfileUiState,
    onlineCount: Int,
    onSelectPreferredCountry: (String) -> Unit,
    onSelectGenderPreferences: (GenderIdentity, GenderPreference) -> Unit,
    onConfirmSafety: () -> Unit,
    onStartVideoChat: (UserProfile) -> Unit,
    onOpenSettings: () -> Unit
) {
    var showCountrySheet by remember { mutableStateOf(false) }
    var showGenderSheet by remember { mutableStateOf(false) }
    var showSafetyGateDialog by remember { mutableStateOf(false) }

    RandomTalkBackground {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.img_launcher_icon),
                            contentDescription = "Random Talk emblem",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Encrypted P2P Video",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OnlineCounterPill(onlineCount = onlineCount)
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                        ) {
                            IconButton(
                                onClick = onOpenSettings,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Settings,
                                    contentDescription = "Open settings",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                when (profileState) {
                    is ProfileUiState.Loading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }

                    is ProfileUiState.Error -> {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = profileState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }

                    is ProfileUiState.Ready -> {
                        val profile = profileState.profile
                        val myCountry = SupportedCountries.byCode(profile.country)
                        val prefCountry = SupportedCountries.byCode(profile.preferredCountry)
                        val myGender = GenderIdentity.fromWire(profile.gender)
                        val prefGender = GenderPreference.fromWire(profile.preferredGender)
                        val genderSupported = myCountry.genderFilterSupported && prefCountry.genderFilterSupported

                        // Hero Banner Card
                        Surface(
                            shape = RoundedCornerShape(26.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.height(176.dp)) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_hero_global_chat),
                                    contentDescription = "Worldwide video network illustration",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(
                                                    Color.Black.copy(alpha = 0.15f),
                                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                                                )
                                            )
                                        )
                                )
                                Column(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(18.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f)
                                    ) {
                                        Text(
                                            text = "${myCountry.flagEmoji} ${profile.alias} • Private ID",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Meet someone new face-to-face",
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Tap Start to connect live with verified 18+ users worldwide.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Country & Gender Preference Cards
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            FilterSelectorCard(
                                title = "Country",
                                value = "${prefCountry.flagEmoji} ${prefCountry.name}",
                                iconTint = ElectricCyan,
                                icon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Public,
                                        contentDescription = "Country filter",
                                        tint = ElectricCyan
                                    )
                                },
                                onClick = { showCountrySheet = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("country_selector_card")
                            )

                            FilterSelectorCard(
                                title = "Match With",
                                value = if (genderSupported) prefGender.label else "Everyone",
                                iconTint = CoralPulse,
                                icon = {
                                    Icon(
                                        imageVector = Icons.Rounded.PersonSearch,
                                        contentDescription = "Gender filter",
                                        tint = CoralPulse
                                    )
                                },
                                onClick = { showGenderSheet = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("gender_selector_card")
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Primary CTA: Start Video Chat (generous clearance around ads)
                        GradientPrimaryButton(
                            text = stringResource(R.string.start_video_chat),
                            onClick = {
                                if (profile.ageConfirmed18Plus && profile.guidelinesAccepted) {
                                    onStartVideoChat(profile)
                                } else {
                                    showSafetyGateDialog = true
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Videocam,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("start_video_chat_button")
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Safety Notice Banner (acts as buffer before ad sections)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Security,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.safety_notice),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        // Policy-compliant Native Ad Card (separated from buttons)
                        HomeNativeAdCard()

                        Spacer(modifier = Modifier.height(16.dp))

                        // Policy-compliant Home Banner Ad Slot at bottom
                        HomeBannerAdSlot()

                        Spacer(modifier = Modifier.height(12.dp))

                        if (showCountrySheet) {
                            CountryPickerSheet(
                                title = "Choose Preferred Country",
                                selectedCode = profile.preferredCountry,
                                includeGlobal = true,
                                onSelect = { option -> onSelectPreferredCountry(option.code) },
                                onDismiss = { showCountrySheet = false }
                            )
                        }

                        if (showGenderSheet) {
                            GenderPickerSheet(
                                myGender = myGender,
                                preferredGender = prefGender,
                                genderFilterSupported = genderSupported,
                                onSave = { identity, preferred ->
                                    onSelectGenderPreferences(identity, preferred)
                                    showGenderSheet = false
                                },
                                onDismiss = { showGenderSheet = false }
                            )
                        }

                        if (showSafetyGateDialog) {
                            SafetyConfirmationDialog(
                                onConfirm = {
                                    onConfirmSafety()
                                    showSafetyGateDialog = false
                                    onStartVideoChat(
                                        profile.copy(
                                            ageConfirmed18Plus = true,
                                            guidelinesAccepted = true
                                        )
                                    )
                                },
                                onDismiss = { showSafetyGateDialog = false }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterSelectorCard(
    title: String,
    value: String,
    iconTint: Color,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = iconTint.copy(alpha = 0.14f),
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) { icon() }
                }
                Icon(
                    imageVector = Icons.Rounded.KeyboardArrowDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SafetyConfirmationDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    var ageChecked by remember { mutableStateOf(true) }
    var rulesChecked by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("18+ & Safety Confirmation") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Before joining live video chat, please confirm:",
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { ageChecked = !ageChecked }
                ) {
                    Checkbox(checked = ageChecked, onCheckedChange = { ageChecked = it })
                    Text("I am 18 years or older.", style = MaterialTheme.typography.bodyMedium)
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { rulesChecked = !rulesChecked }
                ) {
                    Checkbox(checked = rulesChecked, onCheckedChange = { rulesChecked = it })
                    Text(
                        "I agree to follow Community Guidelines (no nudity, harassment, or sharing PII).",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = ageChecked && rulesChecked
            ) {
                Text("Agree & Start")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
