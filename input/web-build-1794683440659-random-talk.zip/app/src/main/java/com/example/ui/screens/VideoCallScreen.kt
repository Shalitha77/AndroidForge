package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VideocamOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.CallConnectionState
import com.example.data.model.ReportReason
import com.example.data.model.SupportedCountries
import com.example.data.model.UserProfile
import com.example.ui.components.MatchingRadarPulse
import com.example.ui.components.RandomTalkBackground
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralPulse
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldOnline
import com.example.ui.viewmodel.VideoCallViewModel
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

@Composable
fun VideoCallScreen(
    viewModel: VideoCallViewModel,
    profile: UserProfile,
    blockedUserIds: Set<String>,
    onExitCall: (completedSession: Boolean) -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var hasPermissions by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val camGranted = results[Manifest.permission.CAMERA] == true
        val micGranted = results[Manifest.permission.RECORD_AUDIO] == true
        hasPermissions = camGranted && micGranted
    }

    var showReportDialog by remember { mutableStateOf(false) }
    var showBlockDialog by remember { mutableStateOf(false) }

    val handleExit = {
        val completed = uiState.hasCompletedSession
        viewModel.endCallCleanup()
        onExitCall(completed)
    }

    BackHandler { handleExit() }

    LaunchedEffect(Unit) {
        if (!hasPermissions) {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    LaunchedEffect(hasPermissions) {
        if (hasPermissions) {
            viewModel.ensureWebRtcStarted(context, profile.lowBandwidthMode)
            viewModel.startSearch(profile, blockedUserIds)
        }
    }

    if (!hasPermissions) {
        RandomTalkBackground {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Videocam,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = stringResource(R.string.permissions_title),
                            style = MaterialTheme.typography.headlineSmall,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.permissions_body),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = {
                                permissionLauncher.launch(
                                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("grant_permissions_button")
                        ) {
                            Text(stringResource(R.string.grant_permissions))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = handleExit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Go Back")
                        }
                    }
                }
            }
        }
        return
    }

    val eglContext = viewModel.getEglBaseContext()
    var localRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    var remoteRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            localRenderer?.release()
            remoteRenderer?.release()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050612))
    ) {
        // Full-bleed Remote Video Stream
        if (eglContext != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    SurfaceViewRenderer(ctx).apply {
                        init(eglContext, null)
                        setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                        setEnableHardwareScaler(true)
                        remoteRenderer = this
                        viewModel.attachRemoteRenderer(this)
                    }
                }
            )
        }

        // Searching / Connecting / Reconnecting Overlay (never blocks controls)
        if (uiState.connectionState != CallConnectionState.CONNECTED) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF08091E).copy(alpha = 0.88f),
                                Color(0xFF0E1233).copy(alpha = 0.92f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 32.dp)
                ) {
                    MatchingRadarPulse()
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = uiState.statusText,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = when (uiState.connectionState) {
                            CallConnectionState.PEER_ENDED -> "Tap Next to match with someone new, or End to return."
                            CallConnectionState.RECONNECTING -> "Trying automatic ICE reconnection…"
                            else -> "Zero personal info shared • Tap Next anytime"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.72f),
                        textAlign = TextAlign.Center
                    )
                    if (uiState.connectionState == CallConnectionState.PEER_ENDED) {
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { viewModel.nextUser() },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
                            modifier = Modifier.testTag("peer_ended_next_button")
                        ) {
                            Text("Find Next Partner", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Top Status & Safety Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Peer Badge & Connection Pill
            Surface(
                shape = RoundedCornerShape(50),
                color = Color.Black.copy(alpha = 0.58f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dotColor = when (uiState.connectionState) {
                        CallConnectionState.CONNECTED -> EmeraldOnline
                        CallConnectionState.RECONNECTING -> AmberWarning
                        CallConnectionState.ERROR, CallConnectionState.PEER_ENDED -> DangerRed
                        else -> ElectricCyan
                    }
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val badgeLabel = if (uiState.peerAlias.isNotBlank()) {
                        val flag = SupportedCountries.byCode(uiState.peerCountry).flagEmoji
                        "$flag ${uiState.peerAlias}"
                    } else {
                        "Matching…"
                    }
                    Text(
                        text = badgeLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White
                    )
                }
            }

            // Right Controls: Low-Bandwidth, Block, Report
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = CircleShape,
                    color = if (uiState.lowBandwidthMode) {
                        ElectricCyan.copy(alpha = 0.35f)
                    } else {
                        Color.Black.copy(alpha = 0.58f)
                    },
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f))
                ) {
                    IconButton(
                        onClick = { viewModel.toggleLowBandwidth() },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("low_bandwidth_toggle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = "Toggle low bandwidth optimization",
                            tint = if (uiState.lowBandwidthMode) ElectricCyan else Color.White
                        )
                    }
                }

                if (uiState.peerId != null) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.58f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f))
                    ) {
                        IconButton(
                            onClick = { showBlockDialog = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("block_user_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Block,
                                contentDescription = stringResource(R.string.block_user),
                                tint = Color.White
                            )
                        }
                    }

                    Surface(
                        shape = CircleShape,
                        color = DangerRed.copy(alpha = 0.72f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
                    ) {
                        IconButton(
                            onClick = { showReportDialog = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("report_user_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Flag,
                                contentDescription = stringResource(R.string.report_user),
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }

        // Local Self-View PiP Card (Bottom-Right above control dock)
        if (eglContext != null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = 16.dp, bottom = 104.dp)
                    .size(width = 110.dp, height = 158.dp),
                shape = RoundedCornerShape(20.dp),
                color = Color.Black,
                border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.35f)),
                shadowElevation = 8.dp
            ) {
                Box {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            SurfaceViewRenderer(ctx).apply {
                                init(eglContext, null)
                                setZOrderMediaOverlay(true)
                                setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                                setEnableHardwareScaler(true)
                                localRenderer = this
                                viewModel.attachLocalRenderer(this)
                            }
                        }
                    )
                    if (!uiState.isCameraEnabled) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF14162B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.VideocamOff,
                                contentDescription = "Camera off",
                                tint = Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }

        // Bottom Glassmorphic Video Controls Dock (NO ADS EVER OVER ACTIVE CALL)
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF10132C).copy(alpha = 0.84f),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CallControlCircle(
                    icon = Icons.Rounded.Cameraswitch,
                    contentDescription = "Switch front or back camera",
                    containerColor = Color.White.copy(alpha = 0.14f),
                    iconTint = Color.White,
                    onClick = { viewModel.switchCamera() },
                    testTag = "switch_camera_button"
                )

                CallControlCircle(
                    icon = if (uiState.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                    contentDescription = if (uiState.isMuted) "Unmute microphone" else "Mute microphone",
                    containerColor = if (uiState.isMuted) CoralPulse else Color.White.copy(alpha = 0.14f),
                    iconTint = Color.White,
                    onClick = { viewModel.toggleMute() },
                    testTag = "mute_mic_button"
                )

                CallControlCircle(
                    icon = if (uiState.isCameraEnabled) Icons.Rounded.Videocam else Icons.Rounded.VideocamOff,
                    contentDescription = if (uiState.isCameraEnabled) "Turn camera off" else "Turn camera on",
                    containerColor = if (!uiState.isCameraEnabled) CoralPulse else Color.White.copy(alpha = 0.14f),
                    iconTint = Color.White,
                    onClick = { viewModel.toggleCamera() },
                    testTag = "toggle_camera_button"
                )

                // Next User Action
                Surface(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable { viewModel.nextUser() }
                        .testTag("next_user_button"),
                    shape = RoundedCornerShape(24.dp),
                    color = ElectricCyan
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipNext,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.next_user),
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color.Black
                        )
                    }
                }

                CallControlCircle(
                    icon = Icons.Rounded.CallEnd,
                    contentDescription = stringResource(R.string.end_call),
                    containerColor = DangerRed,
                    iconTint = Color.White,
                    onClick = handleExit,
                    testTag = "end_call_button"
                )
            }
        }
    }

    if (showReportDialog) {
        ReportUserDialog(
            peerAlias = uiState.peerAlias.ifBlank { "this user" },
            onSubmit = { reason, details ->
                viewModel.reportAndNext(reason, details) {
                    showReportDialog = false
                }
            },
            onDismiss = { showReportDialog = false }
        )
    }

    if (showBlockDialog) {
        AlertDialog(
            onDismissRequest = { showBlockDialog = false },
            title = { Text("Block ${uiState.peerAlias.ifBlank { "User" }}?") },
            text = {
                Text("You will immediately skip to a new partner and never be matched with this user again.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBlockDialog = false
                        viewModel.blockAndNext()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                ) {
                    Text("Block & Next")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBlockDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun CallControlCircle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    containerColor: Color,
    iconTint: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = CircleShape,
        color = containerColor,
        modifier = Modifier.size(48.dp)
    ) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .fillMaxSize()
                .testTag(testTag)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = iconTint,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun ReportUserDialog(
    peerAlias: String,
    onSubmit: (ReportReason, String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedReason by remember { mutableStateOf(ReportReason.INAPPROPRIATE_CONTENT) }
    var details by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Report $peerAlias") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Reporting immediately disconnects, blocks this user, and sends a moderation log.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                ReportReason.entries.forEach { reason ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedReason = reason }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedReason == reason,
                            onClick = { selectedReason = reason }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(reason.title, style = MaterialTheme.typography.labelLarge)
                            Text(
                                reason.subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = details,
                    onValueChange = { if (it.length <= 300) details = it },
                    label = { Text("Optional notes") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(selectedReason, details) },
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
            ) {
                Text("Submit & Skip")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
