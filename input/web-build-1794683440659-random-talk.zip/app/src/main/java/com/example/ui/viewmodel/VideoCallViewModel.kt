package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.MatchAttemptResult
import com.example.data.firebase.MatchmakingRepository
import com.example.data.model.CallConnectionState
import com.example.data.model.ReportReason
import com.example.data.model.UserProfile
import com.example.webrtc.WebRtcClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.webrtc.PeerConnection
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer

data class VideoCallUiState(
    val connectionState: CallConnectionState = CallConnectionState.IDLE,
    val roomId: String? = null,
    val peerId: String? = null,
    val peerAlias: String = "",
    val peerCountry: String = "GLOBAL",
    val isMuted: Boolean = false,
    val isCameraEnabled: Boolean = true,
    val isFrontCamera: Boolean = true,
    val lowBandwidthMode: Boolean = false,
    val hasCompletedSession: Boolean = false,
    val statusText: String = "Preparing video session…",
    val errorMessage: String? = null
)

class VideoCallViewModel(
    private val repository: MatchmakingRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(VideoCallUiState())
    val uiState: StateFlow<VideoCallUiState> = _uiState.asStateFlow()

    private var webRtcClient: WebRtcClient? = null
    private var matchmakingJob: Job? = null
    private var queueObserverJob: Job? = null
    private var roomObserverJob: Job? = null
    private var iceObserverJob: Job? = null

    private var currentProfile: UserProfile? = null
    private var currentBlockedIds: Set<String> = emptySet()
    private val recentPeerIds = LinkedHashSet<String>()
    private val processedIceCandidateIds = HashSet<String>()

    private var activeParticipants: List<String> = emptyList()
    private var isCallerRole: Boolean = false
    private var remoteOfferApplied: Boolean = false
    private var remoteAnswerApplied: Boolean = false
    private var localRendererRef: SurfaceViewRenderer? = null
    private var remoteRendererRef: SurfaceViewRenderer? = null

    fun ensureWebRtcStarted(context: Context, lowBandwidth: Boolean): WebRtcClient {
        val existing = webRtcClient
        if (existing != null) return existing

        val client = WebRtcClient(
            context = context.applicationContext,
            onLocalIceCandidate = { candidate ->
                val roomId = _uiState.value.roomId ?: return@WebRtcClient
                val participants = activeParticipants
                if (participants.size == 2) {
                    viewModelScope.launch {
                        repository.sendIceCandidate(
                            roomId = roomId,
                            participants = participants,
                            sdpMid = candidate.sdpMid ?: "",
                            sdpMLineIndex = candidate.sdpMLineIndex,
                            candidate = candidate.sdp
                        )
                    }
                }
            },
            onRemoteVideoTrack = {
                _uiState.update {
                    it.copy(
                        connectionState = CallConnectionState.CONNECTED,
                        hasCompletedSession = true,
                        statusText = "Connected"
                    )
                }
            },
            onIceConnectionChange = { iceState ->
                handleIceConnectionChange(iceState)
            }
        )
        client.initialize(lowBandwidth)
        webRtcClient = client
        localRendererRef?.let { client.attachLocalRenderer(it) }
        remoteRendererRef?.let { client.attachRemoteRenderer(it) }
        _uiState.update { it.copy(lowBandwidthMode = lowBandwidth, isFrontCamera = client.isFrontCamera) }
        return client
    }

    fun getEglBaseContext() = webRtcClient?.eglBase?.eglBaseContext

    fun attachLocalRenderer(renderer: SurfaceViewRenderer) {
        localRendererRef = renderer
        webRtcClient?.attachLocalRenderer(renderer)
    }

    fun attachRemoteRenderer(renderer: SurfaceViewRenderer) {
        remoteRendererRef = renderer
        webRtcClient?.attachRemoteRenderer(renderer)
    }

    fun startSearch(profile: UserProfile, blockedIds: Set<String>) {
        currentProfile = profile
        currentBlockedIds = blockedIds
        stopRoomListeners()
        webRtcClient?.closePeerConnectionOnly()
        remoteOfferApplied = false
        remoteAnswerApplied = false
        processedIceCandidateIds.clear()
        activeParticipants = emptyList()

        _uiState.update {
            it.copy(
                connectionState = CallConnectionState.SEARCHING,
                roomId = null,
                peerId = null,
                peerAlias = "",
                peerCountry = "GLOBAL",
                errorMessage = null,
                statusText = "Searching for a random partner worldwide…"
            )
        }

        queueObserverJob?.cancel()
        queueObserverJob = viewModelScope.launch {
            repository.observeMyQueueEntry(currentUserId)
                .catch { /* handled in search loop */ }
                .collect { entry ->
                    if (entry != null && entry.status == "matched" && !entry.roomId.isNullOrBlank()) {
                        val targetRoomId = entry.roomId
                        if (_uiState.value.roomId == null) {
                            joinRoomAsCallee(targetRoomId)
                        }
                    }
                }
        }

        matchmakingJob?.cancel()
        matchmakingJob = viewModelScope.launch {
            while (isActive && _uiState.value.connectionState == CallConnectionState.SEARCHING) {
                try {
                    val result = repository.enterQueueAndFindMatch(
                        profile = profile,
                        blockedIds = currentBlockedIds,
                        recentPeerIds = recentPeerIds
                    )
                    when (result) {
                        is MatchAttemptResult.Matched -> {
                            onMatchedAsCaller(result)
                            break
                        }
                        is MatchAttemptResult.WaitingInQueue -> {
                            // Keep waiting & refresh heartbeat
                            for (tick in 0 until 4) {
                                if (!isActive || _uiState.value.connectionState != CallConnectionState.SEARCHING) break
                                delay(1000L)
                            }
                            repository.refreshQueueHeartbeat(currentUserId)
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Matchmaking retry after error: ${e.message}")
                    delay(2500L)
                }
            }
        }
    }

    private suspend fun onMatchedAsCaller(match: MatchAttemptResult.Matched) {
        queueObserverJob?.cancel()
        matchmakingJob?.cancel()
        isCallerRole = true
        rememberRecentPeer(match.peerId)
        activeParticipants = listOf(currentUserId, match.peerId)

        _uiState.update {
            it.copy(
                connectionState = CallConnectionState.MATCHED_CONNECTING,
                roomId = match.roomId,
                peerId = match.peerId,
                peerAlias = match.peerAlias,
                peerCountry = match.peerCountry,
                statusText = "Matched with ${match.peerAlias} • Connecting…"
            )
        }

        val client = webRtcClient ?: return
        client.createPeerConnection()
        observeRoomAndIce(match.roomId)

        try {
            val offer = client.createOffer()
            client.setLocalDescription(offer)
            repository.writeOffer(match.roomId, offer.description)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Caller offer failed", e)
            _uiState.update {
                it.copy(
                    connectionState = CallConnectionState.ERROR,
                    errorMessage = "Could not start video call: ${e.localizedMessage}"
                )
            }
        }
    }

    private suspend fun joinRoomAsCallee(roomId: String) {
        matchmakingJob?.cancel()
        queueObserverJob?.cancel()
        val room = repository.getCallRoom(roomId) ?: return
        isCallerRole = false
        val peerId = if (room.callerId == currentUserId) room.calleeId else room.callerId
        val peerAlias = if (room.callerId == currentUserId) room.calleeAlias else room.callerAlias
        val peerCountry = if (room.callerId == currentUserId) room.calleeCountry else room.callerCountry
        rememberRecentPeer(peerId)
        activeParticipants = room.participants

        _uiState.update {
            it.copy(
                connectionState = CallConnectionState.MATCHED_CONNECTING,
                roomId = roomId,
                peerId = peerId,
                peerAlias = peerAlias,
                peerCountry = peerCountry,
                statusText = "Matched with $peerAlias • Connecting…"
            )
        }

        val client = webRtcClient ?: return
        client.createPeerConnection()
        observeRoomAndIce(roomId)
    }

    private fun observeRoomAndIce(roomId: String) {
        roomObserverJob?.cancel()
        roomObserverJob = viewModelScope.launch {
            repository.observeCallRoom(roomId)
                .catch { error ->
                    Log.w(TAG, "Room observer error: ${error.message}")
                }
                .collect { room ->
                    if (room == null) return@collect
                    if (room.status == "ended" && room.endedBy != currentUserId) {
                        handlePeerEnded()
                        return@collect
                    }

                    val client = webRtcClient ?: return@collect
                    if (!isCallerRole && !remoteOfferApplied && !room.offerSdp.isNullOrBlank()) {
                        remoteOfferApplied = true
                        try {
                            client.setRemoteDescription(
                                SessionDescription(SessionDescription.Type.OFFER, room.offerSdp)
                            )
                            val answer = client.createAnswer()
                            client.setLocalDescription(answer)
                            repository.writeAnswer(roomId, answer.description)
                        } catch (e: Exception) {
                            Log.e(TAG, "Callee answer error", e)
                        }
                    }

                    if (isCallerRole && !remoteAnswerApplied && !room.answerSdp.isNullOrBlank()) {
                        remoteAnswerApplied = true
                        try {
                            client.setRemoteDescription(
                                SessionDescription(SessionDescription.Type.ANSWER, room.answerSdp)
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Caller setRemoteDescription error", e)
                        }
                    }
                }
        }

        iceObserverJob?.cancel()
        iceObserverJob = viewModelScope.launch {
            repository.observeIceCandidates(roomId, currentUserId)
                .catch { error ->
                    Log.w(TAG, "ICE observer error: ${error.message}")
                }
                .collect { candidates ->
                    val client = webRtcClient ?: return@collect
                    for (item in candidates) {
                        if (processedIceCandidateIds.add(item.id)) {
                            client.addRemoteIceCandidate(
                                sdpMid = item.sdpMid,
                                sdpMLineIndex = item.sdpMLineIndex.toInt(),
                                sdp = item.candidate
                            )
                        }
                    }
                }
        }
    }

    private fun handleIceConnectionChange(state: PeerConnection.IceConnectionState) {
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED,
            PeerConnection.IceConnectionState.COMPLETED -> {
                _uiState.update {
                    it.copy(
                        connectionState = CallConnectionState.CONNECTED,
                        hasCompletedSession = true,
                        statusText = "Connected"
                    )
                }
            }
            PeerConnection.IceConnectionState.DISCONNECTED -> {
                _uiState.update {
                    it.copy(
                        connectionState = CallConnectionState.RECONNECTING,
                        statusText = "Connection unstable • Reconnecting…"
                    )
                }
                webRtcClient?.restartIce()
            }
            PeerConnection.IceConnectionState.FAILED -> {
                _uiState.update {
                    it.copy(
                        connectionState = CallConnectionState.RECONNECTING,
                        statusText = "Attempting ICE reconnect…"
                    )
                }
                webRtcClient?.restartIce()
            }
            PeerConnection.IceConnectionState.CLOSED -> {
                if (_uiState.value.connectionState == CallConnectionState.CONNECTED) {
                    handlePeerEnded()
                }
            }
            else -> {}
        }
    }

    private fun handlePeerEnded() {
        stopRoomListeners()
        webRtcClient?.closePeerConnectionOnly()
        _uiState.update {
            it.copy(
                connectionState = CallConnectionState.PEER_ENDED,
                statusText = "Partner disconnected"
            )
        }
    }

    fun nextUser() {
        val roomId = _uiState.value.roomId
        val profile = currentProfile ?: return
        viewModelScope.launch {
            if (!roomId.isNullOrBlank()) {
                repository.endCallRoom(roomId)
            }
            repository.leaveQueue(currentUserId)
            startSearch(profile, currentBlockedIds)
        }
    }

    fun toggleMute() {
        val next = !_uiState.value.isMuted
        webRtcClient?.setMicMuted(next)
        _uiState.update { it.copy(isMuted = next) }
    }

    fun toggleCamera() {
        val next = !_uiState.value.isCameraEnabled
        webRtcClient?.setCameraEnabled(next)
        _uiState.update { it.copy(isCameraEnabled = next) }
    }

    fun switchCamera() {
        webRtcClient?.switchCamera { isFront ->
            _uiState.update { it.copy(isFrontCamera = isFront) }
        }
    }

    fun toggleLowBandwidth() {
        val next = !_uiState.value.lowBandwidthMode
        webRtcClient?.setLowBandwidthMode(next)
        _uiState.update { it.copy(lowBandwidthMode = next) }
    }

    fun reportAndNext(reason: ReportReason, details: String, onSubmitted: () -> Unit) {
        val peerId = _uiState.value.peerId ?: return
        val roomId = _uiState.value.roomId ?: ""
        viewModelScope.launch {
            runCatching {
                repository.submitReport(
                    reportedUserId = peerId,
                    roomId = roomId,
                    reason = reason,
                    details = details
                )
                currentBlockedIds = currentBlockedIds + peerId
            }
            onSubmitted()
            nextUser()
        }
    }

    fun blockAndNext() {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            runCatching {
                repository.blockUser(peerId, "Blocked during random chat")
                currentBlockedIds = currentBlockedIds + peerId
            }
            nextUser()
        }
    }

    fun endCallCleanup() {
        val roomId = _uiState.value.roomId
        stopRoomListeners()
        webRtcClient?.dispose()
        webRtcClient = null
        CoroutineScope(Dispatchers.IO).launch {
            if (!roomId.isNullOrBlank()) {
                runCatching { repository.endCallRoom(roomId) }
            }
            runCatching { repository.leaveQueue(currentUserId) }
        }
    }

    private fun rememberRecentPeer(peerId: String) {
        if (recentPeerIds.size >= 5) {
            val first = recentPeerIds.firstOrNull()
            if (first != null) recentPeerIds.remove(first)
        }
        recentPeerIds.add(peerId)
    }

    private fun stopRoomListeners() {
        matchmakingJob?.cancel()
        queueObserverJob?.cancel()
        roomObserverJob?.cancel()
        iceObserverJob?.cancel()
    }

    override fun onCleared() {
        super.onCleared()
        endCallCleanup()
    }

    private companion object {
        const val TAG = "VideoCallVM"
    }
}
