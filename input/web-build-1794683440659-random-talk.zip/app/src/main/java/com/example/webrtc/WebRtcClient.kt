package com.example.webrtc

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.suspendCancellableCoroutine
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoCapturer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.audio.JavaAudioDeviceModule
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class WebRtcClient(
    private val context: Context,
    private val onLocalIceCandidate: (IceCandidate) -> Unit,
    private val onRemoteVideoTrack: (VideoTrack) -> Unit,
    private val onIceConnectionChange: (PeerConnection.IceConnectionState) -> Unit,
    private val onRenegotiationNeeded: () -> Unit = {}
) {
    val eglBase: EglBase = EglBase.create()

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: VideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var localAudioTrack: AudioTrack? = null
    private var localRenderer: SurfaceViewRenderer? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var remoteVideoTrack: VideoTrack? = null

    var isFrontCamera: Boolean = true
        private set
    private var lowBandwidthMode: Boolean = false
    private var isDisposed: Boolean = false

    fun initialize(lowBandwidth: Boolean) {
        if (isDisposed || peerConnectionFactory != null) return
        this.lowBandwidthMode = lowBandwidth

        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )

        val audioDeviceModule = JavaAudioDeviceModule.builder(context.applicationContext)
            .setUseHardwareAcousticEchoCanceler(true)
            .setUseHardwareNoiseSuppressor(true)
            .createAudioDeviceModule()

        val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)

        peerConnectionFactory = PeerConnectionFactory.builder()
            .setAudioDeviceModule(audioDeviceModule)
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        audioDeviceModule.release()
        startLocalMedia()
    }

    private fun startLocalMedia() {
        val factory = peerConnectionFactory ?: return

        val audioConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
        }
        audioSource = factory.createAudioSource(audioConstraints)
        localAudioTrack = factory.createAudioTrack("RT_AUDIO_0", audioSource)
        localAudioTrack?.setEnabled(true)

        videoCapturer = createCameraCapturer(preferFront = true)
        if (videoCapturer != null) {
            surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.eglBaseContext)
            videoSource = factory.createVideoSource(videoCapturer!!.isScreencast)
            videoCapturer!!.initialize(surfaceTextureHelper, context.applicationContext, videoSource!!.capturerObserver)
            val (w, h, fps) = captureProfile(lowBandwidthMode)
            try {
                videoCapturer!!.startCapture(w, h, fps)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start camera capture", e)
            }
            localVideoTrack = factory.createVideoTrack("RT_VIDEO_0", videoSource)
            localVideoTrack?.setEnabled(true)
            localRenderer?.let { renderer ->
                localVideoTrack?.addSink(renderer)
            }
        }
    }

    private fun createCameraCapturer(preferFront: Boolean): VideoCapturer? {
        val enumerator = Camera2Enumerator(context.applicationContext)
        val deviceNames = enumerator.deviceNames
        val preferred = deviceNames.firstOrNull { name ->
            if (preferFront) enumerator.isFrontFacing(name) else enumerator.isBackFacing(name)
        } ?: deviceNames.firstOrNull()
        if (preferred != null) {
            isFrontCamera = enumerator.isFrontFacing(preferred)
            return enumerator.createCapturer(preferred, null)
        }
        return null
    }

    fun attachLocalRenderer(renderer: SurfaceViewRenderer) {
        if (localRenderer === renderer) return
        localRenderer?.let { prev -> localVideoTrack?.removeSink(prev) }
        localRenderer = renderer
        renderer.setMirror(isFrontCamera)
        localVideoTrack?.addSink(renderer)
    }

    fun attachRemoteRenderer(renderer: SurfaceViewRenderer) {
        if (remoteRenderer === renderer) return
        remoteRenderer?.let { prev -> remoteVideoTrack?.removeSink(prev) }
        remoteRenderer = renderer
        remoteVideoTrack?.addSink(renderer)
    }

    fun createPeerConnection() {
        closePeerConnectionOnly()
        val factory = peerConnectionFactory ?: return

        val iceServers = buildList {
            add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer())
            add(PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer())
            val turnUrl = BuildConfig.TURN_SERVER_URL.trim()
            if (turnUrl.isNotEmpty() &&
                turnUrl != "UNCONFIGURED" &&
                (turnUrl.startsWith("turn:") || turnUrl.startsWith("turns:"))
            ) {
                val builder = PeerConnection.IceServer.builder(turnUrl)
                val user = BuildConfig.TURN_SERVER_USERNAME.trim()
                val cred = BuildConfig.TURN_SERVER_CREDENTIAL.trim()
                if (user.isNotEmpty() && user != "UNCONFIGURED") {
                    builder.setUsername(user)
                }
                if (cred.isNotEmpty() && cred != "UNCONFIGURED") {
                    builder.setPassword(cred)
                }
                add(builder.createIceServer())
            }
        }

        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            iceCandidatePoolSize = 4
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
        }

        peerConnection = factory.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState?) {}

                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    state?.let { onIceConnectionChange(it) }
                }

                override fun onIceConnectionReceivingChange(receiving: Boolean) {}

                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}

                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate?.let { onLocalIceCandidate(it) }
                }

                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}

                override fun onAddStream(stream: MediaStream?) {}

                override fun onRemoveStream(stream: MediaStream?) {}

                override fun onDataChannel(channel: DataChannel?) {}

                override fun onRenegotiationNeeded() {
                    onRenegotiationNeeded()
                }

                override fun onTrack(transceiver: RtpTransceiver?) {
                    val track = transceiver?.receiver?.track()
                    if (track is VideoTrack) {
                        remoteVideoTrack = track
                        track.setEnabled(true)
                        remoteRenderer?.let { renderer ->
                            track.addSink(renderer)
                        }
                        onRemoteVideoTrack(track)
                    }
                }
            }
        )

        val streamIds = listOf("RT_STREAM")
        localVideoTrack?.let { peerConnection?.addTrack(it, streamIds) }
        localAudioTrack?.let { peerConnection?.addTrack(it, streamIds) }
        applyBitrateConstraint(lowBandwidthMode)
    }

    suspend fun createOffer(): SessionDescription {
        val pc = peerConnection ?: throw IllegalStateException("PeerConnection not initialized")
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
        }
        return suspendCancellableCoroutine { cont ->
            pc.createOffer(
                object : SimpleSdpObserver() {
                    override fun onCreateSuccess(sdp: SessionDescription?) {
                        if (sdp != null) cont.resume(sdp)
                        else cont.resumeWithException(IllegalStateException("Null offer SDP"))
                    }

                    override fun onCreateFailure(error: String?) {
                        cont.resumeWithException(IllegalStateException(error ?: "Offer creation failed"))
                    }
                },
                constraints
            )
        }
    }

    suspend fun createAnswer(): SessionDescription {
        val pc = peerConnection ?: throw IllegalStateException("PeerConnection not initialized")
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
        }
        return suspendCancellableCoroutine { cont ->
            pc.createAnswer(
                object : SimpleSdpObserver() {
                    override fun onCreateSuccess(sdp: SessionDescription?) {
                        if (sdp != null) cont.resume(sdp)
                        else cont.resumeWithException(IllegalStateException("Null answer SDP"))
                    }

                    override fun onCreateFailure(error: String?) {
                        cont.resumeWithException(IllegalStateException(error ?: "Answer creation failed"))
                    }
                },
                constraints
            )
        }
    }

    suspend fun setLocalDescription(sdp: SessionDescription) {
        val pc = peerConnection ?: return
        suspendCancellableCoroutine<Unit> { cont ->
            pc.setLocalDescription(
                object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        cont.resume(Unit)
                    }

                    override fun onSetFailure(error: String?) {
                        cont.resumeWithException(IllegalStateException(error ?: "setLocalDescription failed"))
                    }
                },
                sdp
            )
        }
    }

    suspend fun setRemoteDescription(sdp: SessionDescription) {
        val pc = peerConnection ?: return
        suspendCancellableCoroutine<Unit> { cont ->
            pc.setRemoteDescription(
                object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        cont.resume(Unit)
                    }

                    override fun onSetFailure(error: String?) {
                        cont.resumeWithException(IllegalStateException(error ?: "setRemoteDescription failed"))
                    }
                },
                sdp
            )
        }
    }

    fun addRemoteIceCandidate(sdpMid: String, sdpMLineIndex: Int, sdp: String) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, sdp))
    }

    fun restartIce() {
        peerConnection?.restartIce()
    }

    fun setMicMuted(muted: Boolean) {
        localAudioTrack?.setEnabled(!muted)
    }

    fun setCameraEnabled(enabled: Boolean) {
        localVideoTrack?.setEnabled(enabled)
    }

    fun switchCamera(onSwitched: (Boolean) -> Unit = {}) {
        val cam = videoCapturer as? CameraVideoCapturer ?: return
        cam.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
            override fun onCameraSwitchDone(isFront: Boolean) {
                isFrontCamera = isFront
                localRenderer?.setMirror(isFront)
                onSwitched(isFront)
            }

            override fun onCameraSwitchError(error: String?) {
                Log.w(TAG, "Camera switch error: $error")
            }
        })
    }

    fun setLowBandwidthMode(enabled: Boolean) {
        lowBandwidthMode = enabled
        val (w, h, fps) = captureProfile(enabled)
        try {
            videoCapturer?.changeCaptureFormat(w, h, fps)
        } catch (e: Exception) {
            Log.w(TAG, "Unable to change capture format: ${e.message}")
        }
        applyBitrateConstraint(enabled)
    }

    private fun applyBitrateConstraint(lowBandwidth: Boolean) {
        val pc = peerConnection ?: return
        val maxBitrateBps = if (lowBandwidth) 350_000 else 1_500_000
        pc.senders.firstOrNull { it.track()?.kind() == "video" }?.let { sender ->
            val params = sender.parameters
            for (encoding in params.encodings) {
                encoding.maxBitrateBps = maxBitrateBps
                encoding.maxFramerate = if (lowBandwidth) 15 else 30
            }
            sender.parameters = params
        }
    }

    private fun captureProfile(lowBandwidth: Boolean): Triple<Int, Int, Int> =
        if (lowBandwidth) Triple(480, 360, 15) else Triple(1280, 720, 30)

    fun closePeerConnectionOnly() {
        remoteRenderer?.let { renderer -> remoteVideoTrack?.removeSink(renderer) }
        remoteVideoTrack = null
        peerConnection?.close()
        peerConnection?.dispose()
        peerConnection = null
    }

    fun dispose() {
        if (isDisposed) return
        isDisposed = true
        closePeerConnectionOnly()
        localRenderer?.let { renderer -> localVideoTrack?.removeSink(renderer) }
        localRenderer = null
        remoteRenderer = null
        try {
            videoCapturer?.stopCapture()
        } catch (_: Exception) { }
        videoCapturer?.dispose()
        videoCapturer = null
        surfaceTextureHelper?.dispose()
        surfaceTextureHelper = null
        localVideoTrack?.dispose()
        localVideoTrack = null
        localAudioTrack?.dispose()
        localAudioTrack = null
        videoSource?.dispose()
        videoSource = null
        audioSource?.dispose()
        audioSource = null
        peerConnectionFactory?.dispose()
        peerConnectionFactory = null
        eglBase.release()
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(sdp: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }

    private companion object {
        const val TAG = "WebRtcClient"
    }
}
