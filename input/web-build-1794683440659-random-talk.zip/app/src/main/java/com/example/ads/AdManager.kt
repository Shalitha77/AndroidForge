package com.example.ads

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

object AdConsentHelper {
    private const val TAG = "AdConsentHelper"

    fun requestConsent(activity: Activity, onComplete: () -> Unit = {}) {
        val params = ConsentRequestParameters.Builder().build()
        val consentInfo = UserMessagingPlatform.getConsentInformation(activity)
        consentInfo.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        Log.w(TAG, "Consent form notice: ${formError.message}")
                    }
                    onComplete()
                }
            },
            { requestError ->
                Log.w(TAG, "Consent info update error: ${requestError.message}")
                onComplete()
            }
        )
    }

    fun isPrivacyOptionsRequired(context: Context): Boolean {
        val consentInfo = UserMessagingPlatform.getConsentInformation(context)
        return consentInfo.privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
    }

    fun showPrivacyOptions(activity: Activity, onDismissed: () -> Unit = {}) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
            if (error != null) {
                Log.w(TAG, "Privacy options error: ${error.message}")
            }
            onDismissed()
        }
    }
}

class InterstitialAdController(private val context: Context) {
    private var interstitialAd: InterstitialAd? = null
    private var isLoading: Boolean = false
    private var lastShownMs: Long = 0L

    fun preload() {
        if (interstitialAd != null || isLoading) return
        isLoading = true
        InterstitialAd.load(
            context.applicationContext,
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isLoading = false
                    Log.d("AdManager", "Interstitial preload skipped: ${error.message}")
                }
            }
        )
    }

    /**
     * Policy-safe: ONLY invoked after a video chat session has fully ended and the
     * VideoCallScreen is closed. Never shown over an active video call.
     */
    fun showAfterCompletedSession(activity: Activity, onFinished: () -> Unit = {}) {
        val now = System.currentTimeMillis()
        // Frequency cap (45 seconds) so users aren't spammed on short retries
        if (now - lastShownMs < 45_000L) {
            onFinished()
            return
        }
        val ad = interstitialAd
        if (ad == null) {
            preload()
            onFinished()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                lastShownMs = System.currentTimeMillis()
                preload()
                onFinished()
            }

            override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                interstitialAd = null
                preload()
                onFinished()
            }
        }
        ad.show(activity)
    }
}

@Composable
fun HomeBannerAdSlot(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var adLoaded by remember { mutableStateOf(false) }

    val adView = remember(context) {
        AdView(context).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = BuildConfig.ADMOB_BANNER_ID
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    adLoaded = true
                }
            }
            loadAd(AdRequest.Builder().build())
        }
    }

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (adLoaded) "Sponsored" else "Advertisement",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            AndroidView(
                factory = { adView },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun HomeNativeAdCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var loadedNativeAd by remember { mutableStateOf<NativeAd?>(null) }

    val primaryColor = MaterialTheme.colorScheme.primary.toArgb()
    val onPrimaryColor = MaterialTheme.colorScheme.onPrimary.toArgb()
    val textPrimary = MaterialTheme.colorScheme.onSurface.toArgb()
    val textSecondary = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()

    DisposableEffect(context) {
        val adLoader = AdLoader.Builder(context, BuildConfig.ADMOB_NATIVE_ID)
            .forNativeAd { nativeAd ->
                loadedNativeAd?.destroy()
                loadedNativeAd = nativeAd
            }
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()
        adLoader.loadAd(AdRequest.Builder().build())

        onDispose {
            loadedNativeAd?.destroy()
            loadedNativeAd = null
        }
    }

    val nativeAd = loadedNativeAd ?: return

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            factory = { ctx ->
                NativeAdView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    val root = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                    }

                    val headerRow = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }

                    val iconView = ImageView(ctx).apply {
                        id = View.generateViewId()
                        val sizePx = dpToPx(ctx, 42)
                        layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                            marginEnd = dpToPx(ctx, 12)
                        }
                        scaleType = ImageView.ScaleType.CENTER_CROP
                    }

                    val titleCol = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }

                    val badge = TextView(ctx).apply {
                        text = "AD"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                        setTypeface(null, Typeface.BOLD)
                        setTextColor(onPrimaryColor)
                        setPadding(dpToPx(ctx, 6), dpToPx(ctx, 2), dpToPx(ctx, 6), dpToPx(ctx, 2))
                        background = GradientDrawable().apply {
                            setColor(primaryColor)
                            cornerRadius = dpToPx(ctx, 6).toFloat()
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = dpToPx(ctx, 4) }
                    }

                    val headlineView = TextView(ctx).apply {
                        id = View.generateViewId()
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                        setTypeface(null, Typeface.BOLD)
                        setTextColor(textPrimary)
                        maxLines = 1
                    }

                    val bodyView = TextView(ctx).apply {
                        id = View.generateViewId()
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                        setTextColor(textSecondary)
                        maxLines = 2
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = dpToPx(ctx, 6) }
                    }

                    val ctaButton = Button(ctx).apply {
                        id = View.generateViewId()
                        setTextColor(onPrimaryColor)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                        isAllCaps = false
                        background = GradientDrawable().apply {
                            setColor(primaryColor)
                            cornerRadius = dpToPx(ctx, 12).toFloat()
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            dpToPx(ctx, 44)
                        ).apply { topMargin = dpToPx(ctx, 10) }
                    }

                    titleCol.addView(badge)
                    titleCol.addView(headlineView)
                    headerRow.addView(iconView)
                    headerRow.addView(titleCol)
                    root.addView(headerRow)
                    root.addView(bodyView)
                    root.addView(ctaButton)
                    addView(root)

                    this.iconView = iconView
                    this.headlineView = headlineView
                    this.bodyView = bodyView
                    this.callToActionView = ctaButton
                }
            },
            update = { adView ->
                (adView.headlineView as? TextView)?.text = nativeAd.headline
                val body = nativeAd.body
                (adView.bodyView as? TextView)?.apply {
                    text = body ?: ""
                    visibility = if (body.isNullOrBlank()) View.GONE else View.VISIBLE
                }
                val icon = nativeAd.icon?.drawable
                (adView.iconView as? ImageView)?.apply {
                    setImageDrawable(icon)
                    visibility = if (icon == null) View.GONE else View.VISIBLE
                }
                val cta = nativeAd.callToAction
                (adView.callToActionView as? Button)?.apply {
                    text = cta ?: "Learn More"
                    visibility = if (cta.isNullOrBlank()) View.GONE else View.VISIBLE
                }
                adView.setNativeAd(nativeAd)
            }
        )
    }
}

private fun dpToPx(context: Context, dp: Int): Int =
    TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        dp.toFloat(),
        context.resources.displayMetrics
    ).toInt()
