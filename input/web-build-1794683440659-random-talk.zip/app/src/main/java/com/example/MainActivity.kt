package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ads.AdConsentHelper
import com.example.ads.InterstitialAdController
import com.example.data.firebase.AuthManager
import com.example.data.firebase.MatchmakingRepository
import com.example.data.firebase.UserPreferencesRepository
import com.example.data.model.ThemeMode
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VideoCallScreen
import com.example.ui.theme.RandomTalkTheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ProfileUiState
import com.example.ui.viewmodel.VideoCallViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.serialization.Serializable

@Serializable
data object HomeRoute

@Serializable
data object VideoCallRoute

@Serializable
data object SettingsRoute

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        AdConsentHelper.requestConsent(this)

        setContent {
            val prefsRepo = remember { UserPreferencesRepository(applicationContext) }
            val localTheme by prefsRepo.themeModeFlow.collectAsStateWithLifecycle(initialValue = ThemeMode.DARK)

            RandomTalkTheme(themeMode = localTheme) {
                AppRootNavigation(prefsRepo = prefsRepo)
            }
        }
    }
}

@Composable
private fun AppRootNavigation(prefsRepo: UserPreferencesRepository) {
    val context = LocalContext.current
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val currentUser by AuthManager.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null) {
            AuthManager.attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                scope = this,
                onAuthSuccess = {},
                onUnauthenticated = {}
            )
        }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        val uid = user.uid
        key(uid) {
            AuthenticatedFlow(
                currentUserId = uid,
                prefsRepo = prefsRepo
            )
        }
    }
}

@Composable
private fun AuthenticatedFlow(
    currentUserId: String,
    prefsRepo: UserPreferencesRepository
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val navController = rememberNavController()

    val mainViewModel: MainViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                MainViewModel(
                    repository = MatchmakingRepository(db),
                    prefsRepository = prefsRepo,
                    currentUserId = currentUserId
                )
            }
        }
    )

    val profileState by mainViewModel.profileState.collectAsStateWithLifecycle()
    val onlineCount by mainViewModel.onlineCount.collectAsStateWithLifecycle()
    val blockedUsers by mainViewModel.blockedUsers.collectAsStateWithLifecycle()
    val localThemeMode by mainViewModel.localThemeMode.collectAsStateWithLifecycle()

    val interstitialController = remember(context) {
        InterstitialAdController(context).apply { preload() }
    }

    val activeProfile = (profileState as? ProfileUiState.Ready)?.profile
    val effectiveTheme = activeProfile?.let { ThemeMode.fromWire(it.themeMode) } ?: localThemeMode

    RandomTalkTheme(themeMode = effectiveTheme) {
        NavHost(
            navController = navController,
            startDestination = HomeRoute
        ) {
            composable<HomeRoute> {
                HomeScreen(
                    profileState = profileState,
                    onlineCount = onlineCount,
                    onSelectPreferredCountry = { mainViewModel.updatePreferredCountry(it) },
                    onSelectGenderPreferences = { id, pref -> mainViewModel.updateGenderPreferences(id, pref) },
                    onConfirmSafety = { mainViewModel.confirm18PlusAndGuidelines() },
                    onStartVideoChat = {
                        navController.navigate(VideoCallRoute)
                    },
                    onOpenSettings = {
                        navController.navigate(SettingsRoute)
                    }
                )
            }

            composable<VideoCallRoute> {
                val callViewModel: VideoCallViewModel = viewModel(
                    key = "call_$currentUserId",
                    factory = viewModelFactory {
                        initializer {
                            val app = checkNotNull(this[APPLICATION_KEY])
                            val databaseId = app.getString(R.string.firestore_database_id)
                            val db = FirebaseFirestore.getInstance(databaseId)
                            VideoCallViewModel(
                                repository = MatchmakingRepository(db),
                                currentUserId = currentUserId
                            )
                        }
                    }
                )

                val profileForCall = activeProfile
                if (profileForCall != null) {
                    VideoCallScreen(
                        viewModel = callViewModel,
                        profile = profileForCall,
                        blockedUserIds = blockedUsers.map { it.blockedUserId }.toSet(),
                        onExitCall = { completedSession ->
                            navController.popBackStack()
                            if (completedSession && activity != null) {
                                interstitialController.showAfterCompletedSession(activity)
                            }
                        }
                    )
                }
            }

            composable<SettingsRoute> {
                SettingsScreen(
                    profile = activeProfile,
                    themeMode = effectiveTheme,
                    blockedUsers = blockedUsers,
                    onBack = { navController.popBackStack() },
                    onThemeModeChange = { mainViewModel.setThemeMode(it) },
                    onLowBandwidthChange = { mainViewModel.setLowBandwidthMode(it) },
                    onAliasChange = { mainViewModel.updateAlias(it) },
                    onMyCountryChange = { mainViewModel.updateMyCountry(it) },
                    onUnblockUser = { mainViewModel.unblockUser(it) },
                    onDeleteAccount = { onDone, onErr ->
                        mainViewModel.deleteAccount(onDone, onErr)
                    }
                )
            }
        }
    }
}
