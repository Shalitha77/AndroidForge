package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nocturnal / Electric Cyber-Glass Palette (Dark Primary)
val MidnightBg = Color(0xFF07081D)
val DeepIndigoSurface = Color(0xFF10122B)
val ElevatedCardDark = Color(0xFF181B3A)
val OutlineDark = Color(0xFF2B2F59)

val ElectricCyan = Color(0xFF00E5FF)
val CyanMuted = Color(0xFF0097B2)
val CoralPulse = Color(0xFFFF4D8D)
val VioletAccent = Color(0xFF7C4DFF)
val EmeraldOnline = Color(0xFF00E676)
val AmberWarning = Color(0xFFFFB300)
val DangerRed = Color(0xFFFF5252)

val TextPrimaryDark = Color(0xFFF3F6FF)
val TextSecondaryDark = Color(0xFFA6AED0)

// Crisp Daylight Palette (Light Primary)
val DaylightBg = Color(0xFFF4F6FC)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightCardVariant = Color(0xFFEAEFF9)
val OutlineLight = Color(0xFFD0D8EC)

val DeepCyanLight = Color(0xFF007C91)
val DeepCoralLight = Color(0xFFD81B60)
val DeepVioletLight = Color(0xFF5E35B1)

val TextPrimaryLight = Color(0xFF0E122B)
val TextSecondaryLight = Color(0xFF525A7A)
