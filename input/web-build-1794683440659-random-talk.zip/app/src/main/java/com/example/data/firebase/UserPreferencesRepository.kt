package com.example.data.firebase

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "random_talk_prefs")

class UserPreferencesRepository(private val context: Context) {
    private val themeModeKey = stringPreferencesKey("theme_mode")
    private val lowBandwidthKey = booleanPreferencesKey("low_bandwidth_mode")

    val themeModeFlow: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        ThemeMode.fromWire(prefs[themeModeKey])
    }

    val lowBandwidthFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[lowBandwidthKey] ?: false
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[themeModeKey] = mode.wireValue
        }
    }

    suspend fun setLowBandwidthMode(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[lowBandwidthKey] = enabled
        }
    }
}
