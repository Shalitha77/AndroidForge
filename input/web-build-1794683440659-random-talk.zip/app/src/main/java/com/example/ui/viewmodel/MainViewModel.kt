package com.example.ui.viewmodel

import android.util.Log
import com.example.data.firebase.MatchmakingRepository
import com.example.data.firebase.UserPreferencesRepository
import com.example.data.model.BlockedUser
import com.example.data.model.GenderIdentity
import com.example.data.model.GenderPreference
import com.example.data.model.ThemeMode
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

sealed interface ProfileUiState {
    data object Loading : ProfileUiState
    data class Ready(val profile: UserProfile) : ProfileUiState
    data class Error(val message: String) : ProfileUiState
}

class MainViewModel(
    private val repository: MatchmakingRepository,
    private val prefsRepository: UserPreferencesRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val profileState: StateFlow<ProfileUiState> = repository.observeProfile(currentUserId)
        .map<UserProfile?, ProfileUiState> { profile ->
            if (profile != null) {
                ProfileUiState.Ready(profile)
            } else {
                ProfileUiState.Loading
            }
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing profile", rootError)
            emit(ProfileUiState.Error(rootError.message ?: "Unable to load profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = ProfileUiState.Loading
        )

    val onlineCount: StateFlow<Int> = repository.observeOnlineCount()
        .catch { emit(1) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = 1
        )

    val blockedUsers: StateFlow<List<BlockedUser>> = repository.observeBlockedUsers(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val localThemeMode: StateFlow<ThemeMode> = prefsRepository.themeModeFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = ThemeMode.DARK
        )

    private var heartbeatJob: Job? = null

    init {
        viewModelScope.launch {
            try {
                val profile = repository.ensureProfile(currentUserId)
                prefsRepository.setThemeMode(ThemeMode.fromWire(profile.themeMode))
                prefsRepository.setLowBandwidthMode(profile.lowBandwidthMode)
                startPresenceHeartbeat(profile.country)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Failed to initialize profile", e)
            }
        }
    }

    private fun startPresenceHeartbeat(initialCountry: String) {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (isActive) {
                val currentCountry = (profileState.value as? ProfileUiState.Ready)?.profile?.country
                    ?: initialCountry
                repository.updatePresenceHeartbeat(currentUserId, currentCountry, true)
                delay(30_000L)
            }
        }
    }

    fun confirm18PlusAndGuidelines() {
        viewModelScope.launch {
            runCatching {
                repository.updateProfilePreferences(
                    userId = currentUserId,
                    ageConfirmed18Plus = true,
                    guidelinesAccepted = true
                )
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun updatePreferredCountry(countryCode: String) {
        viewModelScope.launch {
            runCatching {
                repository.updateProfilePreferences(
                    userId = currentUserId,
                    preferredCountry = countryCode
                )
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun updateMyCountry(countryCode: String) {
        viewModelScope.launch {
            runCatching {
                repository.updateProfilePreferences(
                    userId = currentUserId,
                    country = countryCode
                )
                repository.updatePresenceHeartbeat(currentUserId, countryCode, true)
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun updateGenderPreferences(identity: GenderIdentity, preferred: GenderPreference) {
        viewModelScope.launch {
            runCatching {
                repository.updateProfilePreferences(
                    userId = currentUserId,
                    gender = identity.wireValue,
                    preferredGender = preferred.wireValue
                )
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun updateAlias(alias: String) {
        val clean = alias.trim()
        if (clean.length !in 2..32) {
            _statusMessage.value = "Display alias must be 2–32 characters."
            return
        }
        viewModelScope.launch {
            runCatching {
                repository.updateProfilePreferences(userId = currentUserId, alias = clean)
                _statusMessage.value = "Alias updated"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            prefsRepository.setThemeMode(mode)
            runCatching {
                repository.updateProfilePreferences(
                    userId = currentUserId,
                    themeMode = mode.wireValue
                )
            }
        }
    }

    fun setLowBandwidthMode(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setLowBandwidthMode(enabled)
            runCatching {
                repository.updateProfilePreferences(
                    userId = currentUserId,
                    lowBandwidthMode = enabled
                )
            }
        }
    }

    fun unblockUser(blockedUserId: String) {
        viewModelScope.launch {
            runCatching {
                repository.unblockUser(blockedUserId)
                _statusMessage.value = "User unblocked"
            }.onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun markOffline() {
        CoroutineScope(Dispatchers.IO).launch {
            val country = (profileState.value as? ProfileUiState.Ready)?.profile?.country ?: "GLOBAL"
            runCatching {
                repository.updatePresenceHeartbeat(currentUserId, country, false)
                repository.leaveQueue(currentUserId)
            }
        }
    }

    fun deleteAccount(onComplete: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                heartbeatJob?.cancel()
                repository.deleteUserAccountData(currentUserId)
                Firebase.auth.currentUser?.delete()?.await()
                onComplete()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Please re-sign in with Google before deleting your account.")
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        heartbeatJob?.cancel()
        markOffline()
    }

    private companion object {
        const val TAG = "MainViewModel"
    }
}
