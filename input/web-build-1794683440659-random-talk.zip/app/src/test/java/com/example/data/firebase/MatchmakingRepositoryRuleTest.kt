package com.example.data.firebase

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.ReportReason
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class MatchmakingRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureProfile_authenticatedOwner_createsAndUpdatesProfile() = runBlocking {
        val uid = signInTestUser("alice_${UUID.randomUUID()}@test.com")
        val repo = MatchmakingRepository(firestore, auth)

        val profile = withTimeout(DEFAULT_TIMEOUT_MS) { repo.ensureProfile(uid) }
        assertEquals(uid, profile.userId)
        assertTrue(profile.alias.isNotBlank())

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.updateProfilePreferences(
                userId = uid,
                preferredCountry = "JP",
                ageConfirmed18Plus = true,
                guidelinesAccepted = true,
                lowBandwidthMode = true
            )
        }

        val observed = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeProfile(uid).first { it?.preferredCountry == "JP" }
        }
        assertNotNull(observed)
        assertEquals(true, observed?.ageConfirmed18Plus)
        assertEquals(true, observed?.lowBandwidthMode)
    }

    @Test
    fun observeProfile_unauthenticatedCaller_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = MatchmakingRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeProfile("some_other_uid").first()
            }
            fail("Expected permission denied exception for unauthenticated caller")
        } catch (e: Exception) {
            val firestoreEx = checkNotNull(e.unwrapFirestoreException()) {
                "Expected nested FirebaseFirestoreException, got $e"
            }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx.code)
        }
    }

    @Test
    fun matchmaking_and_block_and_report_workEndToEnd() = runBlocking {
        val aliceUid = signInTestUser("alice_match_${UUID.randomUUID()}@test.com")
        val repo = MatchmakingRepository(firestore, auth)

        val aliceProfile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureProfile(aliceUid)
            repo.updateProfilePreferences(
                userId = aliceUid,
                ageConfirmed18Plus = true,
                guidelinesAccepted = true
            )
            repo.observeProfile(aliceUid).first { it?.ageConfirmed18Plus == true }!!
        }

        // Alice enters queue
        val aliceAttempt = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.enterQueueAndFindMatch(aliceProfile, emptySet(), emptySet())
        }
        assertTrue(aliceAttempt is MatchAttemptResult.WaitingInQueue)

        // Bob signs in and matches with Alice
        val bobUid = signInTestUser("bob_match_${UUID.randomUUID()}@test.com")
        val bobProfile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureProfile(bobUid)
            repo.updateProfilePreferences(
                userId = bobUid,
                ageConfirmed18Plus = true,
                guidelinesAccepted = true
            )
            repo.observeProfile(bobUid).first { it?.ageConfirmed18Plus == true }!!
        }

        val bobAttempt = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.enterQueueAndFindMatch(bobProfile, emptySet(), emptySet())
        }
        assertTrue(bobAttempt is MatchAttemptResult.Matched)
        val matched = bobAttempt as MatchAttemptResult.Matched
        assertEquals(aliceUid, matched.peerId)

        // Bob submits a safety report against Alice (and auto-blocks)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitReport(
                reportedUserId = aliceUid,
                roomId = matched.roomId,
                reason = ReportReason.SPAM,
                details = "Test moderation report"
            )
        }

        val blocked = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeBlockedUsers(bobUid).first { list -> list.any { it.blockedUserId == aliceUid } }
        }
        assertTrue(blocked.any { it.blockedUserId == aliceUid })
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 7000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
