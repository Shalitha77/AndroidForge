# Random Talk ProGuard / R8 Rules

# Keep WebRTC native bindings and JNI classes
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# Keep Kotlinx Serialization models
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.example.**$$serializer { *; }
-keepclassmembers class com.example.** {
    *** Companion;
}
-keepclasseswithmembers class com.example.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Keep Firestore data models
-keepclassmembers class com.example.data.model.** { *; }

# Keep Google Mobile Ads & UMP classes
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.ump.** { *; }
