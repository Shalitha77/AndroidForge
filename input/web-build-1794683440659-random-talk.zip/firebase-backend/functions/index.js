const functions = require("firebase-functions/v2");
const admin = require("firebase-admin");
admin.initializeApp();

const db = admin.firestore();

/**
 * Automated moderation trigger: increments reported user's reportCount
 * and flags repeat offenders when reports exceed threshold.
 */
exports.onAbuseReportCreated = functions.firestore.onDocumentCreated(
  "reports/{reportId}",
  async (event) => {
    const data = event.data?.data();
    if (!data || !data.reportedUserId) return;

    const reportedRef = db.collection("users").doc(data.reportedUserId);
    await db.runTransaction(async (tx) => {
      const snap = await tx.get(reportedRef);
      if (!snap.exists) return;
      const currentCount = snap.get("reportCount") || 0;
      tx.update(reportedRef, {
        reportCount: currentCount + 1,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    });
  }
);

/**
 * Scheduled cleanup of stale match_queue and offline presence entries (> 5 minutes old).
 */
exports.cleanupStaleMatchQueue = functions.scheduler.onSchedule(
  "every 5 minutes",
  async () => {
    const cutoff = admin.firestore.Timestamp.fromMillis(Date.now() - 5 * 60 * 1000);
    const staleQueue = await db
      .collection("match_queue")
      .where("heartbeatAt", "<", cutoff)
      .limit(200)
      .get();

    const batch = db.batch();
    staleQueue.docs.forEach((doc) => batch.delete(doc.ref));
    await batch.commit();
  }
);
