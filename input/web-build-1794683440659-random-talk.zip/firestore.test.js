const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const serverTimestamp = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";
const CHARLIE_UID = "charlie_uid_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validProfile(uid) {
  return {
    userId: uid,
    alias: "Traveler_42",
    country: "US",
    gender: "unspecified",
    preferredCountry: "GLOBAL",
    preferredGender: "any",
    ageConfirmed18Plus: true,
    guidelinesAccepted: true,
    themeMode: "dark",
    lowBandwidthMode: false,
    reportCount: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

function validQueueEntry(uid) {
  return {
    userId: uid,
    alias: "Traveler_42",
    country: "US",
    gender: "unspecified",
    preferredCountry: "GLOBAL",
    preferredGender: "any",
    status: "waiting",
    ageConfirmed18Plus: true,
    heartbeatAt: serverTimestamp(),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("match_queue").where("status", "==", "waiting").where("ageConfirmed18Plus", "==", true).get());
  await assertFails(unauthDb.collection("online_presence").where("isOnline", "==", true).get());
  await assertFails(unauthDb.collection("reports").where("reporterId", "==", ALICE_UID).get());
});

test("User profile: owner can create/read/update, cross-user read & shadow fields denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());

  // Shadow field injection fails
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({ isAdmin: true, updatedAt: serverTimestamp() })
  );

  // Legitimate preference update succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      preferredCountry: "JP",
      lowBandwidthMode: true,
      updatedAt: serverTimestamp(),
    })
  );
});

test("Blocked users subcollection: owner-isolated", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("blocked").doc(BOB_UID).set({
      userId: ALICE_UID,
      blockedUserId: BOB_UID,
      reason: "spam",
      createdAt: serverTimestamp(),
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("blocked").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("blocked").get());
});

test("Match queue: allows waiting discovery query, rejects unfiltered list & spoofing", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(aliceDb.collection("match_queue").doc(ALICE_UID).set(validQueueEntry(ALICE_UID)));

  // Unfiltered list fails
  await assertFails(bobDb.collection("match_queue").get());

  // Filtered waiting query succeeds
  await assertSucceeds(
    bobDb.collection("match_queue")
      .where("status", "==", "waiting")
      .where("ageConfirmed18Plus", "==", true)
      .get()
  );

  // Bob claims Alice's waiting entry atomically
  await assertSucceeds(
    bobDb.collection("match_queue").doc(ALICE_UID).update({
      status: "matched",
      roomId: "room_alice_bob_1",
      matchedBy: BOB_UID,
      updatedAt: serverTimestamp(),
    })
  );

  // Charlie cannot re-claim an already matched entry
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  await assertFails(
    charlieDb.collection("match_queue").doc(ALICE_UID).update({
      status: "matched",
      roomId: "room_alice_charlie",
      matchedBy: CHARLIE_UID,
      updatedAt: serverTimestamp(),
    })
  );
});

test("Call room & ICE candidates: participant-isolated and terminal ended state locked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  const roomRef = aliceDb.collection("call_rooms").doc("room_1");
  await assertSucceeds(
    roomRef.set({
      callerId: ALICE_UID,
      calleeId: BOB_UID,
      participants: [ALICE_UID, BOB_UID],
      callerAlias: "Alice_01",
      calleeAlias: "Bob_02",
      callerCountry: "US",
      calleeCountry: "CA",
      status: "offering",
      offerSdp: "v=0...",
      offerType: "offer",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Non-participant Charlie cannot read or write room
  await assertFails(charlieDb.collection("call_rooms").doc("room_1").get());
  await assertFails(
    charlieDb.collection("call_rooms").doc("room_1").collection("ice_candidates").doc("c1").set({
      senderId: CHARLIE_UID,
      participants: [ALICE_UID, BOB_UID],
      sdpMid: "0",
      sdpMLineIndex: 0,
      candidate: "candidate:1 1 udp 123 1.2.3.4 5000 typ host",
      createdAt: serverTimestamp(),
    })
  );

  // Participant Bob writes answer & ICE candidate
  await assertSucceeds(
    bobDb.collection("call_rooms").doc("room_1").update({
      answerSdp: "v=0...",
      answerType: "answer",
      status: "connected",
      updatedAt: serverTimestamp(),
    })
  );

  await assertSucceeds(
    bobDb.collection("call_rooms").doc("room_1").collection("ice_candidates").doc("c_bob_1").set({
      senderId: BOB_UID,
      participants: [ALICE_UID, BOB_UID],
      sdpMid: "0",
      sdpMLineIndex: 0,
      candidate: "candidate:1 1 udp 123 1.2.3.4 5000 typ host",
      createdAt: serverTimestamp(),
    })
  );

  // End call locks room
  await assertSucceeds(
    aliceDb.collection("call_rooms").doc("room_1").update({
      status: "ended",
      endedBy: ALICE_UID,
      updatedAt: serverTimestamp(),
    })
  );

  await assertFails(
    bobDb.collection("call_rooms").doc("room_1").update({
      status: "connected",
      updatedAt: serverTimestamp(),
    })
  );
});

test("Reports: reporter can create append-only report, cannot self-report or update", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("reports").doc("rep_1").set({
      reporterId: ALICE_UID,
      reportedUserId: BOB_UID,
      roomId: "room_1",
      reason: "harassment",
      details: "Abusive behavior during call",
      status: "pending",
      createdAt: serverTimestamp(),
    })
  );

  // Self-report rejected
  await assertFails(
    aliceDb.collection("reports").doc("rep_2").set({
      reporterId: ALICE_UID,
      reportedUserId: ALICE_UID,
      roomId: "room_1",
      reason: "spam",
      details: "self",
      status: "pending",
      createdAt: serverTimestamp(),
    })
  );

  // Cross-user read & update rejected
  await assertFails(bobDb.collection("reports").doc("rep_1").get());
  await assertFails(aliceDb.collection("reports").doc("rep_1").update({ status: "resolved" }));
});
