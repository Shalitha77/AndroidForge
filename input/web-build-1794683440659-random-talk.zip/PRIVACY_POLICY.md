# Privacy Policy — Random Talk

**Effective Date:** November 14, 2026  
**Package:** `com.randomtalk.videochat`  
**Contact:** support@randomtalk.app

## 1. Eligibility (18+ Only)
Random Talk is strictly intended for adults aged **18 years and older**. Users must confirm their age before accessing random video chat.

## 2. Data We Collect & Process
1. **Authentication Identifier**: We use Google Sign-In via Firebase Authentication strictly to assign a unique, private User ID (`UID`). Your Google email address, real name, and profile photo are **never displayed** to other users.
2. **Anonymous Matchmaking Profile**: Your chosen non-personal alias, selected country/region, match preferences, and safety blocklist are stored in Firebase Firestore under owner-isolated security rules.
3. **Peer-to-Peer Video & Audio**: Live video and audio are transmitted directly between matched peers via encrypted WebRTC (`DTLS-SRTP`). Random Talk does **not** record, store, or archive video or audio streams.
4. **Safety & Abuse Reports**: When you report a peer, the report category, optional description, and peer UID are logged for moderation and the peer is automatically added to your personal blocklist.
5. **Advertising & Consent**: Random Talk uses Google AdMob and Google User Messaging Platform (UMP) to request and respect user ad privacy consent. Ads are never displayed over an active video call.

## 3. Permissions Used
- `CAMERA`: Capture local video for live video chat.
- `RECORD_AUDIO` & `MODIFY_AUDIO_SETTINGS`: Capture and route audio during calls.
- `INTERNET` & `ACCESS_NETWORK_STATE`: Connect to Firebase matchmaking/signaling and WebRTC peers.
- `com.google.android.gms.permission.AD_ID`: Google Play Services advertising ID compliance.

## 4. Account & Data Deletion
You can permanently delete your profile, blocklist, presence records, and Firebase Auth account at any time inside the app via **Settings → Delete Account**.
