# Random Talk — Firebase, WebRTC, AdMob & Build Guide

## 1. Architecture Overview
- **Package Name (`applicationId`)**: `com.randomtalk.videochat`
- **UI**: Jetpack Compose + Material Design 3 (Light, Dark, System themes)
- **Video & Audio**: WebRTC (`io.getstream:stream-webrtc-android:1.3.10`) with hardware AEC/NS, front/back camera switching, adaptive low-bandwidth bitrate/FPS tuning, and STUN + configurable TURN support.
- **Authentication**: Firebase Authentication using Google Sign-In via Jetpack `CredentialManager` (your Google email and real name are kept private and never shown to strangers).
- **Matchmaking & Signaling**: Cloud Firestore Enterprise (`R.string.firestore_database_id`) with atomic transactions (`db.runTransaction`) preventing duplicate connections, blocklist filtering, live presence heartbeat counter, and isolated `call_rooms/{roomId}/ice_candidates` subcollections.
- **Monetization & Privacy**: Google AdMob SDK (`Banner`, `Native`, post-session `Interstitial`) + Google User Messaging Platform (`UMP`) consent SDK. Zero ads are ever rendered during an active video call.

---

## 2. Firebase Configuration
### Provisioned Backend (Active)
- `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml` are already provisioned for your Firebase project.
- Security rules live in `/firestore.rules` and schema blueprint in `/firebase-blueprint.json`.
- App Check is initialized in `RandomTalkApp.kt` (`DebugAppCheckProviderFactory` for debug builds). For Play Store release builds, register your SHA-256 Play App Signing fingerprint and enable **Play Integrity** in the Firebase Console -> App Check.

### Optional: Firebase Realtime Database & Cloud Functions
Reference templates for optional RTDB `onDisconnect` cleanup and automated abuse moderation triggers are included in:
- `firebase-backend/database.rules.json`
- `firebase-backend/functions/index.js`

---

## 3. WebRTC STUN / TURN Configuration
Default STUN servers (`stun:stun.l.google.com:19302`, `stun1`, `stun2`) are built in.
For reliable connections behind strict carrier/symmetric NATs, add your TURN credentials in `.env` (or AI Studio Secrets):
```properties
TURN_SERVER_URL=turn:turn.yourdomain.com:3478
TURN_SERVER_USERNAME=your_turn_user
TURN_SERVER_CREDENTIAL=your_turn_password
```

---

## 4. Google AdMob Configuration
Official Google test Ad Unit IDs are configured by default in `.env.example`.
For production releases, set your real AdMob IDs in `.env` (or AI Studio Secrets):
```properties
ADMOB_APP_ID=ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy
ADMOB_BANNER_ID=ca-app-pub-xxxxxxxxxxxxxxxx/bbbbbbbbbb
ADMOB_INTERSTITIAL_ID=ca-app-pub-xxxxxxxxxxxxxxxx/iiiiiiiiii
ADMOB_NATIVE_ID=ca-app-pub-xxxxxxxxxxxxxxxx/nnnnnnnnnn
```

---

## 5. Building the APK
Run in the project root:
```bash
gradle :app:assembleDebug
```
The signed debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk` (and copied to `.build-outputs/app-debug.apk` and `APK_DOWNLOAD/app-debug.apk`).
